# ============================================================
# SCRIPT 2: Run on your WORK Windows machine
# No internet needed. No admin required.
#
# How to run:
#   1. Unzip playwright-offline-bundle.zip
#   2. Open a normal PowerShell window (no admin needed)
#   3. Navigate to the unzipped folder
#   4. Run: .\2-install-on-work-windows.ps1
# ============================================================

$ErrorActionPreference = "Stop"

$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Playwright Offline Installer (Windows)"        -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# ── Check Node ──────────────────────────────────────────────
try {
    $nodeVersion = node --version
    Write-Host "✅ Node found: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Node.js not found. Ask IT to install Node.js LTS." -ForegroundColor Red
    exit 1
}

Write-Host "✅ npm found: $(npm --version)" -ForegroundColor Green
Write-Host ""

# ── Install CLI from local tarball ──────────────────────────
$CLI_TARBALL = Get-ChildItem -Path $SCRIPT_DIR -Filter "playwright-cli-*.tgz" `
               | Select-Object -First 1

if (-not $CLI_TARBALL) {
    Write-Host "❌ No CLI tarball found. Make sure you unzipped the full bundle." -ForegroundColor Red
    exit 1
}

Write-Host "📦 Installing Playwright CLI from: $($CLI_TARBALL.Name)" -ForegroundColor Yellow

# Try global first, fall back to local if permissions error
try {
    npm install -g $CLI_TARBALL.FullName 2>&1 | Tee-Object -Variable npmOutput
    if ($LASTEXITCODE -ne 0) { throw "npm install -g failed" }
    Write-Host "✅ Playwright CLI installed globally" -ForegroundColor Green
} catch {
    Write-Host ""
    Write-Host "⚠️  Global install failed (likely a permissions issue)." -ForegroundColor DarkYellow
    Write-Host "   Falling back to local install in this project folder..." -ForegroundColor DarkYellow
    Write-Host ""

    # Install locally instead
    npm install $CLI_TARBALL.FullName

    # Add node_modules/.bin to PATH for this session
    $localBin = Join-Path $SCRIPT_DIR "node_modules\.bin"
    $env:PATH = "$localBin;$env:PATH"

    Write-Host "✅ Playwright CLI installed locally" -ForegroundColor Green
    Write-Host "ℹ️  Use 'npx playwright-cli' instead of 'playwright-cli' to run it." -ForegroundColor DarkYellow
}

Write-Host ""

# ── Verify ───────────────────────────────────────────────────
Write-Host "🔍 Verifying installation..." -ForegroundColor Yellow

$cliCheck = Get-Command playwright-cli -ErrorAction SilentlyContinue
if ($cliCheck) {
    Write-Host "✅ playwright-cli found at: $($cliCheck.Source)" -ForegroundColor Green
} else {
    Write-Host "⚠️  playwright-cli not in PATH yet — open a new PowerShell window." -ForegroundColor DarkYellow
    Write-Host "   Or use: npx playwright-cli" -ForegroundColor DarkYellow
}

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Done! Open a NEW PowerShell window, then:"    -ForegroundColor White
Write-Host "  playwright-cli open https://your-app.com"     -ForegroundColor White
Write-Host "  (or: npx playwright-cli open https://...)"    -ForegroundColor White
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""
