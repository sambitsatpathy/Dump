# Playwright Offline Bundle

Everything needed to run Playwright CLI on a Windows machine with no internet.

## Contents

| File/Folder | Purpose |
|---|---|
| `playwright-cli-X.X.X.tgz` | Playwright CLI npm package |
| `2-install-on-work-windows.ps1` | Windows installer script |

## Steps on your Windows work machine

1. Copy `playwright-offline-bundle.zip` to your work machine
2. Unzip it
3. Open a normal **PowerShell window** (no admin needed)
4. Navigate to the unzipped folder:
   ```powershell
   cd C:\path\to\playwright-transfer
   ```
5. Run the installer:
   ```powershell
   .\2-install-on-work-windows.ps1
   ```
6. Open a **new** PowerShell window
7. Verify:
   ```powershell
   playwright-cli --help
   playwright-cli open https://your-app.com
   ```

## If global install fails

The script automatically falls back to a local install.
Use `npx playwright-cli` instead of `playwright-cli`.

## Using with Copilot Agent in VS Code

Add `.vscode/mcp.json` to your project:

```json
{
  "servers": {
    "playwright": {
      "command": "npx",
      "args": ["@playwright/mcp@latest"],
      "type": "stdio"
    }
  }
}
```
