# Monitoring — Pattern Reference (CloudWatch, Logs, Alarms, CloudTrail, Cost)

## CloudWatch metrics

```bash
aws cloudwatch list-metrics --namespace AWS/EC2 --metric-name CPUUtilization \
  --dimensions Name=InstanceId,Value=i-0abc

# Last 3h of CPU, 5-min buckets
aws cloudwatch get-metric-statistics --namespace AWS/EC2 --metric-name CPUUtilization \
  --dimensions Name=InstanceId,Value=i-0abc \
  --start-time "$(date -u -d '3 hours ago' +%Y-%m-%dT%H:%M:%S)" \
  --end-time "$(date -u +%Y-%m-%dT%H:%M:%S)" \
  --period 300 --statistics Average Maximum \
  --query 'sort_by(Datapoints,&Timestamp)[].[Timestamp,Average,Maximum]' --output table

# Custom metric
aws cloudwatch put-metric-data --namespace MyApp --metric-name QueueDepth --value 42 --unit Count
```

## Logs

```bash
aws logs describe-log-groups --query 'logGroups[].[logGroupName,storedBytes,retentionInDays]' --output table
aws logs put-retention-policy --log-group-name /aws/lambda/my-fn --retention-in-days 30  # default = forever = $$$

# Live tail (best debugging tool in the CLI)
aws logs tail /aws/lambda/my-fn --follow
aws logs tail /aws/lambda/my-fn --since 1h --filter-pattern "ERROR"

# Logs Insights — SQL-ish queries over log groups
QID=$(aws logs start-query --log-group-name /aws/lambda/my-fn \
  --start-time $(date -d '1 hour ago' +%s) --end-time $(date +%s) \
  --query-string 'fields @timestamp, @message | filter @message like /ERROR/ | sort @timestamp desc | limit 50' \
  --query 'queryId' --output text)
sleep 3 && aws logs get-query-results --query-id "$QID"

aws logs delete-log-group --log-group-name /aws/lambda/old-fn
```

## Alarms

```bash
# CPU alarm → SNS
aws cloudwatch put-metric-alarm --alarm-name high-cpu-i0abc \
  --namespace AWS/EC2 --metric-name CPUUtilization \
  --dimensions Name=InstanceId,Value=i-0abc \
  --statistic Average --period 300 --evaluation-periods 2 \
  --threshold 80 --comparison-operator GreaterThanThreshold \
  --alarm-actions arn:aws:sns:us-east-1:123456789012:alerts

aws cloudwatch describe-alarms --state-value ALARM      # what's firing right now
aws cloudwatch set-alarm-state --alarm-name high-cpu-i0abc --state-value ALARM --state-reason test  # test the pipe
aws cloudwatch delete-alarms --alarm-names high-cpu-i0abc
```

## CloudTrail (who did what)

```bash
# Last 90 days queryable free, no setup:
aws cloudtrail lookup-events --lookup-attributes AttributeKey=EventName,AttributeValue=TerminateInstances \
  --max-results 20 --query 'Events[].[EventTime,Username,CloudTrailEvent]' --output text
aws cloudtrail lookup-events --lookup-attributes AttributeKey=Username,AttributeValue=alice --max-results 20
aws cloudtrail lookup-events --lookup-attributes AttributeKey=ResourceName,AttributeValue=i-0abc

# Durable trail to S3 (for >90d / org-wide)
aws cloudtrail create-trail --name main --s3-bucket-name my-trail-bucket --is-multi-region-trail
aws cloudtrail start-logging --name main
```

## Cost

```bash
# This month by service
aws ce get-cost-and-usage \
  --time-period Start=$(date +%Y-%m-01),End=$(date +%Y-%m-%d) \
  --granularity MONTHLY --metrics UnblendedCost \
  --group-by Type=DIMENSION,Key=SERVICE \
  --query 'ResultsByTime[0].Groups[?Metrics.UnblendedCost.Amount > `1`].[Keys[0],Metrics.UnblendedCost.Amount]' \
  --output table

# Daily trend last 14 days
aws ce get-cost-and-usage --time-period Start=$(date -d '14 days ago' +%Y-%m-%d),End=$(date +%Y-%m-%d) \
  --granularity DAILY --metrics UnblendedCost \
  --query 'ResultsByTime[].[TimePeriod.Start,Total.UnblendedCost.Amount]' --output table

# Budget with alert
aws budgets create-budget --account-id 123456789012 \
  --budget '{"BudgetName":"monthly","BudgetLimit":{"Amount":"100","Unit":"USD"},"TimeUnit":"MONTHLY","BudgetType":"COST"}' \
  --notifications-with-subscribers '[{"Notification":{"NotificationType":"ACTUAL","ComparisonOperator":"GREATER_THAN","Threshold":80},"Subscribers":[{"SubscriptionType":"EMAIL","Address":"me@example.com"}]}]'
```

Common money leaks to check: unattached EBS volumes, unassociated Elastic IPs, idle NAT gateways, log groups with no retention, old snapshots, stopped-but-not-terminated instances (EBS still bills).
