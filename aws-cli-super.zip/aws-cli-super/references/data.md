# Data — Pattern Reference (RDS, Redshift, Glue, Athena)

Pattern-level coverage. For unlisted operations use `scaffolds/discovery.md`.

## RDS

```bash
aws rds describe-db-instances \
  --query 'DBInstances[].[DBInstanceIdentifier,Engine,DBInstanceClass,DBInstanceStatus,Endpoint.Address]' --output table

# Create Postgres (put in private subnets; SG only from app tier)
aws rds create-db-instance --db-instance-identifier mydb \
  --engine postgres --engine-version 16.4 \
  --db-instance-class db.t4g.micro --allocated-storage 20 \
  --master-username admin --manage-master-user-password \
  --db-subnet-group-name my-private-subnets \
  --vpc-security-group-ids sg-db --no-publicly-accessible \
  --backup-retention-period 7 --tags Key=CreatedBy,Value=cli
aws rds wait db-instance-available --db-instance-identifier mydb

# --manage-master-user-password stores creds in Secrets Manager:
aws secretsmanager get-secret-value --secret-id $(aws rds describe-db-instances \
  --db-instance-identifier mydb --query 'DBInstances[0].MasterUserSecret.SecretArn' --output text) \
  --query 'SecretString' --output text

# Subnet group (prerequisite)
aws rds create-db-subnet-group --db-subnet-group-name my-private-subnets \
  --db-subnet-group-description private --subnet-ids subnet-priv-a subnet-priv-b

# Ops
aws rds stop-db-instance --db-instance-identifier mydb        # auto-restarts after 7 days
aws rds start-db-instance --db-instance-identifier mydb
aws rds modify-db-instance --db-instance-identifier mydb --db-instance-class db.t4g.small --apply-immediately
aws rds reboot-db-instance --db-instance-identifier mydb

# Snapshots & restore (restore = NEW instance, never in-place)
aws rds create-db-snapshot --db-instance-identifier mydb --db-snapshot-identifier mydb-pre-migration
aws rds restore-db-instance-from-db-snapshot --db-instance-identifier mydb-restored \
  --db-snapshot-identifier mydb-pre-migration
aws rds restore-db-instance-to-point-in-time --source-db-instance-identifier mydb \
  --target-db-instance-identifier mydb-pit --restore-time 2026-07-01T03:00:00Z

# Delete — confirm with user; final snapshot unless truly disposable
aws rds delete-db-instance --db-instance-identifier mydb \
  --final-db-snapshot-identifier mydb-final          # or --skip-final-snapshot
```

Aurora: same verbs, cluster-shaped — `create-db-cluster` + `create-db-instance` per node; `describe-db-clusters`.

## Redshift

```bash
aws redshift describe-clusters --query 'Clusters[].[ClusterIdentifier,NodeType,ClusterStatus,Endpoint.Address]' --output table
aws redshift create-cluster --cluster-identifier my-wh --node-type ra3.xlplus \
  --number-of-nodes 2 --master-username admin --master-user-password 'S3cret!pass' \
  --cluster-subnet-group-name my-subnets --vpc-security-group-ids sg-wh
aws redshift pause-cluster --cluster-identifier my-wh      # stop paying compute
aws redshift resume-cluster --cluster-identifier my-wh
aws redshift delete-cluster --cluster-identifier my-wh --final-cluster-snapshot-identifier my-wh-final

# Run SQL without a client — Redshift Data API
aws redshift-data execute-statement --cluster-identifier my-wh --database dev --db-user admin \
  --sql "SELECT count(*) FROM sales"
aws redshift-data get-statement-result --id STATEMENT_ID
# Consider Redshift Serverless (redshift-serverless namespace) for spiky workloads
```

## Glue

```bash
# Catalog: databases + tables (shared with Athena)
aws glue create-database --database-input '{"Name": "analytics"}'
aws glue get-tables --database-name analytics --query 'TableList[].[Name,StorageDescriptor.Location]' --output table

# Crawler: scans S3, infers schema, fills catalog
aws glue create-crawler --name s3-crawler --role GlueServiceRole \
  --database-name analytics --targets '{"S3Targets": [{"Path": "s3://my-bucket/data/"}]}'
aws glue start-crawler --name s3-crawler
aws glue get-crawler --name s3-crawler --query 'Crawler.State'

# ETL jobs
aws glue create-job --name my-etl --role GlueServiceRole \
  --command '{"Name": "glueetl", "ScriptLocation": "s3://my-bucket/scripts/etl.py", "PythonVersion": "3"}' \
  --glue-version "4.0" --number-of-workers 2 --worker-type G.1X
aws glue start-job-run --job-name my-etl --arguments '{"--input_path": "s3://my-bucket/in/"}'
aws glue get-job-run --job-name my-etl --run-id RUN_ID --query 'JobRun.[JobRunState,ErrorMessage]'
```

## Athena (SQL over S3 — pairs with Glue catalog)

```bash
# One-time: results bucket
aws athena update-work-group --work-group primary --configuration-updates \
  'ResultConfigurationUpdates={OutputLocation=s3://my-athena-results/}'

QID=$(aws athena start-query-execution \
  --query-string "SELECT region, count(*) FROM analytics.events GROUP BY 1" \
  --work-group primary --query 'QueryExecutionId' --output text)
aws athena get-query-execution --query-execution-id "$QID" --query 'QueryExecution.Status.State'
aws athena get-query-results --query-execution-id "$QID"
# Billing is per-TB-scanned: partition data + use Parquet to cut cost 10-100x
```
