# VPC — Networking Reference

Contents: [Inspect](#inspect) · [Build a VPC from scratch](#build) · [Subnets](#subnets) · [Routing](#routing) · [Internet & NAT](#gateways) · [Peering](#peering) · [Endpoints](#endpoints) · [NACLs](#nacls) · [Flow logs](#flow-logs) · [Teardown](#teardown)

## Inspect

```bash
aws ec2 describe-vpcs --query 'Vpcs[].[VpcId,CidrBlock,IsDefault,Tags[?Key==`Name`]|[0].Value]' --output table
aws ec2 describe-subnets --filters "Name=vpc-id,Values=vpc-0abc" \
  --query 'Subnets[].[SubnetId,CidrBlock,AvailabilityZone,MapPublicIpOnLaunch,Tags[?Key==`Name`]|[0].Value]' --output table
aws ec2 describe-route-tables --filters "Name=vpc-id,Values=vpc-0abc"
aws ec2 describe-internet-gateways --filters "Name=attachment.vpc-id,Values=vpc-0abc"
aws ec2 describe-nat-gateways --filter "Name=vpc-id,Values=vpc-0abc"

# What's IN this VPC? (before teardown, always)
aws ec2 describe-network-interfaces --filters "Name=vpc-id,Values=vpc-0abc" \
  --query 'NetworkInterfaces[].[NetworkInterfaceId,Description,Status]' --output table
```

ENIs are the truth: if `describe-network-interfaces` shows anything, something (instance, RDS, Lambda, LB, endpoint) still lives there.

## Build

Standard 2-AZ public/private VPC, step by step. Tag every piece.

```bash
# 1. VPC
VPC=$(aws ec2 create-vpc --cidr-block 10.0.0.0/16 \
  --tag-specifications 'ResourceType=vpc,Tags=[{Key=Name,Value=main}]' \
  --query 'Vpc.VpcId' --output text)
aws ec2 modify-vpc-attribute --vpc-id "$VPC" --enable-dns-hostnames

# 2. Subnets (public ×2, private ×2)
PUB_A=$(aws ec2 create-subnet --vpc-id "$VPC" --cidr-block 10.0.1.0/24 --availability-zone us-east-1a \
  --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=public-a}]' --query 'Subnet.SubnetId' --output text)
PUB_B=$(aws ec2 create-subnet --vpc-id "$VPC" --cidr-block 10.0.2.0/24 --availability-zone us-east-1b \
  --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=public-b}]' --query 'Subnet.SubnetId' --output text)
PRIV_A=$(aws ec2 create-subnet --vpc-id "$VPC" --cidr-block 10.0.11.0/24 --availability-zone us-east-1a \
  --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=private-a}]' --query 'Subnet.SubnetId' --output text)
PRIV_B=$(aws ec2 create-subnet --vpc-id "$VPC" --cidr-block 10.0.12.0/24 --availability-zone us-east-1b \
  --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=private-b}]' --query 'Subnet.SubnetId' --output text)
aws ec2 modify-subnet-attribute --subnet-id "$PUB_A" --map-public-ip-on-launch
aws ec2 modify-subnet-attribute --subnet-id "$PUB_B" --map-public-ip-on-launch

# 3. Internet gateway
IGW=$(aws ec2 create-internet-gateway \
  --tag-specifications 'ResourceType=internet-gateway,Tags=[{Key=Name,Value=main-igw}]' \
  --query 'InternetGateway.InternetGatewayId' --output text)
aws ec2 attach-internet-gateway --internet-gateway-id "$IGW" --vpc-id "$VPC"

# 4. Public route table
PUB_RT=$(aws ec2 create-route-table --vpc-id "$VPC" \
  --tag-specifications 'ResourceType=route-table,Tags=[{Key=Name,Value=public-rt}]' \
  --query 'RouteTable.RouteTableId' --output text)
aws ec2 create-route --route-table-id "$PUB_RT" --destination-cidr-block 0.0.0.0/0 --gateway-id "$IGW"
aws ec2 associate-route-table --route-table-id "$PUB_RT" --subnet-id "$PUB_A"
aws ec2 associate-route-table --route-table-id "$PUB_RT" --subnet-id "$PUB_B"

# 5. NAT gateway (costs ~$32/mo + data — warn user) + private route table
EIP=$(aws ec2 allocate-address --domain vpc --query 'AllocationId' --output text)
NAT=$(aws ec2 create-nat-gateway --subnet-id "$PUB_A" --allocation-id "$EIP" \
  --tag-specifications 'ResourceType=natgateway,Tags=[{Key=Name,Value=main-nat}]' \
  --query 'NatGateway.NatGatewayId' --output text)
aws ec2 wait nat-gateway-available --nat-gateway-ids "$NAT"
PRIV_RT=$(aws ec2 create-route-table --vpc-id "$VPC" \
  --tag-specifications 'ResourceType=route-table,Tags=[{Key=Name,Value=private-rt}]' \
  --query 'RouteTable.RouteTableId' --output text)
aws ec2 create-route --route-table-id "$PRIV_RT" --destination-cidr-block 0.0.0.0/0 --nat-gateway-id "$NAT"
aws ec2 associate-route-table --route-table-id "$PRIV_RT" --subnet-id "$PRIV_A"
aws ec2 associate-route-table --route-table-id "$PRIV_RT" --subnet-id "$PRIV_B"
```

## Subnets

Sizing: /24 = 251 usable IPs (AWS reserves 5 per subnet). Lambda + EKS eat IPs fast — go bigger for those.

```bash
aws ec2 delete-subnet --subnet-id subnet-0abc     # fails if ENIs exist — check first
```

## Routing

```bash
aws ec2 describe-route-tables --route-table-ids rtb-0abc \
  --query 'RouteTables[].Routes[].[DestinationCidrBlock,GatewayId,NatGatewayId,State]' --output table
aws ec2 create-route --route-table-id rtb-0abc --destination-cidr-block 10.1.0.0/16 --vpc-peering-connection-id pcx-0abc
aws ec2 delete-route --route-table-id rtb-0abc --destination-cidr-block 10.1.0.0/16
aws ec2 replace-route --route-table-id rtb-0abc --destination-cidr-block 0.0.0.0/0 --nat-gateway-id nat-NEW
```

A "public subnet" is just a subnet whose route table points 0.0.0.0/0 at an IGW. Nothing else makes it public.

## Gateways

```bash
# NAT gateway delete (stop paying)
aws ec2 delete-nat-gateway --nat-gateway-id nat-0abc
aws ec2 release-address --allocation-id eipalloc-0abc   # after NAT gone, or EIP keeps billing

# Detach + delete IGW (VPC teardown)
aws ec2 detach-internet-gateway --internet-gateway-id igw-0abc --vpc-id vpc-0abc
aws ec2 delete-internet-gateway --internet-gateway-id igw-0abc
```

## Peering

```bash
aws ec2 create-vpc-peering-connection --vpc-id vpc-AAA --peer-vpc-id vpc-BBB \
  --peer-owner-id 999999999999 --peer-region eu-west-1          # cross-account/region optional
aws ec2 accept-vpc-peering-connection --vpc-peering-connection-id pcx-0abc   # run as peer owner
# THEN add routes both sides + open security groups both sides. No transitive routing — hub-spoke needs Transit Gateway.
```

## Endpoints

Keep traffic to AWS services off the internet (and off the NAT bill):

```bash
# Gateway endpoints — FREE — S3 & DynamoDB only
aws ec2 create-vpc-endpoint --vpc-id vpc-0abc --service-name com.amazonaws.us-east-1.s3 \
  --route-table-ids rtb-priv --vpc-endpoint-type Gateway

# Interface endpoints — ~$7/mo each + data — everything else
aws ec2 create-vpc-endpoint --vpc-id vpc-0abc --service-name com.amazonaws.us-east-1.ssm \
  --vpc-endpoint-type Interface --subnet-ids subnet-priv-a subnet-priv-b \
  --security-group-ids sg-endpoints --private-dns-enabled
# SSM Session Manager in private subnet needs three: ssm, ssmmessages, ec2messages

aws ec2 describe-vpc-endpoint-services --query 'ServiceNames' | grep -i ecr   # find service names
```

## NACLs

Stateless subnet firewalls. Default allows all — usually leave alone; use security groups. When needed:

```bash
aws ec2 describe-network-acls --filters "Name=vpc-id,Values=vpc-0abc"
aws ec2 create-network-acl-entry --network-acl-id acl-0abc --rule-number 100 \
  --protocol tcp --port-range From=443,To=443 --cidr-block 0.0.0.0/0 --rule-action allow --ingress
# Stateless = must also allow ephemeral return ports 1024-65535 egress. This trips everyone.
```

## Flow logs

```bash
aws ec2 create-flow-logs --resource-type VPC --resource-ids vpc-0abc \
  --traffic-type ALL --log-destination-type cloud-watch-logs \
  --log-group-name /vpc/flowlogs --deliver-logs-permission-arn arn:aws:iam::123456789012:role/flowlogs-role
# Query rejected traffic via CloudWatch Logs Insights — see references/monitoring.md
```

## Teardown

Order matters. Script it, show hit list, confirm, then:

1. Terminate instances / delete LBs / delete RDS / delete Lambda ENIs sources
2. `describe-network-interfaces` — must be empty
3. Delete NAT gateways → release EIPs
4. Delete VPC endpoints
5. Delete peering connections
6. Detach + delete IGW
7. Delete subnets
8. Delete non-main route tables, non-default SGs/NACLs
9. `aws ec2 delete-vpc --vpc-id vpc-0abc`

If delete-vpc fails with DependencyViolation, an ENI survives — go back to step 2.
