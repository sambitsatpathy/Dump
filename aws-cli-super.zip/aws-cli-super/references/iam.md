# IAM — Identity & Access Reference

IAM is global (no `--region`). Changes propagate in seconds but can take ~1 min to be consistent everywhere. Every mutation here affects security posture — narrate changes to the user and prefer least privilege.

Contents: [Whoami & audit](#audit) · [Users](#users) · [Access keys](#access-keys) · [Groups](#groups) · [Roles](#roles) · [Policies](#policies) · [Permission testing](#testing) · [MFA](#mfa) · [Instance profiles](#instance-profiles) · [Common recipes](#recipes)

## Audit

```bash
aws sts get-caller-identity
aws iam get-account-summary                       # counts of everything
aws iam get-account-authorization-details > iam-dump.json   # EVERYTHING — users, roles, policies, attachments

# Credential report: every user, key age, MFA status, last used (the #1 audit tool)
aws iam generate-credential-report
aws iam get-credential-report --query 'Content' --output text | base64 -d > cred-report.csv

# Old access keys (rotate >90 days)
aws iam list-users --query 'Users[].UserName' --output text | tr '\t' '\n' | while read u; do
  aws iam list-access-keys --user-name "$u" \
    --query "AccessKeyMetadata[].[UserName,AccessKeyId,CreateDate,Status]" --output text
done

# Users without MFA
aws iam list-users --query 'Users[].UserName' --output text | tr '\t' '\n' | while read u; do
  [ -z "$(aws iam list-mfa-devices --user-name "$u" --query 'MFADevices[0]' --output text)" ] && echo "NO MFA: $u"
done

# Who has AdministratorAccess?
aws iam list-entities-for-policy --policy-arn arn:aws:iam::aws:policy/AdministratorAccess
```

## Users

```bash
aws iam create-user --user-name alice --tags Key=Team,Value=eng
aws iam list-users --query 'Users[].[UserName,CreateDate,PasswordLastUsed]' --output table
aws iam get-user --user-name alice

# Console password
aws iam create-login-profile --user-name alice --password 'TempPass123!' --password-reset-required
aws iam update-login-profile --user-name alice --password 'NewPass456!'
aws iam delete-login-profile --user-name alice     # kills console access, keys still work

# Delete user — must strip everything first, in order:
aws iam list-attached-user-policies --user-name alice   # then detach-user-policy each
aws iam list-user-policies --user-name alice            # then delete-user-policy each (inline)
aws iam list-access-keys --user-name alice              # then delete-access-key each
aws iam list-groups-for-user --user-name alice          # then remove-user-from-group each
aws iam list-mfa-devices --user-name alice              # then deactivate-mfa-device each
aws iam delete-login-profile --user-name alice 2>/dev/null
aws iam delete-user --user-name alice
```

## Access keys

```bash
aws iam create-access-key --user-name alice       # SHOWS SECRET ONCE — save immediately
aws iam list-access-keys --user-name alice
aws iam update-access-key --user-name alice --access-key-id AKIA... --status Inactive   # disable, reversible
aws iam delete-access-key --user-name alice --access-key-id AKIA...
aws iam get-access-key-last-used --access-key-id AKIA...   # is it safe to kill?
```

Rotation pattern: create new key → deploy → verify with last-used → deactivate old → wait → delete old.

## Groups

```bash
aws iam create-group --group-name developers
aws iam add-user-to-group --group-name developers --user-name alice
aws iam attach-group-policy --group-name developers --policy-arn arn:aws:iam::aws:policy/PowerUserAccess
aws iam get-group --group-name developers        # members
```

Attach policies to groups, not users. Always.

## Roles

```bash
# Trust policy decides WHO can assume; permission policies decide WHAT they can do
cat > trust.json <<'EOF'
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": {"Service": "ec2.amazonaws.com"},
    "Action": "sts:AssumeRole"
  }]
}
EOF
aws iam create-role --role-name app-server-role --assume-role-policy-document file://trust.json \
  --tags Key=Purpose,Value=app
aws iam attach-role-policy --role-name app-server-role \
  --policy-arn arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess

# Cross-account trust: Principal {"AWS": "arn:aws:iam::OTHER_ACCOUNT:root"} + require MFA/ExternalId as needed
# Lambda: Principal {"Service": "lambda.amazonaws.com"}

aws iam list-roles --query 'Roles[?!starts_with(RoleName, `AWSServiceRole`)].[RoleName,Arn]' --output table
aws iam get-role --role-name app-server-role
aws iam update-assume-role-policy --role-name app-server-role --policy-document file://trust.json

# Delete role: detach policies + delete inline + remove from instance profiles first
```

## Policies

```bash
# Managed policy from JSON
cat > s3-write.json <<'EOF'
{
  "Version": "2012-10-17",
  "Statement": [{
    "Sid": "WriteToOneBucket",
    "Effect": "Allow",
    "Action": ["s3:PutObject", "s3:GetObject"],
    "Resource": "arn:aws:s3:::my-bucket/*"
  }]
}
EOF
aws iam create-policy --policy-name s3-write-mybucket --policy-document file://s3-write.json

# Read a policy (two hops: version list → document)
aws iam get-policy --policy-arn arn:aws:iam::123456789012:policy/s3-write-mybucket
aws iam get-policy-version --policy-arn arn:aws:iam::123456789012:policy/s3-write-mybucket \
  --version-id v1 --query 'PolicyVersion.Document'

# Update = create new version (max 5; delete old ones)
aws iam create-policy-version --policy-arn ARN --policy-document file://s3-write.json --set-as-default
aws iam list-policy-versions --policy-arn ARN
aws iam delete-policy-version --policy-arn ARN --version-id v1

# What's attached where
aws iam list-attached-role-policies --role-name app-server-role
aws iam list-attached-user-policies --user-name alice
aws iam list-entities-for-policy --policy-arn ARN     # reverse lookup

# Inline policies (avoid for anything reusable)
aws iam put-role-policy --role-name r --policy-name inline1 --policy-document file://p.json
aws iam get-role-policy --role-name r --policy-name inline1
```

## Testing

```bash
# Simulate before you grant/deny — no side effects
aws iam simulate-principal-policy \
  --policy-source-arn arn:aws:iam::123456789012:user/alice \
  --action-names s3:GetObject s3:PutObject \
  --resource-arns arn:aws:s3:::my-bucket/* \
  --query 'EvaluationResults[].[EvalActionName,EvalDecision]' --output table

# Decode cryptic UnauthorizedOperation errors
aws sts decode-authorization-message --encoded-message "$MSG" --query 'DecodedMessage' --output text | jq .

# IAM Access Analyzer: unused access + external exposure
aws accessanalyzer list-analyzers
aws accessanalyzer list-findings --analyzer-arn ARN --query 'findings[?status==`ACTIVE`]'
```

## MFA

```bash
aws iam create-virtual-mfa-device --virtual-mfa-device-name alice-mfa \
  --outfile qr.png --bootstrap-method QRCodePNG
aws iam enable-mfa-device --user-name alice --serial-number arn:aws:iam::123456789012:mfa/alice-mfa \
  --authentication-code1 123456 --authentication-code2 654321
# Get session token with MFA (needed when policies require MFA)
aws sts get-session-token --serial-number arn:aws:iam::123456789012:mfa/alice-mfa --token-code 123456
```

## Instance profiles

Roles for EC2 need a wrapper:

```bash
aws iam create-instance-profile --instance-profile-name app-server-profile
aws iam add-role-to-instance-profile --instance-profile-name app-server-profile --role-name app-server-role
# Attach to running instance:
aws ec2 associate-iam-instance-profile --instance-id i-0abc --iam-instance-profile Name=app-server-profile
```

## Recipes

**Read-only auditor user:** attach `arn:aws:iam::aws:policy/ReadOnlyAccess` (or `SecurityAudit`).

**CI deploy role:** trust GitHub OIDC provider, permission scoped to the exact resources deployed. Offer to scaffold the OIDC provider + trust policy.

**Break-glass admin:** separate user, AdministratorAccess, MFA enforced, keys disabled, alarms on use via CloudTrail (see references/monitoring.md).

**Least-privilege discovery:** run the workload with broad perms, then `aws iam generate-service-last-accessed-details --arn ROLE_ARN` → `get-service-last-accessed-details` to see what was actually used, then narrow.
