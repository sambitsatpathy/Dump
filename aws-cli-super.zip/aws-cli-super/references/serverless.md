# Serverless — Pattern Reference (Lambda, API Gateway, DynamoDB, SQS, SNS, Step Functions)

Pattern-level coverage: core verbs + the gotchas. For anything not shown, use `scaffolds/discovery.md`.

## Lambda

```bash
# Deploy from zip
zip -j fn.zip handler.py
aws lambda create-function --function-name my-fn --runtime python3.12 \
  --handler handler.lambda_handler --zip-file fileb://fn.zip \
  --role arn:aws:iam::123456789012:role/lambda-exec-role \
  --timeout 30 --memory-size 256 --tags CreatedBy=cli
# Exec role needs trust for lambda.amazonaws.com + AWSLambdaBasicExecutionRole (logs)

# Update
aws lambda update-function-code --function-name my-fn --zip-file fileb://fn.zip
aws lambda update-function-configuration --function-name my-fn \
  --environment 'Variables={LOG_LEVEL=debug}' --timeout 60
aws lambda wait function-updated --function-name my-fn   # config updates aren't instant

# Invoke (payload must be base64 or use this flag)
aws lambda invoke --function-name my-fn \
  --cli-binary-format raw-in-base64-out \
  --payload '{"key": "value"}' out.json && cat out.json
# Logs from that invoke: add --log-type Tail --query 'LogResult' --output text | base64 -d

aws lambda list-functions --query 'Functions[].[FunctionName,Runtime,MemorySize,LastModified]' --output table
aws lambda get-function --function-name my-fn
aws lambda delete-function --function-name my-fn
```

Container images: `--package-type Image --code ImageUri=ECR_URI` instead of zip. >50MB zips must go via S3: `--code S3Bucket=b,S3Key=k`.

## API Gateway (HTTP API v2 — cheaper/simpler than REST)

```bash
# One-liner API → Lambda
aws apigatewayv2 create-api --name my-api --protocol-type HTTP \
  --target arn:aws:lambda:us-east-1:123456789012:function:my-fn
# Grab ApiEndpoint from output. Then permit APIGW to call the fn:
aws lambda add-permission --function-name my-fn --statement-id apigw \
  --action lambda:InvokeFunction --principal apigateway.amazonaws.com \
  --source-arn "arn:aws:execute-api:us-east-1:123456789012:API_ID/*"

aws apigatewayv2 get-apis --query 'Items[].[ApiId,Name,ApiEndpoint]' --output table
# Routes/integrations/stages: create-route, create-integration, create-stage — discovery pattern applies
```

## DynamoDB

```bash
aws dynamodb create-table --table-name users \
  --attribute-definitions AttributeName=pk,AttributeType=S AttributeName=sk,AttributeType=S \
  --key-schema AttributeName=pk,KeyType=HASH AttributeName=sk,KeyType=RANGE \
  --billing-mode PAY_PER_REQUEST --tags Key=CreatedBy,Value=cli
aws dynamodb wait table-exists --table-name users

# CRUD — everything is typed JSON ({"S": string, "N": number-as-string, "BOOL": ...})
aws dynamodb put-item --table-name users --item '{"pk":{"S":"user#1"},"sk":{"S":"profile"},"name":{"S":"Alice"}}'
aws dynamodb get-item --table-name users --key '{"pk":{"S":"user#1"},"sk":{"S":"profile"}}'
aws dynamodb query --table-name users \
  --key-condition-expression 'pk = :p' --expression-attribute-values '{":p":{"S":"user#1"}}'
aws dynamodb update-item --table-name users --key '{"pk":{"S":"user#1"},"sk":{"S":"profile"}}' \
  --update-expression 'SET #n = :v' --expression-attribute-names '{"#n":"name"}' \
  --expression-attribute-values '{":v":{"S":"Bob"}}'
aws dynamodb delete-item --table-name users --key '{"pk":{"S":"user#1"},"sk":{"S":"profile"}}'

# scan = full table read = $$$ on big tables; prefer query. Export big tables: export-table-to-point-in-time → S3.
aws dynamodb delete-table --table-name users
```

## SQS

```bash
Q=$(aws sqs create-queue --queue-name my-queue --query 'QueueUrl' --output text)
aws sqs send-message --queue-url "$Q" --message-body '{"job": 1}'
aws sqs receive-message --queue-url "$Q" --max-number-of-messages 10 --wait-time-seconds 20
aws sqs delete-message --queue-url "$Q" --receipt-handle "$HANDLE"   # receive ≠ consume; must delete
aws sqs get-queue-attributes --queue-url "$Q" --attribute-names ApproximateNumberOfMessages
aws sqs purge-queue --queue-url "$Q"      # destructive, 60s cooldown
# Lambda trigger: aws lambda create-event-source-mapping --function-name my-fn --event-source-arn QUEUE_ARN
```

## SNS

```bash
T=$(aws sns create-topic --name alerts --query 'TopicArn' --output text)
aws sns subscribe --topic-arn "$T" --protocol email --notification-endpoint me@example.com  # requires email confirm
aws sns publish --topic-arn "$T" --subject "Alert" --message "disk full"
aws sns list-subscriptions-by-topic --topic-arn "$T"
```

## Step Functions

```bash
aws stepfunctions create-state-machine --name my-sm --role-arn ROLE_ARN \
  --definition file://statemachine.asl.json
aws stepfunctions start-execution --state-machine-arn ARN --input '{"key":"value"}'
aws stepfunctions describe-execution --execution-arn EXEC_ARN --query '[status,output]'
aws stepfunctions get-execution-history --execution-arn EXEC_ARN --reverse-order --max-items 10  # debug failures
```

## Standard serverless stack recipe

Lambda + HTTP API + DynamoDB: create exec role (trust lambda, attach basic-execution + scoped dynamodb policy) → create table → create function with table name in env vars → create-api with target → add-permission. Offer to run as one scripted flow using `scaffolds/automation-scaffold.sh`.
