# EC2 — Compute Reference

Contents: [Inspect](#inspect) · [Launch](#launch) · [Lifecycle](#lifecycle) · [Connect](#connect) · [Security groups](#security-groups) · [Key pairs](#key-pairs) · [EBS volumes & snapshots](#ebs) · [AMIs](#amis) · [Spot](#spot) · [Cleanup](#cleanup)

## Inspect

```bash
# All instances, human view
aws ec2 describe-instances \
  --query 'Reservations[].Instances[].{ID:InstanceId,Type:InstanceType,State:State.Name,Name:Tags[?Key==`Name`]|[0].Value,IP:PublicIpAddress,AZ:Placement.AvailabilityZone}' \
  --output table

# Only running
aws ec2 describe-instances --filters "Name=instance-state-name,Values=running" \
  --query 'Reservations[].Instances[].[InstanceId,InstanceType,PublicIpAddress]' --output text

# By tag
aws ec2 describe-instances --filters "Name=tag:Environment,Values=prod"

# One instance, everything
aws ec2 describe-instances --instance-ids i-0abc123 --output yaml

# Instance types available + pricing attributes
aws ec2 describe-instance-types --filters "Name=vcpu-info.default-vcpus,Values=4" \
  --query 'InstanceTypes[].[InstanceType,MemoryInfo.SizeInMiB]' --output table
```

`--filters` runs server-side (fast, less data); `--query` runs client-side (shapes output). Combine both.

## Launch

Minimum viable launch:

```bash
# Find latest Amazon Linux 2023 AMI (never hardcode AMI IDs — they differ per region)
AMI=$(aws ssm get-parameter --name /aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64 \
  --query 'Parameter.Value' --output text)

aws ec2 run-instances \
  --image-id "$AMI" \
  --instance-type t3.micro \
  --key-name my-key \
  --security-group-ids sg-0abc123 \
  --subnet-id subnet-0abc123 \
  --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=my-server},{Key=CreatedBy,Value=cli}]' \
  --count 1
```

Ubuntu latest: SSM path `/aws/service/canonical/ubuntu/server/24.04/stable/current/amd64/hvm/ebs-gp3/ami-id`.

Useful launch add-ons:

```bash
  --user-data file://bootstrap.sh                 # cloud-init script
  --iam-instance-profile Name=my-instance-role    # give it AWS permissions
  --block-device-mappings 'DeviceName=/dev/xvda,Ebs={VolumeSize=50,VolumeType=gp3}' \
  --metadata-options 'HttpTokens=required'        # IMDSv2 only — always set this
  --associate-public-ip-address                   # or --no-associate-public-ip-address
```

Wait until it's actually up:

```bash
aws ec2 wait instance-running --instance-ids i-0abc123
aws ec2 wait instance-status-ok --instance-ids i-0abc123   # slower, checks health
```

## Lifecycle

```bash
aws ec2 stop-instances  --instance-ids i-0abc123
aws ec2 start-instances --instance-ids i-0abc123
aws ec2 reboot-instances --instance-ids i-0abc123
aws ec2 terminate-instances --instance-ids i-0abc123        # DESTRUCTIVE — confirm first

# Test permission without acting (EC2-family superpower)
aws ec2 terminate-instances --instance-ids i-0abc123 --dry-run

# Resize (must be stopped)
aws ec2 stop-instances --instance-ids i-0abc123 && aws ec2 wait instance-stopped --instance-ids i-0abc123
aws ec2 modify-instance-attribute --instance-id i-0abc123 --instance-type '{"Value":"t3.large"}'
aws ec2 start-instances --instance-ids i-0abc123

# Termination protection
aws ec2 modify-instance-attribute --instance-id i-0abc123 --disable-api-termination
```

## Connect

```bash
# SSM Session Manager — no open ports, no key needed (needs SSM agent + role)
aws ssm start-session --target i-0abc123

# Classic SSH — get IP first
IP=$(aws ec2 describe-instances --instance-ids i-0abc123 \
  --query 'Reservations[0].Instances[0].PublicIpAddress' --output text)
ssh -i my-key.pem ec2-user@"$IP"

# Serial console / screenshot for boot debugging
aws ec2 get-console-output --instance-id i-0abc123 --query 'Output' --output text
```

## Security groups

```bash
aws ec2 create-security-group --group-name web-sg --description "web tier" --vpc-id vpc-0abc \
  --tag-specifications 'ResourceType=security-group,Tags=[{Key=Name,Value=web-sg}]'

# Open a port (prefer narrow CIDRs; 0.0.0.0/0 only for 80/443)
aws ec2 authorize-security-group-ingress --group-id sg-0abc \
  --protocol tcp --port 443 --cidr 0.0.0.0/0
aws ec2 authorize-security-group-ingress --group-id sg-0abc \
  --protocol tcp --port 22 --cidr 203.0.113.5/32          # SSH: single IP only

# Reference another SG instead of CIDR (app tier → db tier)
aws ec2 authorize-security-group-ingress --group-id sg-db \
  --protocol tcp --port 5432 --source-group sg-app

# Audit: anything open to the world?
aws ec2 describe-security-groups \
  --query 'SecurityGroups[?IpPermissions[?IpRanges[?CidrIp==`0.0.0.0/0`]]].[GroupId,GroupName]' --output table

aws ec2 revoke-security-group-ingress --group-id sg-0abc --protocol tcp --port 22 --cidr 0.0.0.0/0
aws ec2 delete-security-group --group-id sg-0abc          # fails if in use — good
```

## Key pairs

```bash
aws ec2 create-key-pair --key-name my-key --key-type ed25519 \
  --query 'KeyMaterial' --output text > my-key.pem && chmod 400 my-key.pem
aws ec2 import-key-pair --key-name my-key --public-key-material fileb://~/.ssh/id_ed25519.pub
aws ec2 describe-key-pairs
aws ec2 delete-key-pair --key-name my-key
```

## EBS

```bash
aws ec2 create-volume --availability-zone us-east-1a --size 100 --volume-type gp3 \
  --tag-specifications 'ResourceType=volume,Tags=[{Key=Name,Value=data-vol}]'
aws ec2 attach-volume --volume-id vol-0abc --instance-id i-0abc --device /dev/sdf
aws ec2 detach-volume --volume-id vol-0abc

# Grow live (then grow filesystem inside OS)
aws ec2 modify-volume --volume-id vol-0abc --size 200

# Snapshots
aws ec2 create-snapshot --volume-id vol-0abc --description "pre-upgrade" \
  --tag-specifications 'ResourceType=snapshot,Tags=[{Key=Name,Value=pre-upgrade}]'
aws ec2 describe-snapshots --owner-ids self --query 'Snapshots[].[SnapshotId,VolumeId,StartTime,Description]' --output table
aws ec2 create-volume --snapshot-id snap-0abc --availability-zone us-east-1a   # restore

# Orphaned volumes = money leak
aws ec2 describe-volumes --filters "Name=status,Values=available" \
  --query 'Volumes[].[VolumeId,Size,CreateTime]' --output table
```

## AMIs

```bash
aws ec2 create-image --instance-id i-0abc --name "app-v2-$(date +%Y%m%d)" --no-reboot
aws ec2 describe-images --owners self --query 'Images[].[ImageId,Name,CreationDate]' --output table
aws ec2 copy-image --source-image-id ami-0abc --source-region us-east-1 --region eu-west-1 --name app-v2-eu
# Deregister + delete backing snapshots (two steps!)
aws ec2 deregister-image --image-id ami-0abc
aws ec2 describe-snapshots --owner-ids self --filters "Name=description,Values=*ami-0abc*" \
  --query 'Snapshots[].SnapshotId' --output text | xargs -n1 aws ec2 delete-snapshot --snapshot-id
```

## Spot

```bash
# Cheapest way: run-instances with market options (no separate spot request API needed)
aws ec2 run-instances --image-id "$AMI" --instance-type t3.large \
  --instance-market-options 'MarketType=spot,SpotOptions={SpotInstanceType=one-time}' \
  --key-name my-key --subnet-id subnet-0abc

# Price history
aws ec2 describe-spot-price-history --instance-types t3.large \
  --product-descriptions "Linux/UNIX" --start-time "$(date -u +%Y-%m-%dT%H:%M:%S)" \
  --query 'SpotPriceHistory[].[AvailabilityZone,SpotPrice]' --output table
```

## Cleanup

Full teardown order (dependencies matter): terminate instances → wait → delete volumes → deregister AMIs + snapshots → delete security groups → delete key pairs. Always `describe-*` and show the user the hit list before any delete. See `scaffolds/safety-patterns.md`.
