# Discovery — Operating ANY AWS Service Without a Reference

The AWS CLI is self-documenting and uniformly shaped. Every one of the 300+ services follows the same grammar. This file is the universal fallback: with it, no reference file is ever strictly necessary.

## The grammar

```
aws <service> <verb>-<noun> [--parameters]
```

Verbs are predictable across all services:

| Verb | Meaning |
|---|---|
| `describe-*` / `get-*` | read one thing or details |
| `list-*` | enumerate things |
| `create-*` / `put-*` | make/upsert |
| `update-*` / `modify-*` | change |
| `delete-*` / `remove-*` / `terminate-*` | destroy |
| `tag-resource` / `untag-resource` / `list-tags-for-resource` | tags (most modern services) |
| `wait <condition>` | block until state reached (where supported) |

## The discovery sequence

```bash
aws help | less                          # 1. list every service
aws <service> help                       # 2. list every command in the service
aws <service> <command> help             # 3. full parameter docs + examples
aws <service> <command> --generate-cli-skeleton   # 4. JSON template of ALL input params
```

`--generate-cli-skeleton` is the power move for complex commands: dump the skeleton, fill it in, run with `--cli-input-json file://input.json`. No guessing at nested shorthand syntax.

```bash
aws ecs create-service --generate-cli-skeleton > svc.json
# edit svc.json
aws ecs create-service --cli-input-json file://svc.json
```

## Finding the right service/command

```bash
aws help | grep -i container            # which service? (ecs, ecr, eks...)
aws ecs help | grep -i task             # which command?
```

## Universal recon on an unknown account

```bash
# Everything tagged, all services, one call per region
aws resourcegroupstaggingapi get-resources \
  --query 'ResourceTagMappingList[].ResourceARN' --output text | tr '\t' '\n' | sort

# Per region loop
for r in $(aws ec2 describe-regions --query 'Regions[].RegionName' --output text); do
  echo "=== $r ==="
  aws resourcegroupstaggingapi get-resources --region "$r" \
    --query 'ResourceTagMappingList[].ResourceARN' --output text | tr '\t' '\n'
done
```

## Universal patterns that transfer everywhere

- **IDs vs names vs ARNs**: `describe`/`list` first to get the identifier; never guess format.
- **Eventual consistency**: after create, use `aws <service> wait ...` if available, else poll `describe` for status.
- **Shorthand vs JSON**: any `--option Key=V,Key2=V2` shorthand can also be written as JSON. When shorthand fights you, switch to JSON or skeleton.
- **fileb:// vs file://**: binary payloads (zips, images) need `fileb://`.
- **Tags on create**: most services accept `--tags`; EC2-family uses `--tag-specifications 'ResourceType=X,Tags=[...]'`.
- **Deletes have dependency order**: list attachments/children first; AWS refuses to delete in-use things — treat that error as a map to what remains.

## Worked example: unknown service in 60 seconds (ECR)

```bash
aws ecr help                                       # spot create-repository, get-login-password
aws ecr create-repository --repository-name myapp --query 'repository.repositoryUri' --output text
aws ecr get-login-password | docker login --username AWS --password-stdin ACCOUNT.dkr.ecr.us-east-1.amazonaws.com
docker push ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/myapp:latest
aws ecr list-images --repository-name myapp
```

Same sequence works for any service: help → find verbs → describe → act.
