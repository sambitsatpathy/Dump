# Query Patterns — JMESPath Cookbook for --query

`--query` shapes output client-side using JMESPath. Works on every command. Combine with `--output text` for scripts, `--output table` for humans.

## Core moves

```bash
# Project fields into a list of lists (→ table/text rows)
--query 'Reservations[].Instances[].[InstanceId,State.Name]'

# Project into named objects (→ table with headers)
--query 'Reservations[].Instances[].{ID:InstanceId,State:State.Name}'

# First element
--query 'Reservations[0].Instances[0].PublicIpAddress'

# Flatten nested lists: [] flattens one level
--query 'Reservations[].Instances[]'
```

## Filtering with [? ]

```bash
# String equality — literals in BACKTICKS
--query 'Volumes[?State==`available`].VolumeId'

# Numeric comparison — numbers also in backticks
--query 'Contents[?Size > `104857600`].[Key,Size]'

# Contains / starts_with
--query 'Roles[?contains(RoleName, `admin`)].RoleName'
--query 'Buckets[?starts_with(Name, `prod-`)].Name'

# Negation and AND/OR
--query 'Roles[?!starts_with(RoleName, `AWSServiceRole`)].RoleName'
--query 'Instances[?State.Name==`running` && InstanceType==`t3.micro`]'

# Date comparison (ISO strings compare lexically)
--query 'Snapshots[?StartTime<=`2026-01-01`].SnapshotId'
```

## The tag extraction idiom (memorize this)

Tags are a list of {Key,Value} — getting "the Name tag" needs a filter + pipe:

```bash
--query 'Reservations[].Instances[].{ID:InstanceId,Name:Tags[?Key==`Name`]|[0].Value}'
```

`Tags[?Key==\`Name\`]` filters to matching tags (a list), `|[0]` takes the first, `.Value` extracts.

## Functions

```bash
--query 'length(Reservations[].Instances[])'                 # count
--query 'sort_by(Volumes, &Size)[].{ID:VolumeId,GB:Size}'    # sort ascending
--query 'reverse(sort_by(Snapshots, &StartTime))[:5]'        # 5 newest
--query 'sum(Contents[].Size)'                               # total bytes
--query 'max_by(Datapoints, &Timestamp).Average'             # latest datapoint
```

## Slicing

```bash
--query 'Functions[:10]'      # first 10
--query 'Events[-5:]'         # last 5
```

## Shell quoting rules

- Wrap the whole expression in **single quotes**.
- JMESPath literals use **backticks** inside.
- If the expression itself needs a single quote, use double quotes outside and escape backticks: `--query "Volumes[?State==\`available\`]"`.

## When JMESPath hurts, use jq

JMESPath can't do multi-step joins, grouping, or arithmetic between fields. Bail out:

```bash
aws ec2 describe-instances --output json | jq -r '
  .Reservations[].Instances[] | select(.State.Name=="running") |
  [.InstanceId, (.Tags // [] | from_entries.Name // "-")] | @tsv'
```

## Server-side vs client-side

`--filters` (EC2-family) and `--prefix`/`--max-items` reduce data *before* it's sent — always prefer them, then polish with `--query`. `--query` alone still downloads everything.
