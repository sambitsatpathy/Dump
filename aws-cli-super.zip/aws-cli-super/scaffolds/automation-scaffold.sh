#!/usr/bin/env bash
# automation-scaffold.sh — starting point for any AWS CLI script.
# Copy, rename, fill in main(). Provides: strict mode, identity check,
# profile/region flags, dry-run mode, confirmation gate, retry wrapper,
# pagination helper, structured logging, cleanup trap.

set -Eeuo pipefail

# ---------- config ----------
PROFILE="${AWS_PROFILE:-default}"
REGION="${AWS_DEFAULT_REGION:-us-east-1}"
DRY_RUN=false
ASSUME_YES=false
LOG_FILE=""

usage() {
  cat <<EOF
Usage: $(basename "$0") [-p profile] [-r region] [-n] [-y] [-l logfile]
  -p  AWS profile (default: \$AWS_PROFILE or 'default')
  -r  AWS region  (default: \$AWS_DEFAULT_REGION or us-east-1)
  -n  dry-run: print mutating commands instead of running them
  -y  assume yes: skip confirmation prompts (for CI)
  -l  also append logs to file
EOF
  exit 1
}

while getopts "p:r:nyl:h" opt; do
  case "$opt" in
    p) PROFILE="$OPTARG" ;;
    r) REGION="$OPTARG" ;;
    n) DRY_RUN=true ;;
    y) ASSUME_YES=true ;;
    l) LOG_FILE="$OPTARG" ;;
    *) usage ;;
  esac
done

AWS_ARGS=(--profile "$PROFILE" --region "$REGION" --no-cli-pager)

# ---------- logging ----------
log()  { local msg="[$(date -u +%H:%M:%S)] $*"; echo "$msg" >&2; [ -n "$LOG_FILE" ] && echo "$msg" >> "$LOG_FILE" || true; }
die()  { log "ERROR: $*"; exit 1; }

# ---------- error context on any failure ----------
trap 'log "FAILED at line $LINENO: $BASH_COMMAND"' ERR

# ---------- cleanup (register teardown actions as you create resources) ----------
CLEANUP_CMDS=()
add_cleanup() { CLEANUP_CMDS+=("$*"); }
run_cleanup() {
  for ((i=${#CLEANUP_CMDS[@]}-1; i>=0; i--)); do   # reverse order
    log "cleanup: ${CLEANUP_CMDS[$i]}"
    eval "${CLEANUP_CMDS[$i]}" || log "cleanup step failed (continuing)"
  done
}
# Uncomment to auto-clean on exit (for ephemeral-resource scripts):
# trap run_cleanup EXIT

# ---------- guards ----------
confirm() {
  $ASSUME_YES && return 0
  read -r -p "$1 [y/N] " ans
  [[ "$ans" =~ ^[Yy]$ ]] || die "aborted by user"
}

# aws_ro: read-only calls, always execute
aws_ro() { aws "${AWS_ARGS[@]}" "$@"; }

# aws_mut: mutating calls, honor dry-run
aws_mut() {
  if $DRY_RUN; then
    log "DRY-RUN: aws ${AWS_ARGS[*]} $*"
  else
    aws "${AWS_ARGS[@]}" "$@"
  fi
}

# retry with exponential backoff for throttling
retry() {
  local max=5 delay=2 n=0
  until "$@"; do
    n=$((n+1))
    (( n >= max )) && die "retry: giving up after $max attempts: $*"
    log "retry $n/$max in ${delay}s: $*"
    sleep "$delay"; delay=$((delay*2))
  done
}

# paginate: collect all pages of a list call into one JSON array
# usage: paginate 'Volumes' ec2 describe-volumes --filters ...
paginate() {
  local jpath="$1"; shift
  local token="" out all="[]"
  while :; do
    if [ -n "$token" ]; then
      out=$(aws_ro "$@" --starting-token "$token" --output json)
    else
      out=$(aws_ro "$@" --output json)
    fi
    all=$(jq -s '.[0] + .[1]' <(echo "$all") <(echo "$out" | jq ".$jpath // []"))
    token=$(echo "$out" | jq -r '.NextToken // empty')
    [ -z "$token" ] && break
  done
  echo "$all"
}

# ---------- identity check (always first) ----------
preflight() {
  command -v aws >/dev/null || die "aws CLI not installed"
  command -v jq  >/dev/null || die "jq not installed"
  local ident
  ident=$(aws_ro sts get-caller-identity --output json) || die "credentials invalid for profile '$PROFILE'"
  log "identity: $(echo "$ident" | jq -r '.Arn') | account: $(echo "$ident" | jq -r '.Account') | region: $REGION"
  confirm "Proceed as this identity?"
}

# ---------- main ----------
main() {
  preflight

  # ===== YOUR LOGIC HERE =====
  # Examples of the idioms:
  #
  # vols=$(paginate 'Volumes' ec2 describe-volumes --filters "Name=status,Values=available")
  # echo "$vols" | jq -r '.[].VolumeId'
  #
  # confirm "Delete $(echo "$vols" | jq length) volumes?"
  # echo "$vols" | jq -r '.[].VolumeId' | while read -r id; do
  #   retry aws_mut ec2 delete-volume --volume-id "$id"
  #   log "deleted $id"
  # done
  #
  # ID=$(aws_mut ec2 run-instances ... --query 'Instances[0].InstanceId' --output text)
  # add_cleanup "aws ${AWS_ARGS[*]} ec2 terminate-instances --instance-ids $ID"
  # ===========================

  log "done"
}

main "$@"
