# Safety Patterns — Destructive Ops & Production Discipline

Rules for any command that mutates or destroys. Non-negotiable when acting on someone's real account.

## The three-step ritual for every destructive op

1. **Enumerate**: run the `describe-*`/`list-*` version first and show the user exactly what will be hit.
2. **Confirm**: get explicit user confirmation on that specific list. "Delete all unused volumes" → show the volume IDs, sizes, create dates → wait for yes.
3. **Execute + verify**: run the delete, then re-describe to prove it's gone.

```bash
# Pattern
aws ec2 describe-volumes --filters "Name=status,Values=available" \
  --query 'Volumes[].[VolumeId,Size,CreateTime]' --output table
# → show user → confirm →
aws ec2 delete-volume --volume-id vol-0abc
aws ec2 describe-volumes --volume-ids vol-0abc 2>&1 | grep -q NotFound && echo "gone"
```

## Dry-run where it exists

EC2-family commands (`ec2`, some others) support `--dry-run`: validates permissions + parameters, does nothing.

```bash
aws ec2 terminate-instances --instance-ids i-0abc --dry-run
# "DryRunOperation" error = would have succeeded. "UnauthorizedOperation" = no permission.
```

`aws s3` transfer commands support `--dryrun` (no hyphen). ALWAYS use it before `sync --delete` or `rm --recursive`.

## Escalating caution by blast radius

| Risk | Examples | Extra step |
|---|---|---|
| Reversible | stop instance, deactivate key | normal ritual |
| Recoverable with effort | delete with snapshot/final-backup available | take backup first, verify it exists |
| Irreversible | terminate instance, delete-objects on unversioned bucket, delete IAM user, release EIP | confirm with exact resource IDs echoed back; prefer disable-first-delete-later |
| Account-threatening | delete CloudTrail, detach admin from break-glass, modify SCPs | pause and question the request itself |

## Prefer disable → wait → delete

- Access keys: `update-access-key --status Inactive` for a week, then delete.
- Security group rules: revoke and monitor before deleting the group.
- IAM policies: detach before delete; simulate first (`iam simulate-principal-policy`).
- RDS: `--final-db-snapshot-identifier` unless the user explicitly says throwaway.

## Guardrails to offer proactively

```bash
# Termination protection on important instances
aws ec2 modify-instance-attribute --instance-id i-0abc --disable-api-termination
# RDS deletion protection
aws rds modify-db-instance --db-instance-identifier mydb --deletion-protection
# S3: versioning = undo button
aws s3api put-bucket-versioning --bucket b --versioning-configuration Status=Enabled
# MFA-delete, object lock for the truly paranoid
```

## Batch destruction: never pipe blind

Bad: `... --output text | xargs aws ec2 delete-...` in one line, unreviewed.

Good: write IDs to a file, show the file, count it, then loop:

```bash
aws ec2 describe-snapshots --owner-ids self \
  --query 'Snapshots[?StartTime<=`2025-01-01`].SnapshotId' --output text | tr '\t' '\n' > victims.txt
wc -l victims.txt && cat victims.txt        # ← user reviews this
while read -r id; do
  aws ec2 delete-snapshot --snapshot-id "$id" && echo "deleted $id" || echo "FAILED $id"
done < victims.txt
```

## Production identity hygiene

- Echo `aws sts get-caller-identity` and the active `--profile`/region before any mutating session. Wrong-account incidents start with skipped whoami.
- Never write credentials into scripts, chat, or files. Reference profiles/env vars.
- If the user pastes an access key + secret into chat, tell them it's now exposed and should be rotated (`iam create-access-key` → switch → `delete-access-key`).

## Rate limits during bulk ops

Add `retry_mode = adaptive` + `max_attempts = 5` in `~/.aws/config`, and sleep between calls in loops (`sleep 0.2`) to avoid throttling everyone else on the account.
