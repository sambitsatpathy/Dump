---
name: aws-cli-super
description: End-to-end AWS CLI operations skill covering account access, resource management, and automation across all AWS services. Use this skill whenever the user wants to inspect, create, modify, delete, or automate anything in an AWS account via the command line — EC2 instances, S3 buckets, IAM users/roles/policies, VPC networking, Lambda, RDS, CloudWatch, or any other AWS service. Trigger on any mention of "aws cli", "aws command", specific AWS services (EC2, S3, IAM, VPC, Lambda, RDS, etc.), AWS credentials/profiles, or tasks like "list my instances", "create a bucket", "audit IAM", "set up a VPC", "check my AWS bill/resources". Also use for writing AWS automation scripts, one-liners, or troubleshooting AWS CLI errors — even if the user doesn't say "CLI" explicitly but wants terminal-based AWS work.
---

# AWS CLI Super Skill

Comprehensive operating manual for working with an AWS account through the AWS CLI (v2). Deep coverage of core services (EC2, S3, IAM, VPC) lives in `references/`. Universal patterns for *any* AWS service live in `scaffolds/`. Read only what the task needs.

## How to use this skill

1. Confirm auth works (section below) before running task commands.
2. Route to the right reference file:

| Task involves | Read |
|---|---|
| Compute: instances, AMIs, key pairs, security groups, EBS, spot | `references/ec2.md` |
| Object storage: buckets, objects, sync, presign, lifecycle, static sites | `references/s3.md` |
| Identity: users, roles, policies, MFA, access keys, auditing | `references/iam.md` |
| Networking: VPCs, subnets, route tables, NAT, gateways, peering, endpoints | `references/vpc.md` |
| Lambda, API Gateway, DynamoDB, SQS, SNS, Step Functions | `references/serverless.md` |
| RDS, Redshift, Glue, Athena | `references/data.md` |
| CloudWatch, CloudTrail, logs, alarms, cost | `references/monitoring.md` |
| Any other service, or unsure how a command works | `scaffolds/discovery.md` |
| Filtering/formatting output (JMESPath) | `scaffolds/query-patterns.md` |
| Destructive ops, production safety, dry runs | `scaffolds/safety-patterns.md` |
| Writing a reusable script | `scaffolds/automation-scaffold.sh` |

3. For anything destructive (delete, terminate, detach, revoke), follow `scaffolds/safety-patterns.md` — always show the user exactly what will be affected and get confirmation first.

## Setup and authentication

Check CLI presence and identity first:

```bash
aws --version                      # expect aws-cli/2.x
aws sts get-caller-identity        # who am I? account, ARN, user id
aws configure list                 # active profile, region, cred source
```

If `get-caller-identity` fails, credentials aren't set. Options, best first:

```bash
# SSO (recommended for humans)
aws configure sso                  # interactive; creates named profile
aws sso login --profile myprofile  # refresh session

# Static keys (automation/legacy)
aws configure --profile myprofile  # prompts for key, secret, region, output

# Environment variables (CI, one-off)
export AWS_ACCESS_KEY_ID=... AWS_SECRET_ACCESS_KEY=... AWS_DEFAULT_REGION=us-east-1
```

Config lives in `~/.aws/config` and `~/.aws/credentials`. Named profiles let one machine hold many accounts:

```bash
aws s3 ls --profile prod
export AWS_PROFILE=prod            # set default for the session
```

Assume a role (cross-account or elevated):

```bash
aws sts assume-role --role-arn arn:aws:iam::123456789012:role/Admin \
  --role-session-name work | \
  jq -r '.Credentials | "export AWS_ACCESS_KEY_ID=\(.AccessKeyId)\nexport AWS_SECRET_ACCESS_KEY=\(.SecretAccessKey)\nexport AWS_SESSION_TOKEN=\(.SessionToken)"'
```

Or define role profiles in `~/.aws/config` so the CLI assumes automatically:

```ini
[profile prod-admin]
role_arn = arn:aws:iam::123456789012:role/Admin
source_profile = default
region = us-east-1
```

## Universal flags — work on every command

```bash
--profile NAME          # which credentials
--region us-west-2      # override region
--output json|table|text|yaml
--query 'JMESPath'      # server-side-ish filtering of output (see scaffolds/query-patterns.md)
--no-cli-pager          # don't open less; essential in scripts
--dry-run               # EC2-family only: test permissions without acting
--debug                 # full request/response logging for troubleshooting
```

## Pagination — the #1 silent bug

List commands return at most one page by default in some modes. The CLI v2 auto-paginates for most `list-*`/`describe-*` calls, but when writing scripts always be explicit:

```bash
# Let CLI handle it (preferred)
aws s3api list-objects-v2 --bucket my-bucket --query 'Contents[].Key' --output text

# Manual paging when needed
aws ec2 describe-instances --max-items 100 --starting-token "$NEXT_TOKEN"
```

`--no-paginate` disables auto-pagination — almost never what you want.

## Output discipline

- Interactive exploration: `--output table` for humans.
- Scripting: `--output text --query ...` gives clean whitespace-separated values; `--output json` + `jq` for anything nested.
- Never parse `table` output in a script.

## Error handling essentials

| Error | Meaning | Fix |
|---|---|---|
| `ExpiredToken` | SSO/STS session dead | `aws sso login` or re-assume role |
| `AccessDenied` / `UnauthorizedOperation` | IAM says no | check policy; use `--dry-run` on EC2 to test; decode with `aws sts decode-authorization-message` |
| `Throttling` / `RequestLimitExceeded` | too many calls | retry with backoff (built into scaffold script) |
| `InvalidClientTokenId` | bad/deleted keys | re-run `aws configure` |
| Hangs then prints nothing | pager or wrong region | add `--no-cli-pager`, check `--region` |

Set retries globally in `~/.aws/config`:

```ini
[default]
retry_mode = adaptive
max_attempts = 5
```

## Account-wide reconnaissance (fast situational awareness)

```bash
aws sts get-caller-identity
aws ec2 describe-regions --query 'Regions[].RegionName' --output text
# What exists where — Resource Groups Tagging API sees ~everything tagged
aws resourcegroupstaggingapi get-resources --query 'ResourceTagMappingList[].ResourceARN' --output text
# Untagged/all resources per region: use service list calls (see references)
```

## Ground rules baked into every reference

- Show commands before running them when they mutate state.
- Tag everything created: `--tags Key=CreatedBy,Value=claude Key=Purpose,Value=<task>` (syntax varies per service; each reference shows it).
- Prefer `--dry-run` where supported; prefer describing before deleting.
- Region matters: resources are invisible from the wrong region. When something is "missing," check region first.
