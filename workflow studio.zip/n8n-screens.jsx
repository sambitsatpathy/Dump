// n8n-style screens: Home, Queue, Nodes, Admin, plus overlays

// ─── Mock Data ────────────────────────────────────────────────────────────────
const QUEUE_DATA = [
  { id:'q1', name:'order-form',        type:'Node',     version:'v1.2.0', submittedBy:'alice', submittedAt:'2026-05-18 09:14', status:'IN_REVIEW',         category:'UI'    },
  { id:'q2', name:'validate-order',    type:'Node',     version:'v2.1.0', submittedBy:'bob',   submittedAt:'2026-05-18 10:32', status:'SUBMITTED',         category:'Logic' },
  { id:'q3', name:'submit-order',      type:'Workflow', version:'v3.0.0', submittedBy:'alice', submittedAt:'2026-05-17 16:05', status:'CHANGES_REQUESTED', category:'—'    },
  { id:'q4', name:'payment-gateway',   type:'Node',     version:'v1.4.0', submittedBy:'carol', submittedAt:'2026-05-17 11:20', status:'SUBMITTED',         category:'Infra' },
  { id:'q5', name:'audit-log',         type:'Node',     version:'v1.2.0', submittedBy:'bob',   submittedAt:'2026-05-16 14:55', status:'REJECTED',          category:'Data'  },
  { id:'q6', name:'send-confirmation', type:'Node',     version:'v1.1.0', submittedBy:'carol', submittedAt:'2026-05-15 08:30', status:'IN_REVIEW',         category:'Data'  },
];

const NOTIFICATIONS = [
  { id:'n1', unread:true,  type:'Submission', title:'alice submitted order-form v1.2.0 for review', time:'2m ago',  tone:'info'    },
  { id:'n2', unread:true,  type:'Comment',    title:'bob commented on validate-order v2.1.0',       time:'15m ago', tone:'warning' },
  { id:'n3', unread:true,  type:'Upgrade',    title:'payment-gateway v1.4.0 is now APPROVED',       time:'1h ago',  tone:'success' },
  { id:'n4', unread:false, type:'Rejection',  title:'audit-log v1.1.1 was rejected by checker-dan',time:'3h ago',  tone:'danger'  },
  { id:'n5', unread:false, type:'Approval',   title:'route-request v1.0.0 was approved',            time:'1d ago',  tone:'success' },
  { id:'n6', unread:false, type:'Comment',    title:'carol replied to your comment on submit-order', time:'2d ago', tone:'warning' },
];

// ─── HOME ─────────────────────────────────────────────────────────────────────
function HomeScreen({ onNavigate }) {
  const stats = [
    { label:'Total workflows', value:'12', delta:'+2 this week', color:'#525457', icon:
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="2" y="2" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.4"/><rect x="9" y="2" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.4"/><rect x="2" y="9" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.4"/><rect x="9" y="9" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.4"/></svg>
    },
    { label:'Active nodes',    value:'48', delta:'+5 this week', color:'#525457', icon:
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><polygon points="8,2 14,6 14,12 8,15 2,12 2,6" stroke="currentColor" strokeWidth="1.4" fill="none"/></svg>
    },
    { label:'Pending review',  value:'6',  delta:'2 overdue',    color:'#f5a623', icon:
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6" stroke="currentColor" strokeWidth="1.4"/><path d="M8 5v3l2 1.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>
    },
    { label:'Approved',        value:'31', delta:'94% pass rate', color:'#10b981', icon:
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6" stroke="currentColor" strokeWidth="1.4"/><path d="M5 8l2 2 4-4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>
    },
  ];

  const recent = [
    { user:'alice',       action:'submitted',  spec:'order-form v1.2.0',       time:'2m ago',  status:'IN_REVIEW' },
    { user:'bob',         action:'commented on', spec:'validate-order v2.1.0', time:'15m ago', status:'IN_REVIEW' },
    { user:'carol',       action:'approved',   spec:'payment-gateway v1.4.0',  time:'1h ago',  status:'APPROVED'  },
    { user:'checker-dan', action:'rejected',   spec:'audit-log v1.1.1',        time:'3h ago',  status:'REJECTED'  },
    { user:'dan',         action:'approved',   spec:'route-request v1.0.0',    time:'1d ago',  status:'APPROVED'  },
  ];

  const workflows = [
    { name:'submit-order',     nodes:6, status:'APPROVED',  version:'v3.0.0', updated:'10:32' },
    { name:'checkout-flow',    nodes:9, status:'IN_REVIEW', version:'v2.4.1', updated:'Yest.' },
    { name:'user-onboarding',  nodes:4, status:'DRAFT',     version:'v1.0.0', updated:'2d ago' },
    { name:'refund-process',   nodes:5, status:'APPROVED',  version:'v1.8.0', updated:'4d ago' },
  ];

  const statusColor = s => STATUS_META[s]?.color || 'neutral';

  return (
    <div style={{ flex:1, overflow:'auto', padding:'24px 32px', background:'#f7f7f5' }}>
      {/* Page header */}
      <div style={{ marginBottom:24, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div>
          <h1 style={{ fontSize:24, fontWeight:700, color:'#1f1f1f', marginBottom:4 }}>Welcome back, Alice</h1>
          <p style={{ fontSize:13, color:'#525457' }}>Here's what's happening with your workflows today.</p>
        </div>
        <div style={{ display:'flex', gap:8 }}>
          <Button variant="secondary" onClick={()=>onNavigate('queue')}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="5" stroke="currentColor" strokeWidth="1.5"/><path d="M7 4v3l2 1.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
            Review queue
            <Tag color="warning" size="sm">6</Tag>
          </Button>
          <Button variant="primary" onClick={()=>onNavigate('flow')}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 2v10M2 7h10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
            New workflow
          </Button>
        </div>
      </div>

      {/* KPI row */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:14, marginBottom:24 }}>
        {stats.map(s => (
          <Card key={s.label} style={{ padding:'16px 18px' }}>
            <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:12, color:s.color }}>
              {s.icon}
              <span style={{ fontSize:12, fontWeight:500, color:'#525457' }}>{s.label}</span>
            </div>
            <div style={{ fontSize:30, fontWeight:700, color:'#1f1f1f', lineHeight:1, marginBottom:6 }}>{s.value}</div>
            <div style={{ fontSize:11.5, color:s.color, fontWeight:500 }}>{s.delta}</div>
          </Card>
        ))}
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1.4fr 1fr', gap:16 }}>
        {/* Workflows table */}
        <Card style={{ padding:0, overflow:'hidden' }}>
          <div style={{ padding:'14px 18px', borderBottom:'1px solid #e4e4e7', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <h3 style={{ fontSize:14, fontWeight:600 }}>Your workflows</h3>
            <Button variant="tertiary" size="sm" onClick={()=>onNavigate('flow')}>View all →</Button>
          </div>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
            <thead>
              <tr style={{ borderBottom:'1px solid #e4e4e7', background:'#fafafa' }}>
                {['Name','Nodes','Status','Version','Updated'].map(c=>(
                  <th key={c} style={{ padding:'9px 18px', textAlign:'left', fontSize:11, fontWeight:600, color:'#909399', textTransform:'uppercase', letterSpacing:'0.04em' }}>{c}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {workflows.map(w => (
                <tr key={w.name} onClick={()=>onNavigate('flow')} style={{ borderBottom:'1px solid #f0f0f2', cursor:'pointer' }}
                  onMouseEnter={e=>e.currentTarget.style.background='#fafafa'}
                  onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                  <td style={{ padding:'10px 18px', fontWeight:600, color:'#1f1f1f' }}>{w.name}</td>
                  <td style={{ padding:'10px 18px', color:'#525457' }}>{w.nodes} nodes</td>
                  <td style={{ padding:'10px 18px' }}>
                    <Tag color={statusColor(w.status)} size="sm">
                      <Dot color={STATUS_META[w.status]?.dot} size={6} /> {STATUS_META[w.status]?.label}
                    </Tag>
                  </td>
                  <td style={{ padding:'10px 18px', fontFamily:'ui-monospace,monospace', fontSize:11.5, color:'#525457' }}>{w.version}</td>
                  <td style={{ padding:'10px 18px', color:'#909399', fontSize:11.5 }}>{w.updated}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        {/* Activity feed */}
        <Card style={{ padding:0, overflow:'hidden' }}>
          <div style={{ padding:'14px 18px', borderBottom:'1px solid #e4e4e7' }}>
            <h3 style={{ fontSize:14, fontWeight:600 }}>Recent activity</h3>
          </div>
          <div>
            {recent.map((a,i) => (
              <div key={i} style={{ padding:'11px 18px', borderBottom:'1px solid #f0f0f2', display:'flex', gap:11, alignItems:'flex-start' }}>
                <div style={{
                  width:28, height:28, borderRadius:'50%', flexShrink:0,
                  background:'#ff6d5a', color:'#fff', fontSize:11, fontWeight:700,
                  display:'flex', alignItems:'center', justifyContent:'center',
                }}>{a.user[0].toUpperCase()}</div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontSize:12.5, lineHeight:1.45 }}>
                    <strong>{a.user}</strong> <span style={{color:'#525457'}}>{a.action}</span>{' '}
                    <span style={{fontFamily:'ui-monospace,monospace',fontSize:11.5}}>{a.spec}</span>
                  </div>
                  <div style={{ marginTop:3, display:'flex', alignItems:'center', gap:6 }}>
                    <Dot color={STATUS_META[a.status]?.dot} size={6} />
                    <span style={{ fontSize:11, color:'#909399' }}>{a.time}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

// ─── REVIEW QUEUE ─────────────────────────────────────────────────────────────
function ReviewQueue({ onOpenReview }) {
  const [search, setSearch] = React.useState('');
  const [statusF, setStatusF] = React.useState('');
  const [typeF, setTypeF] = React.useState('');
  const filtered = QUEUE_DATA.filter(r => {
    if (search && !r.name.toLowerCase().includes(search.toLowerCase())) return false;
    if (statusF && r.status !== statusF) return false;
    if (typeF && r.type !== typeF) return false;
    return true;
  });
  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', background:'#f7f7f5' }}>
      <div style={{ padding:'22px 32px 16px', borderBottom:'1px solid #e4e4e7', background:'#fff', flexShrink:0 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <div>
            <h1 style={{ fontSize:22, fontWeight:700, color:'#1f1f1f', marginBottom:3 }}>Review queue</h1>
            <p style={{ fontSize:12.5, color:'#525457' }}>Submissions waiting for your review</p>
          </div>
          <Tag color="warning" style={{padding:'4px 10px', fontSize:12}}>{QUEUE_DATA.filter(r=>['IN_REVIEW','SUBMITTED'].includes(r.status)).length} pending</Tag>
        </div>
      </div>
      <div style={{ padding:'12px 32px', display:'flex', gap:10, borderBottom:'1px solid #e4e4e7', background:'#fff', flexShrink:0 }}>
        <Input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search submissions…"
          startIcon={<svg width="13" height="13" viewBox="0 0 14 14" fill="none"><circle cx="6" cy="6" r="4.5" stroke="currentColor" strokeWidth="1.5"/><path d="M10 10l3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>}
          style={{ width:260 }} aria-label="Search" />
        <Select value={statusF} options={['IN_REVIEW','SUBMITTED','CHANGES_REQUESTED','REJECTED','APPROVED']} onChange={setStatusF} placeholder="Status" aria-label="Status" style={{width:160}}/>
        <Select value={typeF} options={['Node','Workflow']} onChange={setTypeF} placeholder="Type" aria-label="Type" style={{width:120}}/>
        {(search||statusF||typeF) && <Button variant="tertiary" size="sm" onClick={()=>{setSearch('');setStatusF('');setTypeF('');}}>Clear filters</Button>}
      </div>
      <div style={{ flex:1, overflow:'auto', padding:'16px 32px' }}>
        <Card style={{ padding:0, overflow:'hidden' }}>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
            <thead>
              <tr style={{ background:'#fafafa', borderBottom:'1px solid #e4e4e7' }}>
                {['Name','Type','Version','Submitted by','Submitted at','Status',''].map(c=>(
                  <th key={c} style={{ padding:'10px 16px', textAlign:'left', fontSize:11, fontWeight:600, color:'#909399', textTransform:'uppercase', letterSpacing:'0.04em' }}>{c}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(row => (
                <tr key={row.id} onClick={()=>onOpenReview(row)} style={{ borderBottom:'1px solid #f0f0f2', cursor:'pointer' }}
                  onMouseEnter={e=>e.currentTarget.style.background='#fafafa'}
                  onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                  <td style={{ padding:'11px 16px', fontWeight:600 }}>{row.name}</td>
                  <td style={{ padding:'11px 16px', color:'#525457' }}>{row.type}</td>
                  <td style={{ padding:'11px 16px', fontFamily:'ui-monospace,monospace', fontSize:11.5 }}>{row.version}</td>
                  <td style={{ padding:'11px 16px' }}>
                    <span style={{ display:'inline-flex', alignItems:'center', gap:7 }}>
                      <span style={{ width:22, height:22, borderRadius:'50%', background:'#ff6d5a', color:'#fff', fontSize:10, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center' }}>{row.submittedBy[0].toUpperCase()}</span>
                      {row.submittedBy}
                    </span>
                  </td>
                  <td style={{ padding:'11px 16px', color:'#909399', fontSize:12 }}>{row.submittedAt}</td>
                  <td style={{ padding:'11px 16px' }}>
                    <Tag color={STATUS_META[row.status]?.color}>
                      <Dot color={STATUS_META[row.status]?.dot} size={6} />
                      {STATUS_META[row.status]?.label}
                    </Tag>
                  </td>
                  <td style={{ padding:'11px 16px', textAlign:'right' }}>
                    <Button variant="tertiary" size="sm">Open →</Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div style={{ padding:'48px 16px', textAlign:'center', color:'#909399', fontSize:13 }}>
              No submissions match the current filters.
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

// ─── NODE REGISTRY ────────────────────────────────────────────────────────────
function NodesScreen({ onOpenDetail }) {
  const nodes = [
    { id:'order-form',        category:'UI',       version:'v1.1.0', status:'APPROVED',          workflows:3, type:'order-form' },
    { id:'validate-order',    category:'Logic',    version:'v2.0.1', status:'IN_REVIEW',         workflows:2, type:'validate-order' },
    { id:'payment-gateway',   category:'Infra',    version:'v1.3.0', status:'APPROVED',          workflows:4, type:'payment-gateway', newerVersion:'v1.4.0' },
    { id:'send-confirmation', category:'Data',     version:'v1.0.2', status:'DRAFT',             workflows:1, type:'send-confirmation' },
    { id:'audit-log',         category:'Data',     version:'v1.1.1', status:'REJECTED',          workflows:2, type:'audit-log' },
    { id:'route-request',     category:'Logic',    version:'v1.0.0', status:'CHANGES_REQUESTED', workflows:1, type:'route-request' },
    { id:'webhook-trigger',   category:'Trigger',  version:'v1.0.0', status:'APPROVED',          workflows:8, type:'webhook-trigger' },
  ];
  const [cat, setCat] = React.useState('');
  const filtered = nodes.filter(n => !cat || n.category === cat);
  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', background:'#f7f7f5' }}>
      <div style={{ padding:'22px 32px 14px', background:'#fff', borderBottom:'1px solid #e4e4e7' }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <div>
            <h1 style={{ fontSize:22, fontWeight:700 }}>Node registry</h1>
            <p style={{ fontSize:12.5, color:'#525457' }}>Reusable specs you can drop into workflows</p>
          </div>
          <Button variant="primary"><span>+</span> New node</Button>
        </div>
      </div>
      <div style={{ padding:'12px 32px', background:'#fff', borderBottom:'1px solid #e4e4e7', display:'flex', gap:8 }}>
        {['','Trigger','UI','Logic','Infra','Data','External'].map(c=>(
          <button key={c||'all'} onClick={()=>setCat(c)} style={{
            padding:'5px 12px', borderRadius:14, fontSize:12, fontWeight:500,
            background: cat===c?'#1f1f1f':'#fff', color: cat===c?'#fff':'#525457',
            border: `1px solid ${cat===c?'#1f1f1f':'#dbdcdf'}`, cursor:'pointer',
            transition:'all 0.12s', fontFamily:'inherit',
          }}>{c || 'All categories'}</button>
        ))}
      </div>
      <div style={{ flex:1, overflow:'auto', padding:'18px 32px' }}>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(280px, 1fr))', gap:14 }}>
          {filtered.map(n => (
            <Card key={n.id} onClick={()=>onOpenDetail({ ...n, label:n.id, tags:[n.category] })} style={{ padding:14 }}>
              {/* Top row: icon + name/version + menu */}
              <div style={{ display:'flex', alignItems:'flex-start', gap:12, marginBottom:10 }}>
                <div style={{
                  width:44, height:44, borderRadius:6, flexShrink:0,
                  background: CAT_COLORS[n.category],
                  color:'#fff', display:'flex', alignItems:'center', justifyContent:'center',
                }}>
                  <svg width="24" height="24" viewBox="0 0 32 32">{NODE_ICONS[n.type] || NODE_ICONS.default}</svg>
                </div>
                <div style={{ flex:1, minWidth:0 }}>
                  <h4 style={{
                    fontSize:13.5, fontWeight:600, color:'#1f1f1f',
                    overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap',
                  }}>{n.id}</h4>
                  <div style={{ fontSize:11, color:'#909399', fontFamily:'ui-monospace,monospace', marginTop:2 }}>{n.version}</div>
                </div>
                <Menu items={[
                  { label:'View detail', icon:'⊙' },
                  { label:'Submit for review', icon:'↑' },
                  { label:'Duplicate as DRAFT', icon:'⎘' },
                  { divider:true },
                  { label:'View history', icon:'↺' },
                ]} trigger={<IconButton size={26} aria-label="More" style={{flexShrink:0}}><span>⋯</span></IconButton>} />
              </div>
              {/* Newer version banner (its own row, no crowding) */}
              {n.newerVersion && (
                <div style={{
                  marginBottom:10, padding:'5px 9px',
                  background:'#e8f5ed', border:'1px solid #c3e6cf', borderRadius:4,
                  fontSize:11, color:'#1a7a3e', display:'flex', alignItems:'center', gap:5,
                }}>
                  <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M6 2l3 4H7v4H5V6H3l3-4z" fill="currentColor"/></svg>
                  {n.newerVersion} available
                </div>
              )}
              {/* Bottom row: status + workflows count */}
              <div style={{
                display:'flex', alignItems:'center', justifyContent:'space-between',
                borderTop:'1px solid #f0f0f2', paddingTop:10, gap:8,
              }}>
                <Tag color={STATUS_META[n.status]?.color} size="sm" style={{ overflow:'hidden', textOverflow:'ellipsis' }}>
                  <Dot color={STATUS_META[n.status]?.dot} size={5}/>
                  <span style={{ overflow:'hidden', textOverflow:'ellipsis' }}>{STATUS_META[n.status]?.label}</span>
                </Tag>
                <span style={{ fontSize:11.5, color:'#909399', whiteSpace:'nowrap', flexShrink:0 }}>
                  {n.workflows} workflow{n.workflows===1?'':'s'}
                </span>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── ADMIN ────────────────────────────────────────────────────────────────────
function AdminScreen() {
  const [addOpen, setAddOpen] = React.useState(false);
  const [scopeType, setScopeType] = React.useState('global');
  const assignments = [
    { user:'alice',       role:'maker',   scope:'Global',                  by:'admin', at:'May 01, 2026' },
    { user:'bob',         role:'maker',   scope:'Category: Logic',          by:'admin', at:'May 02, 2026' },
    { user:'checker-dan', role:'checker', scope:'Global',                   by:'admin', at:'Apr 28, 2026' },
    { user:'carol',       role:'checker', scope:'Category: Infra',          by:'admin', at:'May 05, 2026' },
    { user:'eve',         role:'viewer',  scope:'Workflow: submit-order',   by:'admin', at:'May 10, 2026' },
  ];
  const roleColor = { maker:'info', checker:'coral', viewer:'neutral', admin:'purple' };
  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', background:'#f7f7f5' }}>
      <div style={{ padding:'22px 32px 14px', background:'#fff', borderBottom:'1px solid #e4e4e7', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <div>
          <h1 style={{ fontSize:22, fontWeight:700 }}>Roles & permissions</h1>
          <p style={{ fontSize:12.5, color:'#525457' }}>Who can submit, review, and approve specs</p>
        </div>
        <Button variant="primary" onClick={()=>setAddOpen(true)}>+ Add assignment</Button>
      </div>
      <div style={{ flex:1, overflow:'auto', padding:'18px 32px' }}>
        <Card style={{padding:0, overflow:'hidden'}}>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
            <thead><tr style={{ background:'#fafafa', borderBottom:'1px solid #e4e4e7' }}>
              {['User','Role','Scope','Assigned by','Assigned at','Actions'].map(c=>(
                <th key={c} style={{ padding:'10px 16px', textAlign:'left', fontSize:11, fontWeight:600, color:'#909399', textTransform:'uppercase', letterSpacing:'0.04em' }}>{c}</th>
              ))}
            </tr></thead>
            <tbody>
              {assignments.map((a,i)=>(
                <tr key={i} style={{ borderBottom:'1px solid #f0f0f2' }}
                  onMouseEnter={e=>e.currentTarget.style.background='#fafafa'}
                  onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                  <td style={{ padding:'11px 16px' }}>
                    <span style={{ display:'inline-flex', alignItems:'center', gap:8 }}>
                      <span style={{ width:24, height:24, borderRadius:'50%', background:'#ff6d5a', color:'#fff', fontSize:10, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center' }}>{a.user[0].toUpperCase()}</span>
                      <strong>{a.user}</strong>
                    </span>
                  </td>
                  <td style={{ padding:'11px 16px' }}><Tag color={roleColor[a.role]}>{a.role}</Tag></td>
                  <td style={{ padding:'11px 16px' }}><Tag color="neutral" style={{fontFamily:'ui-monospace,monospace',fontSize:11}}>{a.scope}</Tag></td>
                  <td style={{ padding:'11px 16px', color:'#525457' }}>{a.by}</td>
                  <td style={{ padding:'11px 16px', color:'#909399', fontSize:11.5 }}>{a.at}</td>
                  <td style={{ padding:'11px 16px' }}>
                    <Menu items={[{label:'Edit', icon:'✎'},{label:'Remove', icon:'🗑', danger:true}]}
                      trigger={<IconButton size={26} aria-label="Actions"><span>⋯</span></IconButton>} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>

      <Dialog open={addOpen} title="Add role assignment" onClose={()=>setAddOpen(false)}
        actions={[
          <Button key="c" variant="secondary" onClick={()=>setAddOpen(false)}>Cancel</Button>,
          <Button key="s" variant="primary">Save assignment</Button>,
        ]}>
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <FormField label="User" required>
            <Select options={['alice','bob','carol','dan','eve']} placeholder="Select user…" aria-label="User" style={{width:'100%'}}/>
          </FormField>
          <FormField label="Role" required>
            <Select options={['maker','checker','viewer','admin']} placeholder="Select role…" aria-label="Role" style={{width:'100%'}}/>
          </FormField>
          <FormField label="Scope type">
            <div style={{ display:'flex', gap:8 }}>
              {[{v:'global',l:'Global'},{v:'category',l:'Category'},{v:'workflow',l:'Workflow'}].map(s=>(
                <label key={s.v} style={{
                  flex:1, padding:'8px 12px', borderRadius:5,
                  border:`1px solid ${scopeType===s.v?'#ff6d5a':'#dbdcdf'}`,
                  background: scopeType===s.v?'#fef0ed':'#fff',
                  cursor:'pointer', fontSize:12, fontWeight: scopeType===s.v?600:500,
                  color: scopeType===s.v?'#c75541':'#525457', textAlign:'center',
                }}>
                  <input type="radio" name="st" value={s.v} checked={scopeType===s.v} onChange={()=>setScopeType(s.v)} style={{display:'none'}}/>
                  {s.l}
                </label>
              ))}
            </div>
          </FormField>
          {scopeType==='category' && <FormField label="Category"><Select options={['UI','Logic','Infra','Data','External']} placeholder="Select category…" aria-label="Category" style={{width:'100%'}}/></FormField>}
          {scopeType==='workflow' && <FormField label="Workflow"><Select options={['submit-order','checkout-flow','user-onboarding']} placeholder="Select workflow…" aria-label="Workflow" style={{width:'100%'}}/></FormField>}
          <Banner tone="info">Global admin assignments override all scopes and can force-approve any spec. Grant sparingly.</Banner>
        </div>
      </Dialog>
    </div>
  );
}

Object.assign(window, { HomeScreen, ReviewQueue, NodesScreen, AdminScreen, QUEUE_DATA, NOTIFICATIONS });
