// App.jsx — Shell, routing, property drawer wiring

const NAV_ITEMS = [
  { id:'home',      label:'Home',         icon:'⊞' },
  { id:'flow',      label:'Workflows',    icon:'⬡' },
  { id:'nodes',     label:'Nodes',        icon:'◈' },
  { id:'queue',     label:'Review Queue', icon:'⏳', badge: 4 },
  { id:'admin',     label:'Admin',        icon:'⚙', adminOnly: true },
];

function AppShell() {
  const [screen, setScreen] = React.useState('flow');
  const [notifOpen, setNotifOpen] = React.useState(false);
  const [selectedNode, setSelectedNode] = React.useState(null);
  const [reviewItem, setReviewItem] = React.useState(null);
  const [detailNode, setDetailNode] = React.useState(null);
  const [propDrawerOpen, setPropDrawerOpen] = React.useState(false);
  const [propNode, setPropNode] = React.useState(null);
  const [exportOpen, setExportOpen] = React.useState(false);
  const [canvasViewMode, setCanvasViewMode] = React.useState('standard');

  // Tweak event listener
  React.useEffect(() => {
    const handler = (e) => {
      const { key, value } = e.detail;
      if (key === 'screen')   setScreen(value);
      if (key === 'viewMode') setCanvasViewMode(value);
      if (key === 'overlay') {
        setNotifOpen(false); setExportOpen(false); setReviewItem(null);
        if (value === 'notifs')  setNotifOpen(true);
        if (value === 'export')  setExportOpen(true);
        if (value === 'review')  setReviewItem(QUEUE_DATA[0]);
      }
      if (key === 'drawer') {
        const node = window.__FLOW_NODES?.[0];
        if (value === 'closed') { setDetailNode(null); }
        else { setDetailNode(node || null); }
      }
    };
    window.addEventListener('studio-tweak', handler);
    return () => window.removeEventListener('studio-tweak', handler);
  }, []);
  const unreadCount = 3;

  const handleNodeSelect = (id) => {
    setSelectedNode(id);
    if (id) {
      const node = window.__FLOW_NODES?.find(n => n.id === id);
      if (node) setDetailNode(node);
    }
  };

  const handleOpenDetail = (node) => {
    setDetailNode(node);
  };

  const breadcrumbs = {
    home: ['MyApp','Workflows'],
    flow: ['MyApp','Workflows','submit-order'],
    nodes: ['MyApp','Nodes'],
    queue: ['MyApp','Review Queue'],
    admin: ['MyApp','Admin','Roles & Permissions'],
  };

  return (
    <div style={{ display:'flex', flexDirection:'column', height:'100vh', overflow:'hidden' }}>
      {/* Top Bar */}
      <div style={{
        height: 'var(--salt-size-base)', display:'flex', alignItems:'center',
        justifyContent:'space-between', padding:'0 16px',
        background:'var(--salt-container-secondary-background)',
        borderBottom:'1px solid var(--salt-separable-primary-borderColor)',
        flexShrink:0, zIndex:50,
      }}>
        {/* Left: wordmark + breadcrumb */}
        <div style={{ display:'flex', alignItems:'center', gap:16 }}>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <span style={{ width:18, height:18, background:'var(--salt-accent-background)', borderRadius:3, display:'flex', alignItems:'center', justifyContent:'center', fontSize:10, fontWeight:700, color:'#fff' }}>W</span>
            <h4 style={{ fontSize:13, fontWeight:700, letterSpacing:'-0.01em', color:'var(--salt-content-primary-foreground)' }}>WorkflowStudio</h4>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:4, fontSize:11, color:'var(--salt-content-secondary-foreground)' }}>
            {(breadcrumbs[screen]||['MyApp']).map((crumb, i, arr) => (
              <React.Fragment key={i}>
                {i > 0 && <span style={{ opacity:0.4 }}>/</span>}
                <span style={{ color: i===arr.length-1 ? 'var(--salt-content-primary-foreground)' : 'var(--salt-content-secondary-foreground)', cursor: i<arr.length-1?'pointer':'default' }}
                  onMouseEnter={e=>{ if(i<arr.length-1) e.currentTarget.style.color='var(--salt-accent-foreground)'; }}
                  onMouseLeave={e=>e.currentTarget.style.color = i===arr.length-1?'var(--salt-content-primary-foreground)':'var(--salt-content-secondary-foreground)'}>
                  {crumb}
                </span>
              </React.Fragment>
            ))}
          </div>
        </div>
        {/* Right: role chip + bell + avatar */}
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <Chip appearance="bordered" style={{ fontSize:10 }}>maker</Chip>
          <div style={{ position:'relative' }}>
            <button onClick={()=>setNotifOpen(true)} style={{
              background:'transparent', border:'none', color:'var(--salt-content-secondary-foreground)',
              cursor:'pointer', width:28, height:28, display:'flex', alignItems:'center', justifyContent:'center',
              borderRadius:3, fontSize:15, transition:'color 0.1s',
            }}
            onMouseEnter={e=>e.currentTarget.style.color='var(--salt-content-primary-foreground)'}
            onMouseLeave={e=>e.currentTarget.style.color='var(--salt-content-secondary-foreground)'}
            aria-label="Notifications">
              🔔
              <Badge>{unreadCount}</Badge>
            </button>
          </div>
          <button style={{
            width:26, height:26, borderRadius:'50%', background:'var(--salt-accent-background)',
            border:'none', color:'#fff', fontSize:11, fontWeight:700, cursor:'pointer',
          }} aria-label="User menu">A</button>
        </div>
      </div>

      {/* Body */}
      <div style={{ display:'flex', flex:1, overflow:'hidden' }}>
        {/* Left sidebar */}
        <div style={{ width:220, borderRight:'1px solid var(--salt-separable-primary-borderColor)', background:'var(--salt-container-secondary-background)', display:'flex', flexDirection:'column', flexShrink:0 }}>
          <div style={{ padding:'12px 0', flex:1 }}>
            {[{label:'NAVIGATION'}].map(group=>(
              <div key={group.label}>
                <div style={{ padding:'6px 14px 4px', fontSize:10, fontWeight:600, color:'var(--salt-content-secondary-foreground)', letterSpacing:'0.06em' }}>{group.label}</div>
                {NAV_ITEMS.map(item=>(
                  <div key={item.id} onClick={()=>setScreen(item.id)} style={{
                    display:'flex', alignItems:'center', gap:10, padding:'7px 14px', cursor:'pointer',
                    background: screen===item.id ? 'rgba(59,130,246,0.1)' : 'transparent',
                    borderLeft: screen===item.id ? '2px solid var(--salt-accent-foreground)' : '2px solid transparent',
                    color: screen===item.id ? 'var(--salt-content-primary-foreground)' : 'var(--salt-content-secondary-foreground)',
                    fontSize:13, fontWeight: screen===item.id ? 600 : 400, transition:'all 0.1s',
                  }}
                  onMouseEnter={e=>{ if(screen!==item.id) { e.currentTarget.style.background='var(--salt-container-tertiary-background)'; e.currentTarget.style.color='var(--salt-content-primary-foreground)'; }}}
                  onMouseLeave={e=>{ if(screen!==item.id) { e.currentTarget.style.background='transparent'; e.currentTarget.style.color='var(--salt-content-secondary-foreground)'; }}}>
                    <span style={{ fontSize:14, opacity: screen===item.id?1:0.7 }}>{item.icon}</span>
                    <span style={{ flex:1 }}>{item.label}</span>
                    {item.badge && <Chip sentiment="caution" style={{ fontSize:9 }}>{item.badge}</Chip>}
                  </div>
                ))}
              </div>
            ))}
          </div>

          {/* Bottom section */}
          <div style={{ borderTop:'1px solid var(--salt-separable-secondary-borderColor)', padding:'10px 14px' }}>
            <div style={{ fontSize:10, color:'var(--salt-content-secondary-foreground)', marginBottom:4 }}>WORKSPACE</div>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <div style={{ width:8, height:8, borderRadius:'50%', background:'var(--salt-status-success-foreground)' }} />
              <span style={{ fontSize:11, color:'var(--salt-content-secondary-foreground)' }}>submit-order</span>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div style={{ flex:1, display:'flex', overflow:'hidden' }}>
          {screen === 'home' && <HomeScreen onNavigate={setScreen} />}
          {screen === 'flow' && (
            <FlowCanvas
              selectedNode={selectedNode}
              onNodeSelect={handleNodeSelect}
              onOpenDetail={handleOpenDetail}
              onExport={() => setExportOpen(true)}
              defaultViewMode={canvasViewMode}
            />
          )}
          {screen === 'nodes' && <NodesScreen />}
          {screen === 'queue' && <ReviewQueue onOpenReview={setReviewItem} />}
          {screen === 'admin' && <AdminScreen />}
        </div>
      </div>

      {/* Overlays */}
      {notifOpen && <NotificationCenter onClose={()=>setNotifOpen(false)} />}
      {reviewItem && <ReviewPanel item={reviewItem} onClose={()=>setReviewItem(null)} />}
      {detailNode && <NodeDetailDrawer node={detailNode} onClose={()=>setDetailNode(null)} />}

      {/* Export modal */}
      <ExportModal open={exportOpen} onClose={()=>setExportOpen(false)} />
    </div>
  );
}

// ─── Nodes screen (list view) ─────────────────────────────────────────────────
function NodesScreen() {
  const nodes = [
    { id:'order-form',        category:'UI',       version:'v1.1.0', status:'APPROVED',          workflows:3 },
    { id:'validate-order',    category:'Logic',    version:'v2.0.1', status:'IN_REVIEW',         workflows:2 },
    { id:'payment-gateway',   category:'Infra',    version:'v1.3.0', status:'APPROVED',          workflows:4, newerVersion:'v1.4.0' },
    { id:'send-confirmation', category:'Data',     version:'v1.0.2', status:'DRAFT',             workflows:1 },
    { id:'audit-log',         category:'Data',     version:'v1.1.1', status:'REJECTED',          workflows:2 },
    { id:'route-request',     category:'Logic',    version:'v1.0.0', status:'CHANGES_REQUESTED', workflows:1 },
    { id:'stripe-api',        category:'External', version:'v2.1.0', status:'APPROVED',          workflows:5 },
    { id:'message-queue',     category:'Infra',    version:'v1.2.0', status:'APPROVED',          workflows:3 },
  ];
  const statusColors = { IN_REVIEW:'warning', APPROVED:'success', REJECTED:'error', CHANGES_REQUESTED:'warning', DRAFT:'info', SUBMITTED:'info' };
  return (
    <div style={{ flex:1, overflow:'hidden', display:'flex', flexDirection:'column' }}>
      <div style={{ padding:'16px 24px 12px', borderBottom:'1px solid var(--salt-separable-primary-borderColor)', flexShrink:0 }}>
        <div style={{ fontSize:11, color:'var(--salt-content-secondary-foreground)', marginBottom:4 }}>MyApp / Nodes</div>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <h2 style={{ fontSize:18, fontWeight:600 }}>Node Registry</h2>
          <Button sentiment="accented" size="sm">+ New Node</Button>
        </div>
      </div>
      <div style={{ flex:1, overflow:'auto' }}>
        <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
          <thead><tr style={{ borderBottom:'1px solid var(--salt-separable-primary-borderColor)', background:'var(--salt-container-secondary-background)', position:'sticky', top:0, zIndex:1 }}>
            {['Name','Category','Version','Status','Used In',''].map(c=>(
              <th key={c} style={{ padding:'8px 16px', textAlign:'left', fontSize:11, fontWeight:600, color:'var(--salt-content-secondary-foreground)' }}>{c}</th>
            ))}
          </tr></thead>
          <tbody>
            {nodes.map(n=>(
              <tr key={n.id} style={{ borderBottom:'1px solid var(--salt-separable-secondary-borderColor)', cursor:'pointer' }}
                onMouseEnter={e=>e.currentTarget.style.background='var(--salt-container-tertiary-background)'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                <td style={{ padding:'8px 16px' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                    <span style={{ width:3, height:16, borderRadius:2, background:CATEGORY_COLORS[n.category]||'#888', flexShrink:0 }} />
                    <span style={{ fontFamily:'var(--salt-text-code-fontFamily)', fontSize:11, fontWeight:600 }}>{n.id}</span>
                    {n.newerVersion && <Chip appearance="bordered" sentiment="positive" style={{ fontSize:9 }}>↑ {n.newerVersion}</Chip>}
                  </div>
                </td>
                <td style={{ padding:'8px 16px', color:CATEGORY_COLORS[n.category]||'#888', fontSize:11, fontWeight:600 }}>{n.category}</td>
                <td style={{ padding:'8px 16px', fontFamily:'var(--salt-text-code-fontFamily)', fontSize:11, color:'var(--salt-content-secondary-foreground)' }}>{n.version}</td>
                <td style={{ padding:'8px 16px' }}>
                  <Chip sentiment={statusColors[n.status]==='warning'?'caution':statusColors[n.status]==='error'?'negative':statusColors[n.status]==='success'?'positive':'info'}>
                    <StatusIndicator status={statusColors[n.status]||'info'} size="sm" />
                    <span style={{ marginLeft:4 }}>{n.status.replace(/_/g,' ')}</span>
                  </Chip>
                </td>
                <td style={{ padding:'8px 16px', color:'var(--salt-content-secondary-foreground)' }}>{n.workflows} workflows</td>
                <td style={{ padding:'8px 16px' }}>
                  <Menu items={[{label:'View detail'},{label:'Submit for review'},{label:'Duplicate as DRAFT'},{label:'View history'}]}
                    trigger={<Button appearance="transparent" size="sm" aria-label="Actions">⋯</Button>} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Admin Screen ─────────────────────────────────────────────────────────────
function AdminScreen() {
  const [addOpen, setAddOpen] = React.useState(false);
  const [scopeType, setScopeType] = React.useState('global');
  const assignments = [
    { user:'alice',     role:'maker',   scope:'Global',              assignedBy:'admin', at:'Apr 01, 2026' },
    { user:'bob',       role:'maker',   scope:'Category: Logic',     assignedBy:'admin', at:'Apr 02, 2026' },
    { user:'checker-dan',role:'checker',scope:'Global',             assignedBy:'admin', at:'Mar 28, 2026' },
    { user:'carol',     role:'checker', scope:'Category: Infra',     assignedBy:'admin', at:'Apr 05, 2026' },
    { user:'eve',       role:'viewer',  scope:'Workflow: submit-order', assignedBy:'admin', at:'Apr 10, 2026' },
  ];
  return (
    <div style={{ flex:1, overflow:'hidden', display:'flex', flexDirection:'column' }}>
      <div style={{ padding:'16px 24px 12px', borderBottom:'1px solid var(--salt-separable-primary-borderColor)', flexShrink:0 }}>
        <div style={{ fontSize:11, color:'var(--salt-content-secondary-foreground)', marginBottom:4 }}>MyApp / Admin</div>
        <h2 style={{ fontSize:18, fontWeight:600 }}>Roles & Permissions</h2>
      </div>
      <div style={{ padding:'12px 24px', borderBottom:'1px solid var(--salt-separable-primary-borderColor)', flexShrink:0 }}>
        <Button sentiment="accented" size="sm" onClick={()=>setAddOpen(true)}>+ Add Assignment</Button>
      </div>
      <div style={{ flex:1, overflow:'auto' }}>
        <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
          <thead><tr style={{ borderBottom:'1px solid var(--salt-separable-primary-borderColor)', background:'var(--salt-container-secondary-background)', position:'sticky', top:0, zIndex:1 }}>
            {['User','Role','Scope','Assigned By','Assigned At','Actions'].map(c=>(
              <th key={c} style={{ padding:'8px 16px', textAlign:'left', fontSize:11, fontWeight:600, color:'var(--salt-content-secondary-foreground)' }}>{c}</th>
            ))}
          </tr></thead>
          <tbody>
            {assignments.map((a,i)=>(
              <tr key={i} style={{ borderBottom:'1px solid var(--salt-separable-secondary-borderColor)' }}
                onMouseEnter={e=>e.currentTarget.style.background='var(--salt-container-tertiary-background)'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                <td style={{ padding:'8px 16px', color:'var(--salt-accent-foreground)', fontWeight:500 }}>{a.user}</td>
                <td style={{ padding:'8px 16px' }}><Chip appearance="bordered">{a.role}</Chip></td>
                <td style={{ padding:'8px 16px' }}><Chip appearance="bordered" style={{ fontFamily:'var(--salt-text-code-fontFamily)', fontSize:10 }}>{a.scope}</Chip></td>
                <td style={{ padding:'8px 16px', color:'var(--salt-content-secondary-foreground)' }}>{a.assignedBy}</td>
                <td style={{ padding:'8px 16px', fontFamily:'var(--salt-text-code-fontFamily)', fontSize:11, color:'var(--salt-content-secondary-foreground)' }}>{a.at}</td>
                <td style={{ padding:'8px 16px' }}>
                  <Menu items={[{label:'Edit'},{label:'Remove',danger:true}]}
                    trigger={<Button appearance="transparent" size="sm" aria-label="Actions">⋯</Button>} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Dialog open={addOpen} title="Add Role Assignment" onClose={()=>setAddOpen(false)}
        actions={[<Button key="c" appearance="bordered" onClick={()=>setAddOpen(false)}>Cancel</Button>, <Button key="s" sentiment="accented">Save</Button>]}>
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <FormField label="User"><Dropdown options={['alice','bob','carol','dan','eve']} placeholder="Select user…" aria-label="User" style={{ width:'100%' }} /></FormField>
          <FormField label="Role"><Dropdown options={['maker','checker','viewer','admin']} placeholder="Select role…" aria-label="Role" style={{ width:'100%' }} /></FormField>
          <FormField label="Scope Type">
            <div style={{ display:'flex', gap:12 }}>
              {['global','category','workflow'].map(s=>(
                <label key={s} style={{ display:'flex', alignItems:'center', gap:6, fontSize:12, cursor:'pointer' }}>
                  <input type="radio" name="scope" value={s} checked={scopeType===s} onChange={()=>setScopeType(s)} />
                  {s.charAt(0).toUpperCase()+s.slice(1)}
                </label>
              ))}
            </div>
          </FormField>
          {scopeType==='category' && <FormField label="Category"><Dropdown options={['UI','Logic','Infra','Data','External']} placeholder="Select category…" aria-label="Category" style={{ width:'100%' }} /></FormField>}
          {scopeType==='workflow' && <FormField label="Workflow"><Dropdown options={['submit-order','checkout-flow','onboarding']} placeholder="Select workflow…" aria-label="Workflow" style={{ width:'100%' }} /></FormField>}
          <Banner sentiment="info">Global admin assignments override all scopes and can force-approve any spec. Grant sparingly.</Banner>
        </div>
      </Dialog>
    </div>
  );
}

// ─── Export Modal ─────────────────────────────────────────────────────────────
function ExportModal({ open, onClose }) {
  const [tab, setTab] = React.useState('full');
  const [format, setFormat] = React.useState('json');
  const [scope, setScope] = React.useState('');
  const tabs = [{id:'full',label:'Full'},{id:'approved',label:'Approved Only'},{id:'delta',label:'Delta ⚗'}];
  const fileTree = `submit-order/\n├── workflow.json\n├── nodes/\n│   ├── order-form.v1.1.0.json\n│   ├── validate-order.v2.0.1.json\n│   ├── payment-gateway.v1.3.0.json\n│   └── audit-log.v1.1.1.json\n└── schemas/\n    └── logic.schema.json`;
  return (
    <Dialog open={open} title="Export Spec" onClose={onClose} width={560}
      actions={[
        <Button key="cancel" appearance="bordered" onClick={onClose}>Cancel</Button>,
        <Button key="download" sentiment="accented">Download ZIP</Button>
      ]}>
      <div style={{ display:'flex', flexDirection:'column', gap:0 }}>
        <div style={{ display:'flex', borderBottom:'1px solid var(--salt-separable-primary-borderColor)', marginBottom:16 }}>
          {tabs.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{
              background:'none', border:'none', borderBottom: tab===t.id?'2px solid var(--salt-accent-foreground)':'2px solid transparent',
              color: tab===t.id?'var(--salt-content-primary-foreground)':'var(--salt-content-secondary-foreground)',
              padding:'6px 14px', fontSize:12, cursor:'pointer', fontFamily:'var(--salt-text-fontFamily)', marginBottom:-1,
            }}>{t.label}</button>
          ))}
        </div>
        {tab==='delta' && <Banner sentiment="caution" style={{ marginBottom:12 }}>Delta export is experimental. Validate that your target agent benefits from deltas before relying on this export.</Banner>}
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <FormField label="Scope">
            <Dropdown value={scope} onChange={setScope} options={['Entire app','Specific workflow','Specific node']} placeholder="Select scope…" aria-label="Export scope" style={{ width:'100%' }} />
          </FormField>
          {tab !== 'delta' && (
            <FormField label="Format">
              <div style={{ display:'flex', gap:16 }}>
                {['json','yaml'].map(f=>(
                  <label key={f} style={{ display:'flex', alignItems:'center', gap:6, fontSize:12, cursor:'pointer' }}>
                    <input type="radio" name="format" value={f} checked={format===f} onChange={()=>setFormat(f)} />
                    {f.toUpperCase()}
                    {f==='yaml' && <Chip appearance="bordered" sentiment="caution" style={{ fontSize:9 }}>beta</Chip>}
                  </label>
                ))}
              </div>
            </FormField>
          )}
          {tab === 'delta' && (
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
              <FormField label="From Version"><Dropdown options={['v1.0.0','v1.1.0','v2.0.0']} placeholder="From…" aria-label="From version" style={{ width:'100%' }} /></FormField>
              <FormField label="To Version"><Dropdown options={['v1.1.0','v1.2.0','v2.0.1']} placeholder="To…" aria-label="To version" style={{ width:'100%' }} /></FormField>
            </div>
          )}
          <FormField label="File Tree Preview">
            <Textarea value={fileTree} readOnly rows={8} aria-label="File tree preview"
              style={{ fontFamily:'var(--salt-text-code-fontFamily)', fontSize:11, resize:'none' }} />
          </FormField>
        </div>
      </div>
    </Dialog>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<AppShell />);
