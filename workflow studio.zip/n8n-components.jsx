// n8n-style component primitives (light theme, coral accent)

// ─── Button ──────────────────────────────────────────────────────────────────
function Button({ children, variant = 'tertiary', size = 'md', onClick, disabled, style, title, 'aria-label': ariaLabel }) {
  const [hov, setHov] = React.useState(false);
  const sizes = {
    sm: { padding: '4px 10px', fontSize: 12, height: 26 },
    md: { padding: '6px 14px', fontSize: 13, height: 32 },
    lg: { padding: '8px 18px', fontSize: 14, height: 38 },
  };
  const variants = {
    primary:   { bg:'#ff6d5a', color:'#fff',     border:'#ff6d5a',   hov:'#ff5a45' },
    secondary: { bg:'#fff',    color:'#525457',  border:'#dbdcdf',   hov:'#f4f4f5' },
    tertiary:  { bg:'transparent', color:'#525457', border:'transparent', hov:'#f4f4f5' },
    danger:    { bg:'#fff',    color:'#dc3545',  border:'#dc3545',   hov:'#fff5f5' },
    ghost:     { bg:'transparent', color:'#909399', border:'transparent', hov:'#f4f4f5' },
  };
  const v = variants[variant] || variants.tertiary;
  return (
    <button onClick={disabled?undefined:onClick} disabled={disabled} title={title} aria-label={ariaLabel}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{
        display:'inline-flex', alignItems:'center', justifyContent:'center', gap:6,
        background: hov && !disabled ? v.hov : v.bg,
        color: v.color, border:`1px solid ${v.border}`, borderRadius: 4,
        fontFamily:'inherit', fontWeight: variant==='primary'?600:500,
        cursor: disabled?'not-allowed':'pointer',
        opacity: disabled?0.5:1, transition:'all 0.12s', whiteSpace:'nowrap',
        outline:'none', userSelect:'none',
        ...sizes[size], ...style
      }}>
      {children}
    </button>
  );
}

// ─── IconButton ──────────────────────────────────────────────────────────────
function IconButton({ children, onClick, active, title, 'aria-label': ariaLabel, size = 32, style }) {
  const [hov, setHov] = React.useState(false);
  return (
    <button onClick={onClick} title={title} aria-label={ariaLabel}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{
        width:size, height:size, display:'inline-flex', alignItems:'center', justifyContent:'center',
        background: active ? '#fef0ed' : (hov ? '#f4f4f5' : 'transparent'),
        color: active ? '#ff6d5a' : '#525457',
        border:'none', borderRadius: 4, cursor:'pointer', transition:'all 0.12s',
        outline:'none', flexShrink:0, ...style
      }}>
      {children}
    </button>
  );
}

// ─── Chip / Tag ──────────────────────────────────────────────────────────────
function Tag({ children, color = 'neutral', size = 'md', onClose, style }) {
  const colors = {
    neutral: { bg:'#f4f4f5', color:'#525457', border:'#e4e4e7' },
    coral:   { bg:'#fef0ed', color:'#c75541', border:'#fad6cd' },
    success: { bg:'#e8f5ed', color:'#1a7a3e', border:'#c3e6cf' },
    warning: { bg:'#fef6e7', color:'#a86a00', border:'#fae0a0' },
    danger:  { bg:'#fdebec', color:'#b3261e', border:'#f5c2c5' },
    info:    { bg:'#e8f0fd', color:'#1a56db', border:'#c1d4f9' },
    purple:  { bg:'#f3eafe', color:'#6b21a8', border:'#dcc5fa' },
  };
  const c = colors[color] || colors.neutral;
  return (
    <span style={{
      display:'inline-flex', alignItems:'center', gap:4,
      padding: size==='sm'?'1px 6px':'2px 8px',
      borderRadius: 3, fontSize: size==='sm'?10:11, fontWeight:500,
      background:c.bg, color:c.color, border:`1px solid ${c.border}`,
      lineHeight:1.4, whiteSpace:'nowrap', ...style
    }}>
      {children}
      {onClose && <span onClick={e=>{e.stopPropagation();onClose();}} style={{cursor:'pointer',opacity:0.6,marginLeft:2}}>×</span>}
    </span>
  );
}

// ─── Status dot ───────────────────────────────────────────────────────────────
function Dot({ color = '#909399', size = 8 }) {
  return <span style={{ display:'inline-block', width:size, height:size, borderRadius:'50%', background:color, flexShrink:0 }} />;
}

// ─── Input ────────────────────────────────────────────────────────────────────
function Input({ value, onChange, placeholder, startIcon, readOnly, style, 'aria-label': ariaLabel, type='text', size='md' }) {
  const [focus, setFocus] = React.useState(false);
  const heights = { sm: 28, md: 32, lg: 36 };
  return (
    <span style={{
      display:'inline-flex', alignItems:'center', gap:6,
      background:'#fff', border:`1px solid ${focus?'#ff6d5a':'#dbdcdf'}`,
      borderRadius:4, padding:'0 10px', height: heights[size],
      transition:'border-color 0.12s', minWidth:0,
      boxShadow: focus?'0 0 0 3px rgba(255,109,90,0.12)':'none', ...style
    }}>
      {startIcon && <span style={{color:'#909399',display:'flex',alignItems:'center'}}>{startIcon}</span>}
      <input type={type} value={value} onChange={onChange} readOnly={readOnly} placeholder={placeholder} aria-label={ariaLabel}
        onFocus={()=>setFocus(true)} onBlur={()=>setFocus(false)}
        style={{ background:'transparent',border:'none',color:'#1f1f1f',fontFamily:'inherit',
          fontSize:13, outline:'none', width:'100%', minWidth:0 }} />
    </span>
  );
}

// ─── Select ───────────────────────────────────────────────────────────────────
function Select({ value, options=[], onChange, placeholder='Select…', style, 'aria-label': ariaLabel, size='md' }) {
  const heights = { sm: 28, md: 32, lg: 36 };
  return (
    <select value={value||''} onChange={e=>onChange&&onChange(e.target.value)} aria-label={ariaLabel}
      style={{ background:'#fff', border:'1px solid #dbdcdf', borderRadius:4,
        color: value?'#1f1f1f':'#909399', fontFamily:'inherit', fontSize:13,
        padding:'0 28px 0 10px', height: heights[size], cursor:'pointer', outline:'none', appearance:'none',
        backgroundImage:`url("data:image/svg+xml;charset=US-ASCII,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%23909399' stroke-width='1.5' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
        backgroundRepeat:'no-repeat', backgroundPosition:'right 10px center', ...style }}>
      <option value="" disabled>{placeholder}</option>
      {options.map(o=>(
        <option key={o.value??o} value={o.value??o}>{o.label??o}</option>
      ))}
    </select>
  );
}

// ─── Textarea ─────────────────────────────────────────────────────────────────
function Textarea({ value, onChange, placeholder, rows=3, readOnly, style, 'aria-label': ariaLabel }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <textarea value={value} onChange={onChange} placeholder={placeholder} readOnly={readOnly} rows={rows} aria-label={ariaLabel}
      onFocus={()=>setFocus(true)} onBlur={()=>setFocus(false)}
      style={{ background:'#fff', border:`1px solid ${focus?'#ff6d5a':'#dbdcdf'}`,
        borderRadius:4, color:'#1f1f1f', fontFamily:'inherit', fontSize:13,
        padding:'8px 10px', resize:'vertical', outline:'none', width:'100%',
        transition:'border-color 0.12s',
        boxShadow: focus?'0 0 0 3px rgba(255,109,90,0.12)':'none', ...style }} />
  );
}

// ─── Card ─────────────────────────────────────────────────────────────────────
function Card({ children, style, onClick, accent }) {
  const [hov, setHov] = React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{ background:'#fff',
        border:`1px solid ${hov&&onClick?'#ff6d5a':'#e4e4e7'}`,
        borderLeft: accent?`3px solid ${accent}`:undefined,
        borderRadius:6, boxShadow: hov&&onClick ? '0 4px 12px rgba(0,0,0,0.06)' : '0 1px 2px rgba(0,0,0,0.04)',
        cursor: onClick?'pointer':'default', transition:'all 0.15s', ...style }}>
      {children}
    </div>
  );
}

// ─── Tooltip ─────────────────────────────────────────────────────────────────
function Tooltip({ content, children, placement='top' }) {
  const [vis, setVis] = React.useState(false);
  const pos = {
    top:    { bottom:'100%', left:'50%', transform:'translateX(-50%)', marginBottom:6 },
    bottom: { top:'100%',    left:'50%', transform:'translateX(-50%)', marginTop:6 },
    right:  { left:'100%',   top:'50%',  transform:'translateY(-50%)', marginLeft:6 },
  };
  return (
    <span style={{ position:'relative', display:'inline-flex' }}
      onMouseEnter={()=>setVis(true)} onMouseLeave={()=>setVis(false)}>
      {children}
      {vis && <span style={{
        position:'absolute', ...pos[placement],
        background:'#1f1f1f', color:'#fff', fontSize:11, padding:'5px 9px',
        borderRadius:4, whiteSpace:'normal', zIndex:9999,
        boxShadow:'0 4px 12px rgba(0,0,0,0.15)', maxWidth:240, pointerEvents:'none',
      }}>{content}</span>}
    </span>
  );
}

// ─── Menu ─────────────────────────────────────────────────────────────────────
function Menu({ items, trigger, placement='bottom-right' }) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef();
  React.useEffect(()=>{
    const h = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return ()=>document.removeEventListener('mousedown', h);
  },[]);
  const pos = placement==='bottom-right'
    ? { top:'100%', right:0, marginTop:4 }
    : { top:'100%', left:0, marginTop:4 };
  return (
    <span ref={ref} style={{ position:'relative', display:'inline-flex' }}>
      <span onClick={e=>{e.stopPropagation();setOpen(p=>!p);}}>{trigger}</span>
      {open && (
        <div style={{ position:'absolute', ...pos, zIndex:9999, minWidth:170,
          background:'#fff', border:'1px solid #e4e4e7', borderRadius:6,
          boxShadow:'0 8px 24px rgba(0,0,0,0.12)', padding:'4px 0' }}>
          {items.map((item, i) => item.divider ? (
            <div key={i} style={{height:1, background:'#e4e4e7', margin:'4px 0'}} />
          ) : (
            <div key={i} onClick={()=>{item.onClick?.();setOpen(false);}}
              style={{ padding:'7px 14px', fontSize:12, cursor:'pointer',
                color: item.danger?'#dc3545':'#1f1f1f', transition:'background 0.1s',
                display:'flex', alignItems:'center', gap:8 }}
              onMouseEnter={e=>e.currentTarget.style.background='#f4f4f5'}
              onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
              {item.icon && <span style={{opacity:0.7}}>{item.icon}</span>}
              {item.label}
              {item.shortcut && <span style={{marginLeft:'auto',color:'#909399',fontSize:11,fontFamily:'ui-monospace,monospace'}}>{item.shortcut}</span>}
            </div>
          ))}
        </div>
      )}
    </span>
  );
}

// ─── Dialog ───────────────────────────────────────────────────────────────────
function Dialog({ open, title, onClose, children, actions, width=520 }) {
  if (!open) return null;
  return (
    <div style={{ position:'fixed', inset:0, zIndex:10000, background:'rgba(15,15,15,0.4)',
      display:'flex', alignItems:'center', justifyContent:'center' }}
      onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={{ background:'#fff', borderRadius:8, width, maxWidth:'92vw', maxHeight:'88vh',
        display:'flex', flexDirection:'column', boxShadow:'0 12px 48px rgba(0,0,0,0.2)' }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
          padding:'16px 20px', borderBottom:'1px solid #e4e4e7', flexShrink:0 }}>
          <h3 style={{ fontSize:15, fontWeight:600, color:'#1f1f1f' }}>{title}</h3>
          <IconButton onClick={onClose} aria-label="Close" size={28}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
          </IconButton>
        </div>
        <div style={{ padding:'18px 20px', overflow:'auto', flex:1 }}>{children}</div>
        {actions && <div style={{ padding:'12px 20px', borderTop:'1px solid #e4e4e7', display:'flex', gap:8, justifyContent:'flex-end', flexShrink:0 }}>{actions}</div>}
      </div>
    </div>
  );
}

// ─── Banner ───────────────────────────────────────────────────────────────────
function Banner({ tone='info', icon, children }) {
  const tones = {
    info:    { bg:'#e8f0fd', border:'#c1d4f9', color:'#1a56db', icon:'ⓘ' },
    warning: { bg:'#fef6e7', border:'#fae0a0', color:'#a86a00', icon:'⚠' },
    danger:  { bg:'#fdebec', border:'#f5c2c5', color:'#b3261e', icon:'⊘' },
    success: { bg:'#e8f5ed', border:'#c3e6cf', color:'#1a7a3e', icon:'✓' },
  };
  const t = tones[tone] || tones.info;
  return (
    <div style={{ background:t.bg, border:`1px solid ${t.border}`,
      borderRadius:5, padding:'10px 12px', fontSize:12.5, color:t.color, lineHeight:1.5,
      display:'flex', gap:9, alignItems:'flex-start' }}>
      <span style={{ fontSize:14, lineHeight:1, marginTop:1 }}>{icon||t.icon}</span>
      <span style={{flex:1}}>{children}</span>
    </div>
  );
}

// ─── ToggleGroup ──────────────────────────────────────────────────────────────
function ToggleGroup({ options, value, onChange }) {
  return (
    <div style={{ display:'inline-flex', border:'1px solid #dbdcdf', borderRadius:5,
      padding:2, background:'#f4f4f5', gap:1 }}>
      {options.map(o=>(
        <button key={o.value} onClick={()=>onChange(o.value)} style={{
          background: value===o.value?'#fff':'transparent',
          border:'none', borderRadius:3,
          color: value===o.value?'#1f1f1f':'#525457',
          padding:'4px 10px', fontSize:11.5, cursor:'pointer', fontFamily:'inherit',
          fontWeight: value===o.value?600:500, transition:'all 0.12s',
          boxShadow: value===o.value?'0 1px 2px rgba(0,0,0,0.08)':'none',
        }}>{o.label}</button>
      ))}
    </div>
  );
}

// ─── Badge (positioned over icon) ─────────────────────────────────────────────
function Badge({ children }) {
  return (
    <span style={{
      position:'absolute', top:-3, right:-3, minWidth:15, height:15, padding:'0 3px',
      background:'#ff6d5a', color:'#fff', borderRadius:8, fontSize:9, fontWeight:700,
      display:'flex', alignItems:'center', justifyContent:'center', lineHeight:1,
      border:'2px solid #fff',
    }}>{children}</span>
  );
}

// ─── FormField ────────────────────────────────────────────────────────────────
function FormField({ label, helper, error, children, required, style }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:5, ...style }}>
      {label && (
        <label style={{ fontSize:12, color:'#525457', fontWeight:500 }}>
          {label} {required && <span style={{color:'#ff6d5a'}}>*</span>}
        </label>
      )}
      {children}
      {error && <span style={{ fontSize:11, color:'#dc3545' }}>{error}</span>}
      {helper && !error && <span style={{ fontSize:11, color:'#909399' }}>{helper}</span>}
    </div>
  );
}

Object.assign(window, { Button, IconButton, Tag, Dot, Input, Select, Textarea, Card, Tooltip, Menu, Dialog, Banner, ToggleGroup, Badge, FormField });
