// FlowCanvas.jsx — Workflow canvas screen with nodes, edges, palette, filter rail

const CATEGORY_COLORS = {
  UI: 'var(--cat-ui)', Logic: 'var(--cat-logic)',
  Infra: 'var(--cat-infra)', Data: 'var(--cat-data)', External: 'var(--cat-external)',
};
const STATUS_CONFIGS = {
  APPROVED:           { label: 'Approved',           saltStatus: 'success' },
  DRAFT:              { label: 'Draft',               saltStatus: 'info'    },
  SUBMITTED:          { label: 'Submitted',           saltStatus: 'info'    },
  IN_REVIEW:          { label: 'In Review',           saltStatus: 'warning' },
  CHANGES_REQUESTED:  { label: 'Changes Requested',   saltStatus: 'warning' },
  REJECTED:           { label: 'Rejected',            saltStatus: 'error'   },
};
const PALETTE_NODES = {
  UI:       ['order-form', 'header-nav', 'modal-dialog', 'data-table'],
  Logic:    ['validate-order', 'route-request', 'transform-data', 'rate-limiter'],
  Infra:    ['payment-gateway', 'message-queue', 'cache-layer', 'load-balancer'],
  Data:     ['audit-log', 'event-store', 'user-profile', 'session-store'],
  External: ['stripe-api', 'sendgrid', 'auth0', 'datadog'],
};
const INITIAL_NODES = [
  { id: 'n1', label: 'order-form',       category: 'UI',       version: 'v1.1.0', status: 'APPROVED',          tags: ['form','checkout'],    x: 60,  y: 60,  newerVersion: null,    comments: 0 },
  { id: 'n2', label: 'validate-order',   category: 'Logic',    version: 'v2.0.1', status: 'IN_REVIEW',         tags: ['validation'],         x: 340, y: 40,  newerVersion: null,    comments: 2 },
  { id: 'n3', label: 'payment-gateway',  category: 'Infra',    version: 'v1.3.0', status: 'APPROVED',          tags: ['payment','external'], x: 340, y: 220, newerVersion: 'v1.4.0', comments: 0 },
  { id: 'n4', label: 'send-confirmation',category: 'Data',     version: 'v1.0.2', status: 'DRAFT',             tags: ['email','notify'],     x: 620, y: 130, newerVersion: null,    comments: 1 },
  { id: 'n5', label: 'audit-log',        category: 'Data',     version: 'v1.1.1', status: 'REJECTED',          tags: ['audit','compliance'], x: 620, y: 320, newerVersion: null,    comments: 3 },
  { id: 'n6', label: 'route-request',    category: 'Logic',    version: 'v1.0.0', status: 'CHANGES_REQUESTED', tags: ['routing'],            x: 120, y: 280, newerVersion: null,    comments: 1 },
];
const INITIAL_EDGES = [
  { id:'e1', src:'n1', tgt:'n2' }, { id:'e2', src:'n1', tgt:'n6' },
  { id:'e3', src:'n2', tgt:'n4' }, { id:'e4', src:'n3', tgt:'n4' },
  { id:'e5', src:'n4', tgt:'n5' }, { id:'e6', src:'n6', tgt:'n3' },
];
const NODE_W = 210, NODE_H = 105;

function getCenterX(n) { return n.x + NODE_W / 2; }
function getCenterY(n) { return n.y + NODE_H / 2; }

function EdgeSvg({ nodes, edges, selected }) {
  const findNode = id => nodes.find(n => n.id === id);
  return (
    <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%', pointerEvents:'none', overflow:'visible' }}>
      <defs>
        <marker id="arrow" markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto">
          <path d="M0,0 L0,7 L7,3.5 z" fill="#2a3548" />
        </marker>
        <marker id="arrow-sel" markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto">
          <path d="M0,0 L0,7 L7,3.5 z" fill="#3b82f6" />
        </marker>
      </defs>
      {edges.map(e => {
        const s = findNode(e.src), t = findNode(e.tgt);
        if (!s || !t) return null;
        const sx = getCenterX(s), sy = getCenterY(s);
        const tx = getCenterX(t), ty = getCenterY(t);
        const mx = (sx + tx) / 2;
        const isSel = selected === e.src || selected === e.tgt;
        return (
          <path key={e.id}
            d={`M${sx},${sy} C${mx},${sy} ${mx},${ty} ${tx},${ty}`}
            fill="none" stroke={isSel ? '#3b82f6' : '#2a3548'}
            strokeWidth={isSel ? 1.5 : 1} opacity={isSel ? 1 : 0.6}
            markerEnd={`url(#${isSel ? 'arrow-sel' : 'arrow'})`} />
        );
      })}
    </svg>
  );
}

function FlowNode({ node, selected, onSelect, onOpenDetail }) {
  const sc = STATUS_CONFIGS[node.status] || STATUS_CONFIGS.DRAFT;
  const catColor = CATEGORY_COLORS[node.category] || '#888';
  return (
    <div onClick={() => onSelect(node.id)}
      onDoubleClick={() => onOpenDetail(node)}
      style={{
        position: 'absolute', left: node.x, top: node.y, width: NODE_W, height: NODE_H,
        background: 'var(--salt-container-card-background)',
        border: `1px solid ${selected ? '#3b82f6' : 'var(--salt-separable-primary-borderColor)'}`,
        borderLeft: `3px solid ${catColor}`, borderRadius: 4,
        boxShadow: selected ? '0 0 0 2px rgba(59,130,246,0.3), var(--salt-card-shadow)' : 'var(--salt-card-shadow)',
        cursor: 'pointer', padding: '8px 10px', display: 'flex', flexDirection: 'column', gap: 5,
        transition: 'border-color 0.12s, box-shadow 0.12s', userSelect: 'none',
      }}>
      {/* Header row */}
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:4 }}>
        <div style={{ display:'flex', alignItems:'center', gap:6, minWidth:0 }}>
          <span style={{ fontSize:12, fontWeight:600, color:'var(--salt-content-primary-foreground)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
            {node.label}
          </span>
          <span style={{ fontFamily:'var(--salt-text-code-fontFamily)', fontSize:10, color:'var(--salt-content-secondary-foreground)', flexShrink:0 }}>
            {node.version}
          </span>
        </div>
        <Chip sentiment={sc.saltStatus === 'success' ? 'positive' : sc.saltStatus === 'error' ? 'negative' : sc.saltStatus === 'warning' ? 'caution' : 'info'}
          style={{ fontSize:10, padding:'1px 5px' }}>
          <StatusIndicator status={sc.saltStatus} size="sm" />
          <span style={{ marginLeft:3 }}>{sc.label}</span>
        </Chip>
      </div>
      {/* Tags */}
      <div style={{ display:'flex', flexWrap:'wrap', gap:3 }}>
        {node.tags.map(t => (
          <Chip key={t} appearance="transparent" style={{ fontSize:10, padding:'1px 5px' }}>{t}</Chip>
        ))}
      </div>
      {/* Bottom badge row */}
      <div style={{ display:'flex', gap:4, marginTop:'auto', alignItems:'center' }}>
        <span style={{ fontSize:10, color:catColor, fontWeight:600 }}>{node.category}</span>
        <span style={{ flex:1 }} />
        {node.newerVersion && (
          <Chip appearance="bordered" sentiment="positive" style={{ fontSize:9, padding:'1px 5px' }}>
            ↑ {node.newerVersion}
          </Chip>
        )}
        {node.comments > 0 && (
          <Chip appearance="transparent" style={{ fontSize:10, padding:'1px 5px', color:'var(--salt-status-warning-foreground)' }}>
            💬 {node.comments}
          </Chip>
        )}
        {node.status === 'REJECTED' && (
          <Tooltip content="Reviewer: Logic does not handle null order_id. Please add validation guard before processing.">
            <span style={{ fontSize:11, color:'var(--salt-status-error-foreground)', cursor:'help' }}>⚠</span>
          </Tooltip>
        )}
      </div>
    </div>
  );
}

function PaletteSidebar({ searchQ, onSearch }) {
  const [expanded, setExpanded] = React.useState({ UI:true, Logic:true, Infra:false, Data:false, External:false });
  return (
    <div style={{ width:200, borderRight:'1px solid var(--salt-separable-primary-borderColor)', background:'var(--salt-container-secondary-background)', display:'flex', flexDirection:'column', flexShrink:0, overflow:'hidden' }}>
      <div style={{ padding:'8px', borderBottom:'1px solid var(--salt-separable-primary-borderColor)' }}>
        <Input value={searchQ} onChange={e=>onSearch(e.target.value)} placeholder="Search nodes…"
          startAdornment="⌕" aria-label="Search palette" style={{ width:'100%' }} />
      </div>
      <div style={{ flex:1, overflow:'auto' }}>
        {Object.entries(PALETTE_NODES).map(([cat, items]) => {
          const filtered = items.filter(i => !searchQ || i.toLowerCase().includes(searchQ.toLowerCase()));
          if (!filtered.length) return null;
          const color = CATEGORY_COLORS[cat];
          return (
            <div key={cat}>
              <div onClick={() => setExpanded(p=>({...p,[cat]:!p[cat]}))} style={{
                display:'flex', alignItems:'center', gap:6, padding:'6px 10px',
                cursor:'pointer', userSelect:'none',
                background: expanded[cat] ? 'var(--salt-container-tertiary-background)' : 'transparent',
                borderBottom:'1px solid var(--salt-separable-secondary-borderColor)',
              }}>
                <span style={{ fontSize:9, color:'var(--salt-content-secondary-foreground)' }}>{expanded[cat]?'▼':'▶'}</span>
                <StatusIndicator status={cat==='UI'?'info':cat==='Logic'?'info':cat==='Infra'?'warning':cat==='Data'?'success':'error'} />
                <span style={{ fontSize:11, fontWeight:600, color }}>{cat}</span>
              </div>
              {expanded[cat] && filtered.map(item => (
                <div key={item} style={{
                  display:'flex', alignItems:'center', gap:8, padding:'5px 10px 5px 22px',
                  cursor:'grab', fontSize:11, color:'var(--salt-content-primary-foreground)',
                  borderBottom:'1px solid var(--salt-separable-secondary-borderColor)',
                  transition:'background 0.1s',
                }}
                onMouseEnter={e=>e.currentTarget.style.background='var(--salt-container-tertiary-background)'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                  <span style={{ width:4, height:4, borderRadius:'50%', background:color, flexShrink:0 }} />
                  {item}
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function FloatingToolbar({ activeTool, onToolChange }) {
  const tools = [
    { id:'select', icon:'↖', label:'Select' }, { id:'pan', icon:'✋', label:'Pan' },
    { id:'edge', icon:'→', label:'Add Edge' }, { id:'node', icon:'+', label:'Add Node' },
    null,
    { id:'layout', icon:'⊞', label:'Auto-layout' }, { id:'undo', icon:'↩', label:'Undo' },
    { id:'redo', icon:'↪', label:'Redo' },
  ];
  return (
    <div style={{
      position:'absolute', top:14, left:'50%', transform:'translateX(-50%)',
      background:'var(--salt-container-secondary-background)', border:'1px solid var(--salt-separable-primary-borderColor)',
      borderRadius:5, boxShadow:'var(--salt-overlayable-shadow)', padding:'4px',
      display:'flex', gap:2, zIndex:10,
    }}>
      {tools.map((t,i) => t === null
        ? <div key={i} style={{ width:1, margin:'2px 3px', background:'var(--salt-separable-primary-borderColor)' }} />
        : (
          <Tooltip key={t.id} content={t.label}>
            <button onClick={() => onToolChange(t.id)} style={{
              background: activeTool===t.id ? 'var(--salt-accent-background)' : 'transparent',
              border:'none', borderRadius:3, color: activeTool===t.id ? '#fff' : 'var(--salt-content-secondary-foreground)',
              width:28, height:28, cursor:'pointer', fontSize:13, display:'flex', alignItems:'center', justifyContent:'center',
              transition:'all 0.1s',
            }}
            onMouseEnter={e=>{ if(activeTool!==t.id) e.currentTarget.style.background='var(--salt-container-tertiary-background)'; }}
            onMouseLeave={e=>{ if(activeTool!==t.id) e.currentTarget.style.background='transparent'; }}>
              {t.icon}
            </button>
          </Tooltip>
        )
      )}
    </div>
  );
}

function Minimap({ nodes }) {
  const scale = 0.18;
  return (
    <div style={{
      position:'absolute', bottom:14, right:14, width:160, height:100,
      background:'var(--salt-container-tertiary-background)', border:'1px solid var(--salt-separable-secondary-borderColor)',
      borderRadius:4, overflow:'hidden', zIndex:10,
    }}>
      <div style={{ position:'relative', width:'100%', height:'100%' }}>
        {nodes.map(n => (
          <div key={n.id} style={{
            position:'absolute', left: n.x*scale, top: n.y*scale,
            width: NODE_W*scale, height: NODE_H*scale,
            background: CATEGORY_COLORS[n.category] + '33',
            border:`1px solid ${CATEGORY_COLORS[n.category]}66`,
            borderRadius:1,
          }} />
        ))}
      </div>
    </div>
  );
}

function FilterRail({ filters, onFilterChange, onClear }) {
  const hasActive = filters.search || filters.status || filters.category;
  const activeChips = [
    filters.status && { label: `Status: ${filters.status}`, key:'status' },
    filters.category && { label: `Category: ${filters.category}`, key:'category' },
  ].filter(Boolean);
  return (
    <div style={{ background:'var(--salt-container-secondary-background)', borderBottom:'1px solid var(--salt-separable-primary-borderColor)', flexShrink:0 }}>
      <div style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 12px', flexWrap:'wrap' }}>
        <Input value={filters.search} onChange={e=>onFilterChange('search',e.target.value)}
          placeholder="Search canvas…" startAdornment="⌕" aria-label="Search canvas" style={{ width:220 }} />
        <Dropdown value={filters.status} options={['APPROVED','DRAFT','SUBMITTED','IN_REVIEW','CHANGES_REQUESTED','REJECTED']}
          placeholder="Status" onChange={v=>onFilterChange('status',v)} aria-label="Status filter" style={{ width:130 }} />
        <Dropdown value={filters.category} options={['UI','Logic','Infra','Data','External']}
          placeholder="Category" onChange={v=>onFilterChange('category',v)} aria-label="Category filter" style={{ width:120 }} />
        <ToggleButtonGroup
          options={[{value:'standard',label:'Standard'},{value:'swimlanes',label:'Swim Lanes'}]}
          value={filters.viewMode} onChange={v=>onFilterChange('viewMode',v)} />
        {hasActive && (
          <Button appearance="transparent" onClick={onClear} size="sm" aria-label="Clear filters">
            <span style={{ fontSize:11 }}>✕ Clear</span>
          </Button>
        )}
      </div>
      {activeChips.length > 0 && (
        <div style={{ display:'flex', gap:6, padding:'0 12px 6px' }}>
          {activeChips.map(c => (
            <Chip key={c.key} appearance="bordered" sentiment="info" onClose={()=>onFilterChange(c.key,'')}>
              {c.label}
            </Chip>
          ))}
        </div>
      )}
    </div>
  );
}

function SwimLanes({ nodes, categories }) {
  const laneH = 180;
  return (
    <>
      {categories.map((cat, i) => (
        <div key={cat} style={{
          position:'absolute', left:0, right:0, top: i*laneH, height: laneH,
          background: i%2===0 ? 'transparent' : 'rgba(255,255,255,0.015)',
          borderBottom:'1px solid var(--salt-separable-secondary-borderColor)',
          display:'flex', alignItems:'center', pointerEvents:'none',
        }}>
          <span style={{ position:'absolute', left:8, fontSize:10, color:CATEGORY_COLORS[cat], fontWeight:700, letterSpacing:'0.05em', opacity:0.7 }}>
            {cat}
          </span>
        </div>
      ))}
    </>
  );
}

function FlowCanvas({ onNodeSelect, selectedNode, onOpenDetail, onExport, defaultViewMode }) {
  const [nodes] = React.useState(() => { window.__FLOW_NODES = INITIAL_NODES; return INITIAL_NODES; });
  const [activeTool, setActiveTool] = React.useState('select');
  const [paletteSearch, setPaletteSearch] = React.useState('');
  const [filters, setFilters] = React.useState({ search:'', status:'', category:'', viewMode: defaultViewMode || 'standard' });
  const [pan, setPan] = React.useState({ x:30, y:30 });
  const [dragging, setDragging] = React.useState(null);
  const canvasRef = React.useRef();

  const handleFilterChange = (k, v) => setFilters(p=>({...p,[k]:v}));
  const clearFilters = () => setFilters(p=>({...p, search:'', status:'', category:''}));

  const visibleNodes = nodes.filter(n => {
    if (filters.search && !n.label.toLowerCase().includes(filters.search.toLowerCase()) && !n.tags.some(t=>t.includes(filters.search.toLowerCase()))) return false;
    if (filters.status && n.status !== filters.status) return false;
    if (filters.category && n.category !== filters.category) return false;
    return true;
  });
  const hiddenIds = new Set(nodes.filter(n=>!visibleNodes.includes(n)).map(n=>n.id));
  const swimCategories = ['UI','Logic','Infra','Data','External'];

  return (
    <div style={{ display:'flex', flexDirection:'column', flex:1, overflow:'hidden' }}>
      <FilterRail filters={filters} onFilterChange={handleFilterChange} onClear={clearFilters} />
      <div style={{ display:'flex', flex:1, overflow:'hidden' }}>
        <PaletteSidebar searchQ={paletteSearch} onSearch={setPaletteSearch} />
        {/* Canvas area */}
        <div ref={canvasRef} style={{ flex:1, position:'relative', overflow:'hidden', background:'var(--salt-container-primary-background)', cursor: activeTool==='pan'?'grab':'default' }}
          onClick={e=>{ if(e.target===canvasRef.current) onNodeSelect(null); }}>
          {/* Dot-grid background */}
          <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%', pointerEvents:'none' }}>
            <defs>
              <pattern id="grid" x={pan.x%20} y={pan.y%20} width="20" height="20" patternUnits="userSpaceOnUse">
                <circle cx="1" cy="1" r="0.7" fill="var(--salt-separable-primary-borderColor)" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>

          <div style={{ position:'absolute', transform:`translate(${pan.x}px,${pan.y}px)`, transformOrigin:'0 0' }}>
            {filters.viewMode === 'swimlanes' && <SwimLanes nodes={nodes} categories={swimCategories} />}
            <EdgeSvg nodes={nodes} edges={INITIAL_EDGES} selected={selectedNode} />
            {nodes.map(n => (
              <div key={n.id} style={{ opacity: hiddenIds.has(n.id) ? 0.2 : 1, transition:'opacity 0.2s' }}>
                <FlowNode node={n} selected={selectedNode===n.id} onSelect={onNodeSelect} onOpenDetail={onOpenDetail} />
              </div>
            ))}
          </div>

          <FloatingToolbar activeTool={activeTool} onToolChange={setActiveTool} />
          <Minimap nodes={nodes} />

          {/* Bottom controls */}
          <div style={{ position:'absolute', bottom:14, left:14, display:'flex', gap:8, zIndex:10 }}>
            <Button appearance="bordered" size="sm" aria-label="Load spec">
              <span>↑</span> Load Spec
            </Button>
          </div>
          <div style={{ position:'absolute', bottom:14, right:180, display:'flex', gap:8, zIndex:10 }}>
            <Button appearance="solid" sentiment="accented" size="sm" aria-label="Export" onClick={onExport}>
              Export ↓
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { FlowCanvas, CATEGORY_COLORS, STATUS_CONFIGS });
