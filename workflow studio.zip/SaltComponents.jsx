// Simulated Salt DS component library
// Exports: Button, Chip, StatusIndicator, Input, Dropdown, Tabs, Tab,
//          Card, FormField, FormFieldLabel, Text, Badge, Tooltip, Menu

// ─── Button ──────────────────────────────────────────────────────────────────
function Button({ children, appearance = 'solid', sentiment = 'neutral', size = 'md',
  onClick, disabled, style, className = '', title, 'aria-label': ariaLabel }) {
  const base = {
    display: 'inline-flex', alignItems: 'center', gap: 5, cursor: disabled ? 'not-allowed' : 'pointer',
    border: '1px solid transparent', borderRadius: 3, fontFamily: 'var(--salt-text-fontFamily)',
    fontSize: 12, fontWeight: 500, padding: size === 'sm' ? '3px 8px' : '5px 12px',
    transition: 'all 0.12s', opacity: disabled ? 0.4 : 1, whiteSpace: 'nowrap',
    userSelect: 'none', outline: 'none',
  };
  let colors = {};
  if (appearance === 'solid') {
    if (sentiment === 'accented') colors = { background: 'var(--salt-accent-background)', color: '#fff', borderColor: 'transparent' };
    else if (sentiment === 'caution') colors = { background: '#b45309', color: '#fff', borderColor: 'transparent' };
    else if (sentiment === 'negative') colors = { background: '#b91c1c', color: '#fff', borderColor: 'transparent' };
    else colors = { background: 'var(--salt-container-tertiary-background)', color: 'var(--salt-content-primary-foreground)', borderColor: 'var(--salt-separable-primary-borderColor)' };
  } else if (appearance === 'bordered') {
    if (sentiment === 'accented') colors = { background: 'transparent', color: 'var(--salt-accent-foreground)', borderColor: 'var(--salt-accent-foreground)' };
    else if (sentiment === 'caution') colors = { background: 'transparent', color: 'var(--salt-status-warning-foreground)', borderColor: 'var(--salt-status-warning-foreground)' };
    else if (sentiment === 'negative') colors = { background: 'transparent', color: 'var(--salt-status-error-foreground)', borderColor: 'var(--salt-status-error-foreground)' };
    else colors = { background: 'transparent', color: 'var(--salt-content-primary-foreground)', borderColor: 'var(--salt-separable-primary-borderColor)' };
  } else if (appearance === 'transparent') {
    colors = { background: 'transparent', color: 'var(--salt-content-secondary-foreground)', borderColor: 'transparent' };
  }
  const [hov, setHov] = React.useState(false);
  const hovStyle = hov && !disabled ? { filter: 'brightness(1.15)', color: appearance === 'transparent' ? 'var(--salt-content-primary-foreground)' : undefined } : {};
  return (
    <button style={{ ...base, ...colors, ...hovStyle, ...style }} className={className}
      onClick={disabled ? undefined : onClick} disabled={disabled} title={title} aria-label={ariaLabel}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}>
      {children}
    </button>
  );
}

// ─── Chip ─────────────────────────────────────────────────────────────────────
function Chip({ children, appearance = 'solid', sentiment, onClose, onClick, style }) {
  const sentimentColors = {
    positive: { bg: 'var(--salt-status-success-background)', color: 'var(--salt-status-success-foreground)', border: 'var(--salt-status-success-foreground)' },
    caution:  { bg: 'var(--salt-status-warning-background)', color: 'var(--salt-status-warning-foreground)', border: 'var(--salt-status-warning-foreground)' },
    negative: { bg: 'var(--salt-status-error-background)',   color: 'var(--salt-status-error-foreground)',   border: 'var(--salt-status-error-foreground)' },
    info:     { bg: 'var(--salt-status-info-background)',    color: 'var(--salt-status-info-foreground)',    border: 'var(--salt-status-info-foreground)' },
  };
  const sc = sentimentColors[sentiment] || { bg: 'var(--salt-container-tertiary-background)', color: 'var(--salt-content-secondary-foreground)', border: 'var(--salt-separable-primary-borderColor)' };
  const isBordered = appearance === 'bordered' || appearance === 'transparent';
  return (
    <span onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '2px 7px', borderRadius: 2, fontSize: 11, fontWeight: 500, lineHeight: '16px',
      background: isBordered ? 'transparent' : sc.bg, color: sc.color,
      border: `1px solid ${isBordered ? sc.border : 'transparent'}`,
      cursor: onClick ? 'pointer' : 'default', whiteSpace: 'nowrap', ...style
    }}>
      {children}
      {onClose && <span onClick={e => { e.stopPropagation(); onClose(); }} style={{ cursor: 'pointer', marginLeft: 2, opacity: 0.7 }}>×</span>}
    </span>
  );
}

// ─── StatusIndicator ─────────────────────────────────────────────────────────
function StatusIndicator({ status = 'info', size = 'sm' }) {
  const colors = { info: '#60a5fa', success: '#4ade80', warning: '#fbbf24', error: '#f87171' };
  const sz = size === 'sm' ? 7 : 10;
  return <span style={{ display: 'inline-block', width: sz, height: sz, borderRadius: '50%', background: colors[status] || colors.info, flexShrink: 0 }} />;
}

// ─── Badge ────────────────────────────────────────────────────────────────────
function Badge({ children }) {
  return (
    <span style={{
      position: 'absolute', top: -4, right: -5, minWidth: 14, height: 14, padding: '0 3px',
      background: '#ef4444', color: '#fff', borderRadius: 7, fontSize: 9, fontWeight: 700,
      display: 'flex', alignItems: 'center', justifyContent: 'center', lineHeight: 1,
    }}>{children}</span>
  );
}

// ─── Input ────────────────────────────────────────────────────────────────────
function Input({ value, onChange, placeholder, startAdornment, readOnly, style, 'aria-label': ariaLabel, type = 'text' }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6,
      background: 'var(--salt-container-tertiary-background)', border: '1px solid var(--salt-separable-primary-borderColor)',
      borderRadius: 3, padding: '4px 8px', minWidth: 0, ...style }}>
      {startAdornment && <span style={{ color: 'var(--salt-content-secondary-foreground)', fontSize: 12 }}>{startAdornment}</span>}
      <input type={type} value={value} onChange={onChange} readOnly={readOnly} placeholder={placeholder} aria-label={ariaLabel}
        style={{ background: 'transparent', border: 'none', color: 'var(--salt-content-primary-foreground)',
          fontFamily: 'var(--salt-text-fontFamily)', fontSize: 12, outline: 'none', width: '100%', minWidth: 0 }} />
    </span>
  );
}

// ─── Dropdown ────────────────────────────────────────────────────────────────
function Dropdown({ value, options = [], onChange, placeholder = 'Select…', style, 'aria-label': ariaLabel }) {
  return (
    <select value={value} onChange={e => onChange && onChange(e.target.value)} aria-label={ariaLabel}
      style={{ background: 'var(--salt-container-tertiary-background)', border: '1px solid var(--salt-separable-primary-borderColor)',
        borderRadius: 3, color: value ? 'var(--salt-content-primary-foreground)' : 'var(--salt-content-secondary-foreground)',
        fontFamily: 'var(--salt-text-fontFamily)', fontSize: 12, padding: '4px 8px', cursor: 'pointer', outline: 'none',
        appearance: 'none', paddingRight: 22, ...style }}>
      <option value="" disabled>{placeholder}</option>
      {options.map(o => <option key={o.value ?? o} value={o.value ?? o}>{o.label ?? o}</option>)}
    </select>
  );
}

// ─── Tabs ─────────────────────────────────────────────────────────────────────
function Tabs({ tabs, activeTab, onTabChange, children, headerExtra }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        borderBottom: '1px solid var(--salt-separable-primary-borderColor)', flexShrink: 0 }}>
        <div style={{ display: 'flex' }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => onTabChange(t.id)} style={{
              background: 'none', border: 'none', borderBottom: activeTab === t.id ? '2px solid var(--salt-accent-foreground)' : '2px solid transparent',
              color: activeTab === t.id ? 'var(--salt-content-primary-foreground)' : 'var(--salt-content-secondary-foreground)',
              padding: '8px 14px', fontSize: 12, fontWeight: activeTab === t.id ? 600 : 400, cursor: 'pointer',
              fontFamily: 'var(--salt-text-fontFamily)', display: 'flex', alignItems: 'center', gap: 5,
              marginBottom: -1, transition: 'color 0.12s',
            }}>
              {t.label}
              {t.badge && <StatusIndicator status="error" size="sm" />}
            </button>
          ))}
        </div>
        {headerExtra}
      </div>
      <div style={{ flex: 1, overflow: 'auto', padding: '12px' }}>{children}</div>
    </div>
  );
}

// ─── Card ─────────────────────────────────────────────────────────────────────
function Card({ children, style, onClick, accent, elevated }) {
  const [hov, setHov] = React.useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)} style={{
      background: 'var(--salt-container-card-background)',
      border: `1px solid ${hov && onClick ? 'var(--salt-accent-foreground)' : 'var(--salt-separable-primary-borderColor)'}`,
      borderLeft: accent ? `3px solid ${accent}` : undefined,
      borderRadius: 4, boxShadow: elevated ? 'var(--salt-overlayable-shadow)' : 'var(--salt-card-shadow)',
      cursor: onClick ? 'pointer' : 'default', transition: 'border-color 0.12s', ...style
    }}>
      {children}
    </div>
  );
}

// ─── FormField ────────────────────────────────────────────────────────────────
function FormField({ label, children, error, style }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4, ...style }}>
      {label && <label style={{ fontSize: 11, color: 'var(--salt-content-secondary-foreground)', fontWeight: 500 }}>{label}</label>}
      {children}
      {error && <span style={{ fontSize: 11, color: 'var(--salt-status-error-foreground)' }}>{error}</span>}
    </div>
  );
}

// ─── Tooltip wrapper ─────────────────────────────────────────────────────────
function Tooltip({ content, children }) {
  const [vis, setVis] = React.useState(false);
  return (
    <span style={{ position: 'relative', display: 'inline-flex' }}
      onMouseEnter={() => setVis(true)} onMouseLeave={() => setVis(false)}>
      {children}
      {vis && <span style={{
        position: 'absolute', bottom: '100%', left: '50%', transform: 'translateX(-50%)', marginBottom: 6,
        background: '#0d1117', border: '1px solid var(--salt-separable-primary-borderColor)',
        color: 'var(--salt-content-primary-foreground)', fontSize: 11, padding: '5px 9px', borderRadius: 3,
        whiteSpace: 'nowrap', zIndex: 9999, boxShadow: 'var(--salt-overlayable-shadow)', maxWidth: 260, whiteSpace: 'normal',
      }}>{content}</span>}
    </span>
  );
}

// ─── Menu (overflow) ─────────────────────────────────────────────────────────
function Menu({ items, trigger }) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef();
  React.useEffect(() => {
    const h = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  return (
    <span ref={ref} style={{ position: 'relative', display: 'inline-flex' }}>
      <span onClick={e => { e.stopPropagation(); setOpen(p => !p); }}>{trigger}</span>
      {open && (
        <div style={{
          position: 'absolute', top: '100%', right: 0, zIndex: 9999, minWidth: 160,
          background: 'var(--salt-container-secondary-background)', border: '1px solid var(--salt-separable-primary-borderColor)',
          borderRadius: 4, boxShadow: 'var(--salt-overlayable-shadow)', padding: '4px 0',
        }}>
          {items.map((item, i) => (
            <div key={i} onClick={() => { item.onClick?.(); setOpen(false); }} style={{
              padding: '6px 14px', fontSize: 12, cursor: 'pointer', color: item.danger ? 'var(--salt-status-error-foreground)' : 'var(--salt-content-primary-foreground)',
              transition: 'background 0.1s',
            }} onMouseEnter={e => e.currentTarget.style.background = 'var(--salt-container-tertiary-background)'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
              {item.label}
            </div>
          ))}
        </div>
      )}
    </span>
  );
}

// ─── Dialog ───────────────────────────────────────────────────────────────────
function Dialog({ open, title, onClose, children, actions, width = 480 }) {
  if (!open) return null;
  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 10000, background: 'rgba(0,0,0,0.65)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: 'var(--salt-container-secondary-background)', border: '1px solid var(--salt-separable-primary-borderColor)',
        borderRadius: 5, boxShadow: 'var(--salt-overlayable-shadow)', width, maxWidth: '90vw', maxHeight: '85vh',
        display: 'flex', flexDirection: 'column',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 18px', borderBottom: '1px solid var(--salt-separable-primary-borderColor)', flexShrink: 0 }}>
          <span style={{ fontSize: 15, fontWeight: 600 }}>{title}</span>
          <Button appearance="transparent" onClick={onClose} aria-label="Close dialog">✕</Button>
        </div>
        <div style={{ padding: '16px 18px', overflow: 'auto', flex: 1 }}>{children}</div>
        {actions && <div style={{ padding: '12px 18px', borderTop: '1px solid var(--salt-separable-primary-borderColor)', display: 'flex', gap: 8, justifyContent: 'flex-end', flexShrink: 0 }}>{actions}</div>}
      </div>
    </div>
  );
}

// ─── Banner ───────────────────────────────────────────────────────────────────
function Banner({ sentiment = 'info', children }) {
  const colors = {
    info:     { bg: 'var(--salt-status-info-background)',    border: 'var(--salt-status-info-foreground)',    color: 'var(--salt-status-info-foreground)' },
    caution:  { bg: 'var(--salt-status-warning-background)', border: 'var(--salt-status-warning-foreground)', color: 'var(--salt-status-warning-foreground)' },
    negative: { bg: 'var(--salt-status-error-background)',   border: 'var(--salt-status-error-foreground)',   color: 'var(--salt-status-error-foreground)' },
  };
  const c = colors[sentiment] || colors.info;
  return (
    <div style={{ background: c.bg, border: `1px solid ${c.border}33`, borderLeft: `3px solid ${c.border}`, borderRadius: 3, padding: '8px 12px', fontSize: 12, color: c.color, lineHeight: 1.5 }}>
      {children}
    </div>
  );
}

// ─── Textarea ─────────────────────────────────────────────────────────────────
function Textarea({ value, onChange, placeholder, rows = 3, readOnly, style, 'aria-label': ariaLabel }) {
  return (
    <textarea value={value} onChange={onChange} placeholder={placeholder} readOnly={readOnly} rows={rows} aria-label={ariaLabel}
      style={{ background: 'var(--salt-container-tertiary-background)', border: '1px solid var(--salt-separable-primary-borderColor)',
        borderRadius: 3, color: 'var(--salt-content-primary-foreground)', fontFamily: 'var(--salt-text-fontFamily)', fontSize: 12,
        padding: '6px 8px', resize: 'vertical', outline: 'none', width: '100%', ...style }} />
  );
}

// ─── ToggleButtonGroup ────────────────────────────────────────────────────────
function ToggleButtonGroup({ options, value, onChange }) {
  return (
    <div style={{ display: 'inline-flex', border: '1px solid var(--salt-separable-primary-borderColor)', borderRadius: 3, overflow: 'hidden' }}>
      {options.map(o => (
        <button key={o.value} onClick={() => onChange(o.value)} style={{
          background: value === o.value ? 'var(--salt-container-tertiary-background)' : 'transparent',
          border: 'none', borderLeft: '1px solid var(--salt-separable-primary-borderColor)',
          color: value === o.value ? 'var(--salt-content-primary-foreground)' : 'var(--salt-content-secondary-foreground)',
          padding: '4px 10px', fontSize: 11, cursor: 'pointer', fontFamily: 'var(--salt-text-fontFamily)',
          fontWeight: value === o.value ? 600 : 400, transition: 'all 0.1s',
        }}>{o.label}</button>
      ))}
    </div>
  );
}

Object.assign(window, {
  Button, Chip, StatusIndicator, Badge, Input, Dropdown, Tabs, Card,
  FormField, Tooltip, Menu, Dialog, Banner, Textarea, ToggleButtonGroup
});
