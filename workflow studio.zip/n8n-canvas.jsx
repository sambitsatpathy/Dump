// n8n-style canvas + nodes + ports + curved edges

const CAT_COLORS = {
  UI:       '#9b5cf6',
  Logic:    '#3b82f6',
  Infra:    '#ff6d5a',
  Data:     '#10b981',
  External: '#ec4899',
  Trigger:  '#13a463',
};

const STATUS_META = {
  APPROVED:           { label:'Approved',          color:'success', dot:'#10b981' },
  DRAFT:              { label:'Draft',             color:'neutral', dot:'#909399' },
  SUBMITTED:          { label:'Submitted',         color:'info',    dot:'#3b82f6' },
  IN_REVIEW:          { label:'In Review',         color:'warning', dot:'#f5a623' },
  CHANGES_REQUESTED:  { label:'Changes requested', color:'warning', dot:'#f5a623' },
  REJECTED:           { label:'Rejected',          color:'danger',  dot:'#dc3545' },
};

// SVG icons for each node type (n8n-style — simple bold glyphs)
const NODE_ICONS = {
  'order-form':       <path d="M8 6h16v2H8zm0 6h16v2H8zm0 6h10v2H8zM22 18h4l-4 4v-4z" fill="currentColor"/>,
  'validate-order':   <path d="M14 16l3 3 7-7-2-2-5 5-1-1-2 2zM6 6h20v20H6z" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>,
  'payment-gateway':  <><rect x="5" y="9" width="22" height="14" rx="2" fill="none" stroke="currentColor" strokeWidth="2"/><path d="M5 13h22" stroke="currentColor" strokeWidth="2"/><rect x="9" y="17" width="4" height="2" fill="currentColor"/></>,
  'send-confirmation':<path d="M4 8l12 8 12-8v14H4zm0 0l12 8 12-8" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>,
  'audit-log':        <><path d="M8 6h12l4 4v16H8z" fill="none" stroke="currentColor" strokeWidth="2"/><path d="M20 6v4h4M11 14h10M11 18h10M11 22h7" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></>,
  'route-request':    <><path d="M6 8h8v6h12M14 14v10h12" fill="none" stroke="currentColor" strokeWidth="2"/><circle cx="6" cy="8" r="2" fill="currentColor"/><circle cx="26" cy="14" r="2" fill="currentColor"/><circle cx="26" cy="24" r="2" fill="currentColor"/></>,
  'webhook-trigger':  <><circle cx="16" cy="10" r="4" fill="none" stroke="currentColor" strokeWidth="2"/><path d="M8 26l5-9M24 26l-5-9M11 26h12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></>,
  'default':          <rect x="9" y="9" width="14" height="14" rx="2" fill="none" stroke="currentColor" strokeWidth="2"/>,
};

const INITIAL_NODES = [
  { id:'n0', label:'Webhook',             type:'webhook-trigger', category:'Trigger',  version:'v1.0.0', status:'APPROVED',          tags:['trigger'],         x:80,  y:240, isTrigger:true,  comments:0 },
  { id:'n1', label:'order-form',          type:'order-form',      category:'UI',       version:'v1.1.0', status:'APPROVED',          tags:['form','checkout'], x:240, y:160, pinned:true,     comments:0 },
  { id:'n2', label:'validate-order',      type:'validate-order',  category:'Logic',    version:'v2.0.1', status:'IN_REVIEW',         tags:['validation'],      x:240, y:340, comments:2 },
  { id:'n3', label:'payment-gateway',     type:'payment-gateway', category:'Infra',    version:'v1.3.0', status:'APPROVED',          tags:['payment'],         x:440, y:160, newerVersion:'v1.4.0', comments:0 },
  { id:'n4', label:'route-request',       type:'route-request',   category:'Logic',    version:'v1.0.0', status:'CHANGES_REQUESTED', tags:['routing'],         x:440, y:340, comments:1 },
  { id:'n5', label:'send-confirmation',   type:'send-confirmation', category:'Data',   version:'v1.0.2', status:'DRAFT',             tags:['email'],           x:640, y:200, comments:1 },
  { id:'n6', label:'audit-log',           type:'audit-log',       category:'Data',     version:'v1.1.1', status:'REJECTED',          tags:['audit'],           x:640, y:380, comments:3 },
];

const INITIAL_EDGES = [
  { id:'e0', src:'n0', tgt:'n1' }, { id:'e1', src:'n0', tgt:'n2' },
  { id:'e2', src:'n1', tgt:'n3' }, { id:'e3', src:'n2', tgt:'n4' },
  { id:'e4', src:'n3', tgt:'n5' }, { id:'e5', src:'n4', tgt:'n6' },
];

// Sticky note data
const STICKIES = [
  { id:'s1', x: 60, y:  60, w:200, h:90, text:'Entry trigger — fires on POST /orders' },
  { id:'s2', x:620, y: 80, w:220, h:80, text:'After payment success, branch to email + audit' },
];

const NODE_SIZE = 90;     // n8n nodes are square
const PORT_RADIUS = 6;

function getNodeCenter(n) { return { cx: n.x + NODE_SIZE/2, cy: n.y + NODE_SIZE/2 }; }
function getOutputPort(n) { return { x: n.x + NODE_SIZE,    y: n.y + NODE_SIZE/2 }; }
function getInputPort(n)  { return { x: n.x,                y: n.y + NODE_SIZE/2 }; }

// ─── Edges ────────────────────────────────────────────────────────────────────
function EdgeLayer({ nodes, edges, selected }) {
  const findNode = id => nodes.find(n => n.id === id);
  return (
    <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%', pointerEvents:'none', overflow:'visible' }}>
      <defs>
        <marker id="n8n-arrow" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto" markerUnits="strokeWidth">
          <path d="M0,0 L6,3 L0,6 z" fill="#909399" />
        </marker>
        <marker id="n8n-arrow-sel" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto" markerUnits="strokeWidth">
          <path d="M0,0 L6,3 L0,6 z" fill="#ff6d5a" />
        </marker>
      </defs>
      {edges.map(e => {
        const s = findNode(e.src), t = findNode(e.tgt);
        if (!s || !t) return null;
        const p1 = getOutputPort(s), p2 = getInputPort(t);
        // Tangent length scales with horizontal distance for that n8n-curve feel
        const dx = Math.max(60, Math.abs(p2.x - p1.x) * 0.5);
        const sel = selected === e.src || selected === e.tgt;
        const stroke = sel ? '#ff6d5a' : '#909399';
        return (
          <g key={e.id}>
            <path
              d={`M${p1.x},${p1.y} C${p1.x+dx},${p1.y} ${p2.x-dx},${p2.y} ${p2.x-8},${p2.y}`}
              fill="none" stroke={stroke} strokeWidth={sel?2.5:2}
              markerEnd={`url(#${sel?'n8n-arrow-sel':'n8n-arrow'})`}
              opacity={sel?1:0.75}
              style={{transition:'stroke 0.15s, opacity 0.15s'}}
            />
            {/* "+" insert button at midpoint */}
            <g transform={`translate(${(p1.x+p2.x)/2},${(p1.y+p2.y)/2})`} opacity={0}
              style={{transition:'opacity 0.15s'}}
              onMouseEnter={e=>e.currentTarget.setAttribute('opacity','1')}
              onMouseLeave={e=>e.currentTarget.setAttribute('opacity','0')}>
              <circle r="8" fill="#fff" stroke="#dbdcdf" strokeWidth="1"/>
              <path d="M-4,0 L4,0 M0,-4 L0,4" stroke="#525457" strokeWidth="1.5" strokeLinecap="round"/>
            </g>
          </g>
        );
      })}
    </svg>
  );
}

// ─── Single Node ─────────────────────────────────────────────────────────────
function FlowNode({ node, selected, onSelect, onOpenDetail }) {
  const [hov, setHov] = React.useState(false);
  const catColor = CAT_COLORS[node.category] || '#909399';
  const status = STATUS_META[node.status] || STATUS_META.DRAFT;
  const icon = NODE_ICONS[node.type] || NODE_ICONS.default;
  const isTrigger = node.isTrigger;

  return (
    <div onClick={e=>{e.stopPropagation();onSelect(node.id);}}
      onDoubleClick={e=>{e.stopPropagation();onOpenDetail(node);}}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{
        position:'absolute', left:node.x, top:node.y,
        width:NODE_SIZE, height:NODE_SIZE,
        cursor:'pointer', userSelect:'none', zIndex: selected?5:1,
      }}>
      {/* Node body */}
      <div style={{
        position:'absolute', inset:0,
        background:'#fff',
        border: selected ? `2px solid #ff6d5a` : `2px solid ${hov?'#909399':'#e4e4e7'}`,
        borderRadius: isTrigger ? '20px 8px 8px 20px' : 8,
        boxShadow: selected
          ? '0 0 0 4px rgba(255,109,90,0.15), 0 4px 12px rgba(0,0,0,0.08)'
          : (hov ? '0 4px 14px rgba(0,0,0,0.1)' : '0 1px 3px rgba(0,0,0,0.06)'),
        transition:'all 0.15s',
        display:'flex', alignItems:'center', justifyContent:'center',
      }}>
        {/* Colored icon block */}
        <div style={{
          width:54, height:54, borderRadius:6,
          background: catColor,
          display:'flex', alignItems:'center', justifyContent:'center',
          color:'#fff', flexShrink:0,
        }}>
          <svg width="32" height="32" viewBox="0 0 32 32">{icon}</svg>
        </div>

        {/* Top-right status indicator */}
        <div style={{
          position:'absolute', top:-7, right:-7,
          display:'flex', gap:3,
        }}>
          {node.pinned && (
            <Tooltip content="Pinned data">
              <span style={{
                width:18, height:18, borderRadius:'50%',
                background:'#fff', border:'1.5px solid #f5a623',
                display:'flex',alignItems:'center',justifyContent:'center',
                fontSize:10, color:'#f5a623',
              }}>📌</span>
            </Tooltip>
          )}
          <Tooltip content={status.label}>
            <span style={{
              width:14, height:14, borderRadius:'50%',
              background: status.dot, border:'2px solid #fff',
              boxShadow:'0 1px 2px rgba(0,0,0,0.15)',
            }} />
          </Tooltip>
        </div>

        {/* Newer-version chevron */}
        {node.newerVersion && (
          <div style={{ position:'absolute', top:-7, left:-7 }}>
            <Tooltip content={`Newer version available: ${node.newerVersion}`}>
              <span style={{
                width:18, height:18, borderRadius:'50%',
                background:'#10b981', color:'#fff',
                display:'flex',alignItems:'center',justifyContent:'center',
                fontSize:11, fontWeight:700, boxShadow:'0 1px 2px rgba(0,0,0,0.15)',
              }}>↑</span>
            </Tooltip>
          </div>
        )}
      </div>

      {/* Input port */}
      {!isTrigger && (
        <div style={{
          position:'absolute', left:-PORT_RADIUS-2, top:NODE_SIZE/2-PORT_RADIUS,
          width:PORT_RADIUS*2+4, height:PORT_RADIUS*2+4,
          display:'flex',alignItems:'center',justifyContent:'center',
        }}>
          <span style={{
            width: PORT_RADIUS*2, height: PORT_RADIUS*2, borderRadius:'50%',
            background:'#909399', border:'2px solid #fff',
            boxShadow:'0 0 0 1px #dbdcdf',
          }} />
        </div>
      )}
      {/* Output port */}
      <div style={{
        position:'absolute', right:-PORT_RADIUS-2, top:NODE_SIZE/2-PORT_RADIUS,
        width:PORT_RADIUS*2+4, height:PORT_RADIUS*2+4,
        display:'flex',alignItems:'center',justifyContent:'center',
      }}>
        <span style={{
          width: PORT_RADIUS*2, height: PORT_RADIUS*2, borderRadius:'50%',
          background: hov?'#ff6d5a':'#909399', border:'2px solid #fff',
          boxShadow:'0 0 0 1px #dbdcdf', transition:'background 0.12s',
        }} />
      </div>

      {/* Label below */}
      <div style={{
        position:'absolute', top:NODE_SIZE+8, left:'50%', transform:'translateX(-50%)',
        textAlign:'center', whiteSpace:'nowrap',
      }}>
        <div style={{ fontSize:12.5, fontWeight:600, color:'#1f1f1f', marginBottom:2 }}>{node.label}</div>
        <div style={{ fontSize:10.5, color:'#909399', fontFamily:'ui-monospace,"SF Mono",monospace', letterSpacing:'-0.02em' }}>{node.version}</div>
      </div>

      {/* Comments badge */}
      {node.comments > 0 && (
        <div style={{
          position:'absolute', bottom:-6, right:-6,
          background:'#ff6d5a', color:'#fff',
          minWidth:18, height:18, borderRadius:9, padding:'0 5px',
          fontSize:10, fontWeight:700,
          display:'flex',alignItems:'center',justifyContent:'center',
          border:'2px solid #fff',
        }}>{node.comments}</div>
      )}
    </div>
  );
}

// ─── Sticky note ──────────────────────────────────────────────────────────────
function StickyNote({ note }) {
  return (
    <div style={{
      position:'absolute', left:note.x, top:note.y, width:note.w, minHeight:note.h,
      background:'#fff5b7', border:'1px solid #f0d870',
      borderRadius:5, padding:'10px 12px',
      fontSize:12, color:'#665e2a', lineHeight:1.5,
      boxShadow:'0 1px 3px rgba(0,0,0,0.08)',
      transform:'rotate(-0.5deg)',
    }}>
      {note.text}
    </div>
  );
}

// ─── Toolbar (top of canvas, right side) ─────────────────────────────────────
function CanvasToolbar({ filters, onFilter, onClearFilters }) {
  const hasFilters = filters.search || filters.status || filters.category;
  return (
    <div style={{
      position:'absolute', top:14, left:14, right:14,
      display:'flex', alignItems:'center', justifyContent:'space-between',
      pointerEvents:'none', zIndex:20,
    }}>
      {/* Left: filter chip rail */}
      <div style={{ display:'flex', alignItems:'center', gap:8, pointerEvents:'auto' }}>
        <div style={{
          background:'#fff', border:'1px solid #e4e4e7', borderRadius:6,
          boxShadow:'0 1px 3px rgba(0,0,0,0.06)', padding:'4px',
          display:'flex', alignItems:'center', gap:4,
        }}>
          <Input size="sm" value={filters.search} onChange={e=>onFilter('search',e.target.value)}
            placeholder="Find a node…" startIcon={
              <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><circle cx="6" cy="6" r="4.5" stroke="currentColor" strokeWidth="1.5"/><path d="M10 10l3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
            } style={{ width:200, border:'none', boxShadow:'none', height:24 }} aria-label="Search canvas" />
          <span style={{width:1,height:18,background:'#e4e4e7'}} />
          <Select size="sm" value={filters.status} onChange={v=>onFilter('status',v)}
            options={['APPROVED','DRAFT','SUBMITTED','IN_REVIEW','CHANGES_REQUESTED','REJECTED']}
            placeholder="Status" aria-label="Status filter" style={{ width:120, height:24, border:'none' }} />
          <Select size="sm" value={filters.category} onChange={v=>onFilter('category',v)}
            options={['UI','Logic','Infra','Data','External','Trigger']}
            placeholder="Category" aria-label="Category filter" style={{ width:110, height:24, border:'none' }} />
          {hasFilters && (
            <IconButton size={24} onClick={onClearFilters} aria-label="Clear filters" title="Clear filters">
              <svg width="11" height="11" viewBox="0 0 14 14" fill="none"><path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
            </IconButton>
          )}
        </div>
        <ToggleGroup options={[{value:'standard',label:'Workflow'},{value:'swimlanes',label:'Swim lanes'}]} value={filters.viewMode} onChange={v=>onFilter('viewMode',v)} />
      </div>
    </div>
  );
}

// ─── Bottom-right zoom & minimap stack ────────────────────────────────────────
function CanvasFloatControls({ zoom, onZoom, onFit, onLayout }) {
  return (
    <div style={{
      position:'absolute', bottom:18, right:18, zIndex:20,
      display:'flex', flexDirection:'column', gap:8, alignItems:'flex-end',
    }}>
      {/* Zoom stack */}
      <div style={{
        background:'#fff', border:'1px solid #e4e4e7', borderRadius:6,
        boxShadow:'0 1px 3px rgba(0,0,0,0.06)', padding:3, display:'flex', flexDirection:'column', gap:1,
      }}>
        <IconButton size={28} onClick={()=>onZoom(zoom+0.1)} aria-label="Zoom in" title="Zoom in">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 3v8M3 7h8" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"/></svg>
        </IconButton>
        <div style={{height:1,background:'#e4e4e7',margin:'2px 4px'}} />
        <IconButton size={28} onClick={()=>onZoom(zoom-0.1)} aria-label="Zoom out" title="Zoom out">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M3 7h8" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"/></svg>
        </IconButton>
        <div style={{height:1,background:'#e4e4e7',margin:'2px 4px'}} />
        <IconButton size={28} onClick={onFit} aria-label="Fit to screen" title="Fit to screen">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 5V2h3M9 2h3v3M12 9v3H9M5 12H2V9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
        </IconButton>
        <div style={{height:1,background:'#e4e4e7',margin:'2px 4px'}} />
        <IconButton size={28} onClick={onLayout} aria-label="Auto-layout" title="Auto-layout">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="2" y="2" width="4" height="4" stroke="currentColor" strokeWidth="1.4"/><rect x="8" y="2" width="4" height="4" stroke="currentColor" strokeWidth="1.4"/><rect x="2" y="8" width="4" height="4" stroke="currentColor" strokeWidth="1.4"/><rect x="8" y="8" width="4" height="4" stroke="currentColor" strokeWidth="1.4"/></svg>
        </IconButton>
      </div>
      {/* Zoom % readout */}
      <div style={{
        background:'#fff', border:'1px solid #e4e4e7', borderRadius:5,
        padding:'4px 10px', fontSize:11, color:'#525457', fontWeight:500,
        boxShadow:'0 1px 2px rgba(0,0,0,0.04)', fontFamily:'ui-monospace,monospace',
      }}>{Math.round(zoom*100)}%</div>
    </div>
  );
}

// ─── Add Node FAB ─────────────────────────────────────────────────────────────
function AddNodeFab({ onClick }) {
  return (
    <div style={{ position:'absolute', bottom:18, left:'50%', transform:'translateX(-50%)', zIndex:20 }}>
      <button onClick={onClick} aria-label="Add node" style={{
        width:48, height:48, borderRadius:'50%', background:'#ff6d5a', color:'#fff',
        border:'none', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center',
        boxShadow:'0 4px 14px rgba(255,109,90,0.35), 0 1px 3px rgba(0,0,0,0.1)',
        transition:'transform 0.12s, box-shadow 0.12s',
      }}
      onMouseEnter={e=>{e.currentTarget.style.transform='translateY(-2px)';e.currentTarget.style.boxShadow='0 6px 18px rgba(255,109,90,0.4), 0 1px 3px rgba(0,0,0,0.1)';}}
      onMouseLeave={e=>{e.currentTarget.style.transform='';e.currentTarget.style.boxShadow='0 4px 14px rgba(255,109,90,0.35), 0 1px 3px rgba(0,0,0,0.1)';}}>
        <svg width="22" height="22" viewBox="0 0 22 22" fill="none"><path d="M11 5v12M5 11h12" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"/></svg>
      </button>
    </div>
  );
}

// ─── Swim lane backgrounds ────────────────────────────────────────────────────
function SwimLanes({ categories, laneH=180 }) {
  return (
    <>
      {categories.map((cat, i) => (
        <div key={cat} style={{
          position:'absolute', left:0, right:0, top:i*laneH, height:laneH,
          background: i%2 ? 'transparent' : 'rgba(0,0,0,0.012)',
          borderBottom:'1px dashed #e4e4e7', pointerEvents:'none',
        }}>
          <span style={{
            position:'absolute', left:14, top:10, fontSize:10, fontWeight:700,
            color: CAT_COLORS[cat] || '#909399',
            letterSpacing:'0.08em', textTransform:'uppercase', opacity:0.7,
          }}>{cat}</span>
        </div>
      ))}
    </>
  );
}

// ─── Main Canvas ──────────────────────────────────────────────────────────────
function FlowCanvas({ onNodeSelect, selectedNode, onOpenDetail, onOpenNodePicker, defaultViewMode }) {
  const [nodes] = React.useState(()=>{ window.__FLOW_NODES = INITIAL_NODES; return INITIAL_NODES; });
  const [zoom, setZoom] = React.useState(1);
  const [pan] = React.useState({ x:0, y:0 });
  const [filters, setFilters] = React.useState({ search:'', status:'', category:'', viewMode: defaultViewMode || 'standard' });
  const canvasRef = React.useRef();
  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

  const setFilter = (k, v) => setFilters(p=>({...p, [k]: v}));
  const clearFilters = () => setFilters(p=>({...p, search:'', status:'', category:''}));
  const handleZoom = z => setZoom(clamp(parseFloat(z.toFixed(2)), 0.3, 2));

  const visible = nodes.filter(n => {
    if (filters.search && !n.label.toLowerCase().includes(filters.search.toLowerCase()) &&
        !n.tags.some(t=>t.toLowerCase().includes(filters.search.toLowerCase()))) return false;
    if (filters.status && n.status !== filters.status) return false;
    if (filters.category && n.category !== filters.category) return false;
    return true;
  });
  const hiddenIds = new Set(nodes.filter(n => !visible.includes(n)).map(n => n.id));

  return (
    <div ref={canvasRef}
      onClick={e=>{ if(e.target===canvasRef.current || e.target.dataset?.canvasBg) onNodeSelect(null); }}
      style={{
        flex:1, position:'relative', overflow:'hidden',
        background:'#f7f7f5',
        backgroundImage:'radial-gradient(circle, #c8c9cc 1px, transparent 1px)',
        backgroundSize:'18px 18px',
        backgroundPosition: `${pan.x}px ${pan.y}px`,
      }}>
      <div data-canvas-bg="1" style={{
        position:'absolute', inset:0,
        transform:`translate(${pan.x}px,${pan.y}px) scale(${zoom})`,
        transformOrigin:'0 0',
      }}>
        {filters.viewMode === 'swimlanes' && <SwimLanes categories={['UI','Logic','Infra','Data','Trigger']} />}
        {STICKIES.map(s => <StickyNote key={s.id} note={s} />)}
        <EdgeLayer nodes={nodes} edges={INITIAL_EDGES} selected={selectedNode} />
        {nodes.map(n => (
          <div key={n.id} style={{ opacity: hiddenIds.has(n.id) ? 0.18 : 1, transition:'opacity 0.2s' }}>
            <FlowNode node={n} selected={selectedNode===n.id} onSelect={onNodeSelect} onOpenDetail={onOpenDetail} />
          </div>
        ))}
      </div>

      <CanvasToolbar filters={filters} onFilter={setFilter} onClearFilters={clearFilters} />
      <CanvasFloatControls zoom={zoom} onZoom={handleZoom} onFit={()=>setZoom(1)} onLayout={()=>{}} />
      <AddNodeFab onClick={onOpenNodePicker} />
    </div>
  );
}

Object.assign(window, { FlowCanvas, CAT_COLORS, STATUS_META, NODE_ICONS, INITIAL_NODES });
