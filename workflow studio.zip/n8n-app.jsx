// n8n-style app shell — left rail, top bar, screen routing

const NAV_ITEMS = [
  { id:'home',  label:'Home',     icon:
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M3 10l7-7 7 7v7a1 1 0 01-1 1h-4v-5H8v5H4a1 1 0 01-1-1v-7z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/></svg>
  },
  { id:'flow',  label:'Workflows', icon:
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="4" cy="6" r="2" stroke="currentColor" strokeWidth="1.5"/><circle cx="16" cy="6" r="2" stroke="currentColor" strokeWidth="1.5"/><circle cx="10" cy="14" r="2" stroke="currentColor" strokeWidth="1.5"/><path d="M5.5 7L9 12.5M14.5 7L11 12.5" stroke="currentColor" strokeWidth="1.5"/></svg>
  },
  { id:'nodes', label:'Nodes',    icon:
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><polygon points="10,2 17,6 17,14 10,18 3,14 3,6" stroke="currentColor" strokeWidth="1.5" fill="none"/></svg>
  },
  { id:'queue', label:'Review queue', icon:
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" strokeWidth="1.5"/><path d="M10 6v4l3 2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>,
    badge:4 },
  { id:'admin', label:'Admin',    icon:
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="2.5" stroke="currentColor" strokeWidth="1.5"/><path d="M10 2v2M10 16v2M2 10h2M16 10h2M4.2 4.2l1.4 1.4M14.4 14.4l1.4 1.4M4.2 15.8l1.4-1.4M14.4 5.6l1.4-1.4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
  },
];

// ─── Left rail ────────────────────────────────────────────────────────────────
function LeftRail({ screen, onScreen }) {
  return (
    <div style={{
      width:60, background:'#1f1f1f', display:'flex', flexDirection:'column',
      alignItems:'center', padding:'12px 0', flexShrink:0,
    }}>
      {/* Logo */}
      <div style={{ marginBottom:18 }}>
        <div style={{
          width:34, height:34, borderRadius:7,
          background:'#ff6d5a',
          display:'flex', alignItems:'center', justifyContent:'center',
          color:'#fff', fontSize:15, fontWeight:800, fontFamily:'ui-monospace,monospace',
        }}>W</div>
      </div>
      {/* Nav items */}
      <div style={{ display:'flex', flexDirection:'column', gap:4, flex:1, width:'100%', alignItems:'center' }}>
        {NAV_ITEMS.map(item => {
          const active = screen === item.id;
          return (
            <Tooltip key={item.id} content={item.label} placement="right">
              <button onClick={()=>onScreen(item.id)} aria-label={item.label} style={{
                width:42, height:42, borderRadius:7,
                background: active ? '#ff6d5a' : 'transparent',
                color: active ? '#fff' : '#909399',
                border:'none', cursor:'pointer', position:'relative',
                display:'flex', alignItems:'center', justifyContent:'center',
                transition:'all 0.12s',
              }}
              onMouseEnter={e=>{ if(!active){e.currentTarget.style.background='#2a2a2a';e.currentTarget.style.color='#fff';}}}
              onMouseLeave={e=>{ if(!active){e.currentTarget.style.background='transparent';e.currentTarget.style.color='#909399';}}}>
                {item.icon}
                {item.badge && (
                  <span style={{
                    position:'absolute', top:4, right:4, width:8, height:8,
                    background:'#ff6d5a', borderRadius:'50%', border:'2px solid #1f1f1f',
                  }} />
                )}
              </button>
            </Tooltip>
          );
        })}
      </div>
      {/* Bottom — user + help */}
      <div style={{ display:'flex', flexDirection:'column', gap:6, alignItems:'center', paddingTop:8, borderTop:'1px solid #2a2a2a', width:36 }}>
        <Tooltip content="Help & feedback" placement="right">
          <button aria-label="Help" style={{ width:34, height:34, borderRadius:7, background:'transparent', color:'#909399', border:'none', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="7" stroke="currentColor" strokeWidth="1.5"/><path d="M7 7a2 2 0 014 0c0 1-2 1.5-2 3M9 12.5h.01" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
          </button>
        </Tooltip>
        <Tooltip content="Alice · maker" placement="right">
          <button aria-label="User" style={{ width:34, height:34, borderRadius:'50%', background:'#ff6d5a', color:'#fff', border:'none', cursor:'pointer', fontSize:13, fontWeight:700 }}>A</button>
        </Tooltip>
      </div>
    </div>
  );
}

// ─── Workflow Top Bar (only on flow screen) ───────────────────────────────────
function WorkflowTopBar({ onBell, unread, onExport, onSubmit }) {
  const [tab, setTab] = React.useState('editor');
  const [active, setActive] = React.useState(true);
  const [name] = React.useState('submit-order');
  return (
    <div style={{
      height:56, background:'#fff', borderBottom:'1px solid #e4e4e7',
      display:'flex', alignItems:'center', padding:'0 18px', flexShrink:0, gap:14, zIndex:50,
    }}>
      {/* Left: breadcrumb + name */}
      <div style={{ display:'flex', alignItems:'center', gap:10, minWidth:0 }}>
        <span style={{ fontSize:12, color:'#909399' }}>Workflows /</span>
        <h2 style={{ fontSize:15, fontWeight:600, color:'#1f1f1f' }}>{name}</h2>
        <Tag color={STATUS_META.APPROVED.color} size="sm"><Dot color={STATUS_META.APPROVED.dot} size={6}/> APPROVED</Tag>
        <span style={{ fontSize:11, color:'#909399', fontFamily:'ui-monospace,monospace' }}>v3.0.0</span>
        <Tooltip content="Edit workflow details">
          <IconButton size={26} aria-label="Edit">
            <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><path d="M2 12l1-3 7-7 2 2-7 7-3 1z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/></svg>
          </IconButton>
        </Tooltip>
      </div>

      {/* Center: tabs */}
      <div style={{ flex:1, display:'flex', justifyContent:'center' }}>
        <div style={{ display:'inline-flex', background:'#f4f4f5', borderRadius:6, padding:3, gap:1 }}>
          {[
            {id:'editor', label:'Editor'},
            {id:'executions', label:'Executions', badge:'12'},
            {id:'evaluation', label:'Evaluation'},
          ].map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{
              padding:'5px 14px', background: tab===t.id?'#fff':'transparent',
              color: tab===t.id?'#1f1f1f':'#525457',
              border:'none', borderRadius:4, cursor:'pointer',
              fontSize:12.5, fontWeight: tab===t.id?600:500, fontFamily:'inherit',
              boxShadow: tab===t.id?'0 1px 2px rgba(0,0,0,0.08)':'none',
              display:'inline-flex', alignItems:'center', gap:6, transition:'all 0.12s',
            }}>
              {t.label}
              {t.badge && <span style={{ fontSize:10, color:'#909399', padding:'0 5px', background: tab===t.id?'#f4f4f5':'transparent', borderRadius:7 }}>{t.badge}</span>}
            </button>
          ))}
        </div>
      </div>

      {/* Right: status toggle, bell, share, save, more */}
      <div style={{ display:'flex', alignItems:'center', gap:6 }}>
        <div style={{ display:'inline-flex', alignItems:'center', gap:8, padding:'5px 10px', background:'#f4f4f5', borderRadius:5 }}>
          <span style={{ fontSize:11.5, color:'#525457', fontWeight:500 }}>{active ? 'Active' : 'Inactive'}</span>
          <button onClick={()=>setActive(p=>!p)} aria-label="Toggle workflow active" style={{
            width:30, height:18, borderRadius:9, background: active?'#10b981':'#c8c9cc',
            border:'none', cursor:'pointer', position:'relative', transition:'background 0.15s',
            padding:0,
          }}>
            <span style={{
              position:'absolute', top:2, left: active?14:2, width:14, height:14, borderRadius:'50%',
              background:'#fff', boxShadow:'0 1px 2px rgba(0,0,0,0.2)', transition:'left 0.15s',
            }} />
          </button>
        </div>
        <span style={{ width:1, height:24, background:'#e4e4e7', margin:'0 4px' }} />
        <Tooltip content="Notifications">
          <span style={{ position:'relative' }}>
            <IconButton onClick={onBell} aria-label="Notifications">
              <svg width="17" height="17" viewBox="0 0 17 17" fill="none"><path d="M4 7a4.5 4.5 0 019 0v3.5l1.5 2H2.5L4 10.5V7z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/><path d="M6.5 13a2 2 0 004 0" stroke="currentColor" strokeWidth="1.5"/></svg>
            </IconButton>
            {unread > 0 && <Badge>{unread}</Badge>}
          </span>
        </Tooltip>
        <Tooltip content="Share workflow">
          <IconButton aria-label="Share">
            <svg width="17" height="17" viewBox="0 0 17 17" fill="none"><circle cx="4" cy="9" r="2" stroke="currentColor" strokeWidth="1.5"/><circle cx="13" cy="4" r="2" stroke="currentColor" strokeWidth="1.5"/><circle cx="13" cy="14" r="2" stroke="currentColor" strokeWidth="1.5"/><path d="M5.7 8L11.3 5M5.7 10L11.3 13" stroke="currentColor" strokeWidth="1.4"/></svg>
          </IconButton>
        </Tooltip>
        <Button variant="secondary" onClick={onExport}>
          <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><path d="M7 2v7M4 6l3 3 3-3M2 12h10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
          Export
        </Button>
        <Button variant="primary" onClick={onSubmit}>
          <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><path d="M3 7l3 3 5-6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
          Save
        </Button>
        <Menu items={[
          { label:'Test workflow',     icon:'▶' },
          { label:'Duplicate',         icon:'⎘' },
          { label:'Download as JSON',  icon:'↓' },
          { divider:true },
          { label:'Settings',          icon:'⚙' },
          { divider:true },
          { label:'Delete workflow',   icon:'🗑', danger:true },
        ]} trigger={<IconButton aria-label="More actions"><span>⋯</span></IconButton>}/>
      </div>
    </div>
  );
}

// ─── Generic top bar (non-flow screens) ───────────────────────────────────────
function GenericTopBar({ title, onBell, unread }) {
  return (
    <div style={{
      height:56, background:'#fff', borderBottom:'1px solid #e4e4e7',
      display:'flex', alignItems:'center', padding:'0 24px', flexShrink:0,
      justifyContent:'space-between',
    }}>
      <h2 style={{ fontSize:14, fontWeight:600, color:'#525457' }}>{title}</h2>
      <div style={{ display:'flex', alignItems:'center', gap:6 }}>
        <Input size="sm" placeholder="Search anything…" aria-label="Global search"
          startIcon={<svg width="13" height="13" viewBox="0 0 14 14" fill="none"><circle cx="6" cy="6" r="4.5" stroke="currentColor" strokeWidth="1.5"/><path d="M10 10l3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>}
          style={{ width:260, marginRight:6 }} />
        <Tooltip content="Notifications">
          <span style={{position:'relative'}}>
            <IconButton onClick={onBell} aria-label="Notifications">
              <svg width="17" height="17" viewBox="0 0 17 17" fill="none"><path d="M4 7a4.5 4.5 0 019 0v3.5l1.5 2H2.5L4 10.5V7z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/><path d="M6.5 13a2 2 0 004 0" stroke="currentColor" strokeWidth="1.5"/></svg>
            </IconButton>
            {unread > 0 && <Badge>{unread}</Badge>}
          </span>
        </Tooltip>
      </div>
    </div>
  );
}

// ─── App Shell ────────────────────────────────────────────────────────────────
function AppShell() {
  const [screen, setScreen] = React.useState('flow');
  const [notifOpen, setNotifOpen] = React.useState(false);
  const [selectedNode, setSelectedNode] = React.useState(null);
  const [detailNode, setDetailNode] = React.useState(null);
  const [detailTab, setDetailTab] = React.useState('parameters');
  const [reviewItem, setReviewItem] = React.useState(null);
  const [pickerOpen, setPickerOpen] = React.useState(false);
  const [exportOpen, setExportOpen] = React.useState(false);
  const [canvasView, setCanvasView] = React.useState('standard');
  const unread = 3;

  // Tweak event listener
  React.useEffect(() => {
    const handler = e => {
      const { key, value } = e.detail || {};
      if (key === 'screen')    setScreen(value);
      if (key === 'viewMode')  setCanvasView(value);
      if (key === 'overlay') {
        setNotifOpen(false); setExportOpen(false); setReviewItem(null); setPickerOpen(false);
        if (value === 'notifs')   setNotifOpen(true);
        if (value === 'export')   setExportOpen(true);
        if (value === 'picker')   setPickerOpen(true);
        if (value === 'review')   setReviewItem(QUEUE_DATA[0]);
      }
      if (key === 'drawer') {
        if (value === 'closed') setDetailNode(null);
        else if (value === 'params')   { setDetailNode(window.__FLOW_NODES?.[2]); setDetailTab('parameters'); }
        else if (value === 'versions') { setDetailNode(window.__FLOW_NODES?.[2]); setDetailTab('versions'); }
        else if (value === 'comments') { setDetailNode(window.__FLOW_NODES?.[2]); setDetailTab('comments'); }
      }
    };
    window.addEventListener('studio-tweak', handler);
    return () => window.removeEventListener('studio-tweak', handler);
  }, []);

  const handleSelect = id => {
    setSelectedNode(id);
    if (id) {
      const n = window.__FLOW_NODES?.find(x=>x.id===id);
      if (n) { setDetailNode(n); setDetailTab('parameters'); }
    }
  };
  const handleOpenDetail = node => { setDetailNode(node); setDetailTab('parameters'); };

  return (
    <div style={{ display:'flex', height:'100vh', overflow:'hidden', background:'#f7f7f5' }}>
      <LeftRail screen={screen} onScreen={setScreen} />

      <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden' }}>
        {screen === 'flow'
          ? <WorkflowTopBar onBell={()=>setNotifOpen(true)} unread={unread} onExport={()=>setExportOpen(true)} onSubmit={()=>{}} />
          : screen !== 'home' && <GenericTopBar title={NAV_ITEMS.find(n=>n.id===screen)?.label || ''} onBell={()=>setNotifOpen(true)} unread={unread} />}

        <div style={{ flex:1, display:'flex', overflow:'hidden' }}>
          {screen === 'home'  && <HomeScreen onNavigate={setScreen} />}
          {screen === 'flow'  && <FlowCanvas selectedNode={selectedNode} onNodeSelect={handleSelect} onOpenDetail={handleOpenDetail} onOpenNodePicker={()=>setPickerOpen(true)} defaultViewMode={canvasView} />}
          {screen === 'nodes' && <NodesScreen onOpenDetail={handleOpenDetail} />}
          {screen === 'queue' && <ReviewQueue onOpenReview={setReviewItem} />}
          {screen === 'admin' && <AdminScreen />}
        </div>
      </div>

      {/* Overlays */}
      {notifOpen   && <NotificationCenter onClose={()=>setNotifOpen(false)} />}
      {reviewItem  && <ReviewPanel item={reviewItem} onClose={()=>setReviewItem(null)} />}
      {detailNode  && <NodeDetailDrawer node={detailNode} initialTab={detailTab} onClose={()=>setDetailNode(null)} />}
      <NodePicker open={pickerOpen} onClose={()=>setPickerOpen(false)} />
      <ExportModal open={exportOpen} onClose={()=>setExportOpen(false)} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<AppShell />);
