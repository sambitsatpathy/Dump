// n8n-style drawers and overlays

// ─── Node Picker (slides in from right, n8n-style) ────────────────────────────
const PICKER_NODES = {
  'Trigger':  [
    { id:'webhook',   name:'Webhook',         desc:'Wait for HTTP requests' },
    { id:'schedule',  name:'Schedule',        desc:'Run on cron/interval' },
    { id:'manual',    name:'Manual',          desc:'Run manually' },
  ],
  'UI':       [
    { id:'order-form',     name:'order-form',     desc:'Checkout form component' },
    { id:'header-nav',     name:'header-nav',     desc:'Top navigation bar' },
    { id:'modal-dialog',   name:'modal-dialog',   desc:'Modal/dialog component' },
    { id:'data-table',     name:'data-table',     desc:'Sortable data grid' },
  ],
  'Logic':    [
    { id:'validate-order', name:'validate-order', desc:'Order validation rules' },
    { id:'route-request',  name:'route-request',  desc:'Request routing' },
    { id:'transform-data', name:'transform-data', desc:'Data transformation' },
    { id:'rate-limiter',   name:'rate-limiter',   desc:'Rate limit by key' },
  ],
  'Infra':    [
    { id:'payment-gateway', name:'payment-gateway', desc:'Payment processing' },
    { id:'message-queue',   name:'message-queue',   desc:'Pub/sub messaging' },
    { id:'cache-layer',     name:'cache-layer',     desc:'In-memory cache' },
  ],
  'Data':     [
    { id:'audit-log',        name:'audit-log',        desc:'Compliance logging' },
    { id:'event-store',      name:'event-store',      desc:'Event sourcing' },
    { id:'send-confirmation',name:'send-confirmation',desc:'Email notifications' },
  ],
  'External': [
    { id:'stripe-api', name:'Stripe',   desc:'Payments API integration' },
    { id:'sendgrid',   name:'SendGrid', desc:'Transactional email' },
    { id:'auth0',      name:'Auth0',    desc:'Identity provider' },
  ],
};

function NodePicker({ open, onClose }) {
  const [search, setSearch] = React.useState('');
  const [selectedCat, setSelectedCat] = React.useState(null);
  if (!open) return null;
  const filterFn = items => items.filter(n => !search || n.name.toLowerCase().includes(search.toLowerCase()) || n.desc.toLowerCase().includes(search.toLowerCase()));
  return (
    <>
      <div style={{ position:'fixed', inset:0, background:'rgba(15,15,15,0.2)', zIndex:200 }} onClick={onClose}/>
      <div style={{
        position:'fixed', top:0, right:0, bottom:0, width:380, zIndex:201,
        background:'#fff', borderLeft:'1px solid #e4e4e7',
        display:'flex', flexDirection:'column', boxShadow:'-8px 0 32px rgba(0,0,0,0.08)',
      }}>
        <div style={{ padding:'14px 16px', borderBottom:'1px solid #e4e4e7', flexShrink:0 }}>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:10 }}>
            <h3 style={{ fontSize:14, fontWeight:600 }}>Add a node</h3>
            <IconButton onClick={onClose} size={26} aria-label="Close">
              <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
            </IconButton>
          </div>
          <Input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search nodes…" aria-label="Search nodes"
            startIcon={<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="6" cy="6" r="4.5" stroke="currentColor" strokeWidth="1.5"/><path d="M10 10l3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>}
            style={{ width:'100%' }} />
        </div>
        <div style={{ flex:1, overflow:'auto', padding:'8px 0' }}>
          {Object.entries(PICKER_NODES).map(([cat, items]) => {
            const visible = filterFn(items);
            if (!visible.length) return null;
            const expanded = !selectedCat || selectedCat === cat;
            return (
              <div key={cat}>
                <div onClick={()=>setSelectedCat(selectedCat===cat?null:cat)} style={{
                  padding:'8px 16px', display:'flex', alignItems:'center', gap:8,
                  background:'#fafafa', cursor:'pointer',
                  borderBottom: expanded?'1px solid #f0f0f2':'none',
                  borderTop:'1px solid #f0f0f2',
                  userSelect:'none',
                }}>
                  <span style={{ width:6, height:6, borderRadius:'50%', background: CAT_COLORS[cat] || '#909399' }} />
                  <span style={{ fontSize:11, fontWeight:700, color:'#525457', letterSpacing:'0.04em', textTransform:'uppercase', flex:1 }}>{cat}</span>
                  <span style={{ fontSize:11, color:'#909399' }}>{visible.length}</span>
                </div>
                {expanded && visible.map(n => (
                  <div key={n.id} style={{
                    padding:'10px 16px', display:'flex', alignItems:'center', gap:11,
                    cursor:'grab', borderBottom:'1px solid #f5f5f7',
                    transition:'background 0.1s',
                  }}
                  onMouseEnter={e=>e.currentTarget.style.background='#fafafa'}
                  onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                    <div style={{
                      width:32, height:32, borderRadius:5, flexShrink:0,
                      background: CAT_COLORS[cat], color:'#fff',
                      display:'flex',alignItems:'center',justifyContent:'center',
                    }}>
                      <svg width="18" height="18" viewBox="0 0 32 32">{NODE_ICONS[n.id] || NODE_ICONS.default}</svg>
                    </div>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ fontSize:13, fontWeight:600, color:'#1f1f1f' }}>{n.name}</div>
                      <div style={{ fontSize:11.5, color:'#909399', marginTop:1 }}>{n.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}

// ─── Node Detail Drawer (n8n-style parameters panel, right slide-in) ─────────
function NodeDetailDrawer({ node, onClose, initialTab='parameters' }) {
  const [tab, setTab] = React.useState(initialTab);
  const [comment, setComment] = React.useState('');
  React.useEffect(()=>{ setTab(initialTab); }, [initialTab, node?.id]);
  if (!node) return null;
  const catColor = CAT_COLORS[node.category] || '#909399';
  const status = STATUS_META[node.status] || STATUS_META.DRAFT;
  const tabs = [
    { id:'parameters', label:'Parameters', warn: node.status==='CHANGES_REQUESTED' },
    { id:'details',    label:'Details' },
    { id:'lifecycle',  label:'Lifecycle' },
    { id:'comments',   label:'Comments', badge: node.comments },
    { id:'versions',   label:'Versions' },
  ];
  const versionHistory = [
    { ver:'v1.1.0', status:'APPROVED', author:'alice',       date:'Apr 12', msg:'Initial approval' },
    { ver:'v1.0.1', status:'APPROVED', author:'bob',         date:'Mar 28', msg:'Fix null-guard on order_id' },
    { ver:'v1.0.0', status:'REJECTED', author:'alice',       date:'Mar 20', msg:'Missing validation logic' },
  ];

  return (
    <>
      <div style={{ position:'fixed', inset:0, background:'rgba(15,15,15,0.15)', zIndex:200 }} onClick={onClose}/>
      <div style={{
        position:'fixed', top:0, right:0, bottom:0, width:520, zIndex:201,
        background:'#fff', borderLeft:'1px solid #e4e4e7',
        display:'flex', flexDirection:'column', boxShadow:'-12px 0 36px rgba(0,0,0,0.08)',
      }}>
        {/* Drawer header */}
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'14px 18px', borderBottom:'1px solid #e4e4e7', flexShrink:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:12 }}>
            <div style={{
              width:34, height:34, borderRadius:5,
              background: catColor, color:'#fff',
              display:'flex',alignItems:'center',justifyContent:'center',
            }}>
              <svg width="20" height="20" viewBox="0 0 32 32">{NODE_ICONS[node.type] || NODE_ICONS.default}</svg>
            </div>
            <div>
              <h3 style={{ fontSize:14.5, fontWeight:600 }}>{node.label}</h3>
              <div style={{ display:'flex', alignItems:'center', gap:6, marginTop:2 }}>
                <Tag color={status.color} size="sm"><Dot color={status.dot} size={5}/> {status.label}</Tag>
                <span style={{ fontSize:11, color:'#909399', fontFamily:'ui-monospace,monospace' }}>{node.version}</span>
              </div>
            </div>
          </div>
          <div style={{ display:'flex', gap:4 }}>
            <Menu items={[
              { label:'Execute node',         icon:'▶' },
              { label:'Pin data',             icon:'📌' },
              { divider:true },
              { label:'Duplicate as DRAFT',   icon:'⎘' },
              { label:'Submit for review',    icon:'↑' },
              { divider:true },
              { label:'Delete',               icon:'🗑', danger:true },
            ]} trigger={<IconButton size={28} aria-label="More"><span>⋯</span></IconButton>} />
            <IconButton onClick={onClose} size={28} aria-label="Close">
              <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
            </IconButton>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display:'flex', borderBottom:'1px solid #e4e4e7', padding:'0 14px', flexShrink:0, background:'#fafafa' }}>
          {tabs.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{
              padding:'10px 14px', background:'none', border:'none',
              borderBottom: tab===t.id?'2px solid #ff6d5a':'2px solid transparent',
              color: tab===t.id?'#1f1f1f':'#525457', fontWeight: tab===t.id?600:500,
              fontSize:12.5, cursor:'pointer', marginBottom:-1,
              display:'inline-flex', alignItems:'center', gap:6, fontFamily:'inherit',
            }}>
              {t.label}
              {t.warn && <Dot color="#dc3545" size={6} />}
              {t.badge > 0 && <span style={{ fontSize:10, padding:'1px 5px', background:'#e4e4e7', color:'#525457', borderRadius:8, fontWeight:600 }}>{t.badge}</span>}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div style={{ flex:1, overflow:'auto', padding:'16px 18px' }}>
          {tab === 'parameters' && (
            <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
              {node.status === 'CHANGES_REQUESTED' && (
                <Banner tone="warning">Schema validation errors found. Fix highlighted fields before saving.</Banner>
              )}
              <FormField label="Strict mode" helper="Reject any input that doesn't match schema exactly">
                <Select value="true" options={[{value:'true',label:'On'},{value:'false',label:'Off'}]} aria-label="Strict mode" style={{width:'100%'}}/>
              </FormField>
              <FormField label="Max retries" helper="0–10 retries on transient errors">
                <Input value="3" aria-label="Max retries" />
              </FormField>
              <FormField label="Timeout (ms)" error="Must be a positive integer">
                <Input value="-1" aria-label="Timeout" style={{ borderColor:'#dc3545' }}/>
              </FormField>
              <FormField label="Schema reference">
                <span style={{ display:'inline-flex', alignItems:'center', gap:6, padding:'7px 10px', background:'#fafafa', border:'1px solid #e4e4e7', borderRadius:4, fontSize:12 }}>
                  <span style={{fontFamily:'ui-monospace,monospace'}}>/specs/schemas/logic.schema.json</span>
                  <Button variant="tertiary" size="sm" style={{padding:'2px 6px', height:'auto'}}>Open ↗</Button>
                </span>
              </FormField>
              <FormField label="Description">
                <Textarea value="Handles order validation including null-guard on order_id and field-level checks." rows={3} aria-label="Description" />
              </FormField>
            </div>
          )}

          {tab === 'details' && (
            <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
              <FormField label="Node ID">
                <Input value={node.id} readOnly aria-label="Node ID" style={{fontFamily:'ui-monospace,monospace'}}/>
              </FormField>
              <FormField label="Label"><Input value={node.label} aria-label="Label"/></FormField>
              <FormField label="Category"><Input value={node.category} readOnly aria-label="Category"/></FormField>
              <FormField label="Tags">
                <div style={{display:'flex',gap:5,flexWrap:'wrap'}}>
                  {node.tags.map(t=><Tag key={t} color="neutral">{t}</Tag>)}
                  <Button variant="tertiary" size="sm" style={{padding:'2px 8px',height:'auto',fontSize:11}}>+ Add tag</Button>
                </div>
              </FormField>
            </div>
          )}

          {tab === 'lifecycle' && (
            <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
              {[
                {l:'Status', v:status.label},
                {l:'Submitted by', v:'alice'},
                {l:'Submitted at', v:'May 18, 2026 09:14'},
                {l:'Reviewed by', v:'checker-dan'},
                {l:'Reviewed at', v:'May 18, 2026 15:30'},
              ].map(f=>(
                <FormField key={f.l} label={f.l}><Input value={f.v} readOnly aria-label={f.l}/></FormField>
              ))}
              <div style={{ display:'flex', gap:8, marginTop:6, paddingTop:14, borderTop:'1px solid #e4e4e7' }}>
                <Button variant="primary" size="sm">Submit for review</Button>
                <Button variant="secondary" size="sm">Withdraw submission</Button>
              </div>
            </div>
          )}

          {tab === 'comments' && (
            <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
              <div style={{ display:'flex', justifyContent:'flex-end' }}>
                <Select value="unresolved" options={['unresolved','all','orphaned']} aria-label="Comment filter" style={{width:140}}/>
              </div>
              {[
                { author:'checker-dan', time:'May 18', body:'Logic does not handle null order_id. Please add validation guard before processing.', fromPrev:true },
                { author:'alice',       time:'May 18', body:'Acknowledged. Will fix in v2.1.0 with explicit null-guard.', fromPrev:false },
              ].map((c,i)=>(
                <div key={i} style={{
                  padding:'12px 14px', background:c.fromPrev?'#fffbf2':'#fafafa',
                  border:`1px solid ${c.fromPrev?'#fae0a0':'#e4e4e7'}`,
                  borderRadius:6,
                }}>
                  <div style={{ display:'flex', alignItems:'center', gap:7, marginBottom:6 }}>
                    <span style={{ width:22, height:22, borderRadius:'50%', background:'#ff6d5a', color:'#fff', fontSize:10, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center' }}>{c.author[0].toUpperCase()}</span>
                    <span style={{ fontSize:12, fontWeight:600 }}>{c.author}</span>
                    <span style={{ fontSize:10.5, color:'#909399' }}>· {c.time}</span>
                    {c.fromPrev && <Tag color="warning" size="sm">from previous review</Tag>}
                    <span style={{ flex:1 }} />
                    <Button variant="tertiary" size="sm" style={{padding:'2px 6px',height:'auto'}}>Resolve</Button>
                  </div>
                  <p style={{ fontSize:12.5, lineHeight:1.5, color:'#1f1f1f' }}>{c.body}</p>
                </div>
              ))}
              <div style={{ marginTop:4, paddingTop:14, borderTop:'1px solid #e4e4e7', display:'flex', flexDirection:'column', gap:8 }}>
                <Textarea value={comment} onChange={e=>setComment(e.target.value)} placeholder="Add a comment…" rows={2} aria-label="Add comment"/>
                <div style={{ display:'flex', justifyContent:'flex-end' }}>
                  <Button variant="primary" size="sm" disabled={!comment.trim()}>Comment</Button>
                </div>
              </div>
            </div>
          )}

          {tab === 'versions' && (
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <span style={{ fontSize:11, color:'#909399' }}>{versionHistory.length} versions</span>
                <Button variant="secondary" size="sm">Compare versions</Button>
              </div>
              {versionHistory.map((v,i)=>(
                <Card key={i} accent={v.status==='APPROVED'?'#10b981':'#dc3545'} style={{padding:'10px 14px'}}>
                  <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                      <span style={{ fontFamily:'ui-monospace,monospace', fontSize:12.5, fontWeight:700, color:'#1f1f1f' }}>{v.ver}</span>
                      <Tag color={v.status==='APPROVED'?'success':'danger'} size="sm">
                        <Dot color={v.status==='APPROVED'?'#10b981':'#dc3545'} size={5}/> {v.status}
                      </Tag>
                    </div>
                    <Menu items={[
                      {label:'View at this version', icon:'⊙'},
                      {label:'Compare to current', icon:'⇄'},
                      {label:'Duplicate as DRAFT', icon:'⎘'},
                    ]} trigger={<IconButton size={24} aria-label="Version actions"><span>⋯</span></IconButton>}/>
                  </div>
                  <div style={{ fontSize:11.5, color:'#909399', marginTop:6 }}>
                    <strong style={{color:'#525457'}}>{v.author}</strong> · {v.date}
                  </div>
                  <div style={{ fontSize:12, marginTop:4 }}>{v.msg}</div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}

// ─── Review Panel (large drawer with diff + comments) ─────────────────────────
const DIFF_LINES = [
  { t:'unchanged', text:'id: validate-order' },
  { t:'unchanged', text:'category: Logic' },
  { t:'removed',   text:'version: 2.0.1' },
  { t:'added',     text:'version: 2.1.0' },
  { t:'unchanged', text:'label: Validate Order' },
  { t:'removed',   text:'description: Basic validation' },
  { t:'added',     text:'description: Full validation with null-guard on order_id' },
  { t:'unchanged', text:'tags:' },
  { t:'unchanged', text:'  - validation' },
  { t:'added',     text:'properties:' },
  { t:'added',     text:'  strictMode: true' },
  { t:'added',     text:'  maxRetries: 3' },
];

function ReviewPanel({ item, onClose }) {
  const [comment, setComment] = React.useState('');
  const [dialog, setDialog] = React.useState(null);
  const [reason, setReason] = React.useState('');
  if (!item) return null;
  const isWorkflow = item.type === 'Workflow';
  const comments = [
    { author:'alice',       time:'May 18 09:14', body:'Added null-guard for order_id as requested. Also bumped strictMode to true.', fromPrev:false, status:'open' },
    { author:'checker-dan', time:'May 17 16:30', body:'Please add null-guard on order_id before processing. This caused a prod issue last sprint.', fromPrev:true, status:'open' },
  ];
  const lineColor = t => t==='added' ? '#10b981' : t==='removed' ? '#dc3545' : '#525457';
  const lineBg    = (t, side) => t==='unchanged' ? 'transparent' : (side==='left' ? (t==='removed'?'#fdebec':'transparent') : (t==='added'?'#e8f5ed':'transparent'));

  return (
    <>
      <div style={{ position:'fixed', inset:0, background:'rgba(15,15,15,0.35)', zIndex:200 }} onClick={onClose}/>
      <div style={{
        position:'fixed', top:0, right:0, bottom:0, width:'68%', minWidth:780, zIndex:201,
        background:'#f7f7f5', borderLeft:'1px solid #e4e4e7',
        display:'flex', flexDirection:'column', boxShadow:'-12px 0 36px rgba(0,0,0,0.12)',
      }}>
        {/* Header */}
        <div style={{ background:'#fff', borderBottom:'1px solid #e4e4e7', padding:'14px 22px', display:'flex', alignItems:'center', justifyContent:'space-between', flexShrink:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:14 }}>
            <IconButton onClick={onClose} aria-label="Close" size={32}>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M10 4l-4 4 4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </IconButton>
            <div>
              <h2 style={{ fontSize:16, fontWeight:600, marginBottom:3 }}>{item.name}</h2>
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <Tag color={STATUS_META[item.status]?.color}>
                  <Dot color={STATUS_META[item.status]?.dot} size={6}/> {STATUS_META[item.status]?.label}
                </Tag>
                <span style={{ fontSize:11.5, color:'#909399', fontFamily:'ui-monospace,monospace' }}>{item.version}</span>
                <span style={{ fontSize:11.5, color:'#909399' }}>· {item.type} · submitted by <strong style={{color:'#525457'}}>{item.submittedBy}</strong></span>
              </div>
            </div>
          </div>
          <div style={{ display:'flex', gap:8 }}>
            <Button variant="secondary" onClick={()=>setDialog('changes')}>Request changes</Button>
            <Button variant="danger" onClick={()=>setDialog('reject')}>Reject</Button>
            <Button variant="primary" onClick={()=>setDialog('approve')}>
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M3 7l3 3 5-6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
              Approve
            </Button>
          </div>
        </div>

        <div style={{ flex:1, overflow:'auto', padding:'18px 22px', display:'flex', flexDirection:'column', gap:16 }}>
          {isWorkflow && (
            <Banner tone="warning">
              This workflow contains node refs with non-APPROVED status. Approval is blocked until all dependencies are APPROVED.
              <Button variant="tertiary" size="sm" style={{marginLeft:8,padding:'0 6px',height:'auto',fontSize:11.5,color:'#a86a00',textDecoration:'underline'}}>View blocking deps →</Button>
            </Banner>
          )}

          {/* Diff view */}
          <Card style={{ overflow:'hidden', padding:0 }}>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr' }}>
              {[
                { label:'v1.1.0 · current APPROVED', side:'left' },
                { label:'v1.2.0 · incoming', side:'right' },
              ].map((col,ci)=>(
                <div key={ci} style={{ borderRight: ci===0?'1px solid #e4e4e7':'none' }}>
                  <div style={{ padding:'9px 14px', background:'#fafafa', borderBottom:'1px solid #e4e4e7', fontSize:11.5, color:'#525457', fontWeight:600, display:'flex',alignItems:'center',gap:6 }}>
                    <Dot color={ci===0?'#10b981':'#f5a623'} size={6}/>
                    {col.label}
                  </div>
                  <div style={{ padding:'10px 0', fontFamily:'ui-monospace,"SF Mono",monospace', fontSize:11.5, lineHeight:'19px' }}>
                    {DIFF_LINES.map((line,i)=>{
                      const show = ci===0 ? line.t!=='added' : line.t!=='removed';
                      return show ? (
                        <div key={i} style={{
                          color:lineColor(line.t),
                          background:lineBg(line.t, col.side),
                          padding:'0 14px',
                          display:'flex', gap:8,
                        }}>
                          <span style={{ width:14, color:'#c8c9cc', userSelect:'none', fontSize:10 }}>{i+1}</span>
                          <span style={{ width:10, color:'#909399', userSelect:'none' }}>{line.t==='added'?'+':line.t==='removed'?'-':' '}</span>
                          <span>{line.text}</span>
                        </div>
                      ) : <div key={i} style={{ height:19 }}>&nbsp;</div>;
                    })}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Comments thread */}
          <div>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:10 }}>
              <h4 style={{ fontSize:13, fontWeight:600, color:'#525457', textTransform:'uppercase', letterSpacing:'0.04em' }}>Conversation ({comments.length})</h4>
              <Select value="open" options={['open','all','resolved']} aria-label="Comment filter" style={{width:130, fontSize:11}}/>
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              {comments.map((c,i)=>(
                <Card key={i} style={{ padding:'12px 14px' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
                    <span style={{ width:24, height:24, borderRadius:'50%', background:'#ff6d5a', color:'#fff', fontSize:10, fontWeight:700, display:'flex', alignItems:'center', justifyContent:'center' }}>{c.author[0].toUpperCase()}</span>
                    <span style={{ fontSize:12.5, fontWeight:600 }}>{c.author}</span>
                    <span style={{ fontSize:11, color:'#909399' }}>· {c.time}</span>
                    {c.fromPrev && <Tag color="warning" size="sm">from previous review</Tag>}
                    <span style={{ flex:1 }} />
                    <Button variant="tertiary" size="sm" style={{padding:'2px 8px',height:'auto'}}>Resolve</Button>
                    <IconButton size={22} aria-label="More"><span>⋯</span></IconButton>
                  </div>
                  <p style={{ fontSize:13, lineHeight:1.55, color:'#1f1f1f' }}>{c.body}</p>
                </Card>
              ))}
            </div>
            <div style={{ marginTop:14, display:'flex', flexDirection:'column', gap:8 }}>
              <Textarea value={comment} onChange={e=>setComment(e.target.value)} placeholder="Write a comment…" rows={2} aria-label="Add comment"/>
              <div style={{ display:'flex', justifyContent:'flex-end' }}>
                <Button variant="primary" size="sm" disabled={!comment.trim()}>Comment</Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Confirm dialogs */}
      <Dialog open={dialog==='approve'} title="Approve submission" onClose={()=>setDialog(null)}
        actions={[
          <Button key="c" variant="secondary" onClick={()=>setDialog(null)}>Cancel</Button>,
          <Button key="s" variant="primary">Confirm approval</Button>,
        ]}>
        <p style={{ fontSize:13.5, lineHeight:1.6 }}>Approve <strong>{item.name} {item.version}</strong>?</p>
        <p style={{ fontSize:12.5, color:'#525457', marginTop:8, lineHeight:1.5 }}>This will move the spec to APPROVED status and notify <strong>{item.submittedBy}</strong>. Any open comments will be carried forward to the next submission.</p>
      </Dialog>
      <Dialog open={dialog==='reject'} title="Reject submission" onClose={()=>setDialog(null)}
        actions={[
          <Button key="c" variant="secondary" onClick={()=>setDialog(null)}>Cancel</Button>,
          <Button key="s" variant="danger" disabled={!reason.trim()}>Confirm rejection</Button>,
        ]}>
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <p style={{ fontSize:13 }}>Rejecting <strong>{item.name} {item.version}</strong>. Please provide a reason for the maker:</p>
          <Textarea value={reason} onChange={e=>setReason(e.target.value)} placeholder="Reason for rejection…" rows={4} aria-label="Rejection reason"/>
        </div>
      </Dialog>
      <Dialog open={dialog==='changes'} title="Request changes" onClose={()=>setDialog(null)}
        actions={[
          <Button key="c" variant="secondary" onClick={()=>setDialog(null)}>Cancel</Button>,
          <Button key="s" variant="primary" disabled={!reason.trim()}>Send request</Button>,
        ]}>
        <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
          <p style={{ fontSize:13 }}>Specify what changes are needed for <strong>{item.name} {item.version}</strong>:</p>
          <Textarea value={reason} onChange={e=>setReason(e.target.value)} placeholder="Describe required changes…" rows={4} aria-label="Changes description"/>
        </div>
      </Dialog>
    </>
  );
}

// ─── Notification Center ──────────────────────────────────────────────────────
function NotificationCenter({ onClose }) {
  const [items, setItems] = React.useState(NOTIFICATIONS);
  const [filter, setFilter] = React.useState('all');
  const [typeF, setTypeF] = React.useState('');
  const unreadCount = items.filter(n=>n.unread).length;
  const markAll = () => setItems(ns=>ns.map(n=>({...n, unread:false})));
  const visible = items.filter(n => {
    if (filter==='unread' && !n.unread) return false;
    if (typeF && n.type !== typeF) return false;
    return true;
  });
  const toneIcon = {
    success: <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><circle cx="6" cy="6" r="5" fill="#10b981"/><path d="M3.5 6l2 2 3-4" stroke="#fff" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>,
    warning: <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><circle cx="6" cy="6" r="5" fill="#f5a623"/><path d="M6 3v3M6 8h.01" stroke="#fff" strokeWidth="1.4" strokeLinecap="round"/></svg>,
    danger:  <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><circle cx="6" cy="6" r="5" fill="#dc3545"/><path d="M4 4l4 4M8 4l-4 4" stroke="#fff" strokeWidth="1.4" strokeLinecap="round"/></svg>,
    info:    <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><circle cx="6" cy="6" r="5" fill="#3b82f6"/><path d="M6 5v3M6 4h.01" stroke="#fff" strokeWidth="1.4" strokeLinecap="round"/></svg>,
  };
  return (
    <>
      <div style={{ position:'fixed', inset:0, background:'rgba(15,15,15,0.15)', zIndex:200 }} onClick={onClose}/>
      <div style={{
        position:'fixed', top:0, right:0, bottom:0, width:420, zIndex:201,
        background:'#fff', borderLeft:'1px solid #e4e4e7',
        display:'flex', flexDirection:'column', boxShadow:'-8px 0 28px rgba(0,0,0,0.1)',
      }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'14px 18px', borderBottom:'1px solid #e4e4e7', flexShrink:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <h3 style={{ fontSize:14.5, fontWeight:600 }}>Notifications</h3>
            {unreadCount>0 && <Tag color="coral" size="sm">{unreadCount} new</Tag>}
          </div>
          <div style={{ display:'flex', gap:4 }}>
            <Button variant="tertiary" size="sm" onClick={markAll}>Mark all read</Button>
            <IconButton onClick={onClose} size={28} aria-label="Close">
              <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><path d="M3 3l8 8M11 3l-8 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
            </IconButton>
          </div>
        </div>
        <div style={{ padding:'10px 14px', display:'flex', gap:8, borderBottom:'1px solid #f0f0f2', flexShrink:0 }}>
          <ToggleGroup options={[{value:'all',label:'All'},{value:'unread',label:'Unread'},{value:'mentions',label:'Mentions'}]} value={filter} onChange={setFilter}/>
          <Select value={typeF} options={['Submission','Approval','Rejection','Comment','Upgrade']} placeholder="Event type" onChange={setTypeF} size="sm" aria-label="Event type filter" style={{flex:1}}/>
        </div>
        <div style={{ flex:1, overflow:'auto' }}>
          {visible.length === 0 ? (
            <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:'100%', gap:14, color:'#909399' }}>
              <svg width="42" height="42" viewBox="0 0 42 42" fill="none"><path d="M10 16a11 11 0 0122 0v8l3 4H7l3-4v-8z" stroke="#c8c9cc" strokeWidth="2" strokeLinejoin="round"/><path d="M17 32a4 4 0 008 0" stroke="#c8c9cc" strokeWidth="2"/></svg>
              <span style={{ fontSize:13 }}>You're all caught up.</span>
            </div>
          ) : visible.map(n => (
            <div key={n.id} onClick={()=>setItems(ns=>ns.map(x=>x.id===n.id?{...x,unread:false}:x))} style={{
              display:'flex', gap:10, padding:'12px 18px',
              borderBottom:'1px solid #f0f0f2',
              background: n.unread?'rgba(255,109,90,0.04)':'transparent',
              borderLeft: n.unread?'3px solid #ff6d5a':'3px solid transparent',
              cursor:'pointer', transition:'background 0.12s',
            }}
            onMouseEnter={e=>e.currentTarget.style.background='#fafafa'}
            onMouseLeave={e=>e.currentTarget.style.background=n.unread?'rgba(255,109,90,0.04)':'transparent'}>
              <span style={{ marginTop:3 }}>{toneIcon[n.tone]}</span>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:12, color:'#909399', textTransform:'uppercase', fontWeight:600, letterSpacing:'0.04em', marginBottom:3 }}>{n.type}</div>
                <div style={{ fontSize:12.5, lineHeight:1.45, color: n.unread?'#1f1f1f':'#525457' }}>{n.title}</div>
                <div style={{ fontSize:11, color:'#909399', marginTop:5 }}>{n.time}</div>
              </div>
              <Menu items={[{label:'Mark as read', icon:'✓'},{label:'Open spec', icon:'↗'},{label:'Mute this spec', icon:'🔕'}]}
                trigger={<IconButton size={24} aria-label="More"><span>⋯</span></IconButton>}/>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// ─── Export Modal ─────────────────────────────────────────────────────────────
function ExportModal({ open, onClose }) {
  const [tab, setTab] = React.useState('full');
  const [format, setFormat] = React.useState('json');
  const [scope, setScope] = React.useState('Entire app');
  const tabs = [
    { id:'full',     label:'Full' },
    { id:'approved', label:'Approved only' },
    { id:'delta',    label:'Delta', beta:true },
  ];
  const fileTree = `submit-order/
├── workflow.json
├── nodes/
│   ├── webhook-trigger.v1.0.0.json
│   ├── order-form.v1.1.0.json
│   ├── validate-order.v2.0.1.json
│   ├── payment-gateway.v1.3.0.json
│   ├── route-request.v1.0.0.json
│   ├── send-confirmation.v1.0.2.json
│   └── audit-log.v1.1.1.json
└── schemas/
    └── logic.schema.json`;
  return (
    <Dialog open={open} title="Export spec" onClose={onClose} width={600}
      actions={[
        <Button key="c" variant="secondary" onClick={onClose}>Cancel</Button>,
        <Button key="d" variant="primary">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 2v8M3 6l4 4 4-4M2 12h10" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>
          Download ZIP
        </Button>,
      ]}>
      <div style={{ display:'flex', borderBottom:'1px solid #e4e4e7', marginBottom:16, gap:0 }}>
        {tabs.map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{
            padding:'8px 14px', background:'none', border:'none',
            borderBottom: tab===t.id?'2px solid #ff6d5a':'2px solid transparent',
            color: tab===t.id?'#1f1f1f':'#525457', fontWeight: tab===t.id?600:500,
            fontSize:13, cursor:'pointer', marginBottom:-1, fontFamily:'inherit',
            display:'inline-flex', alignItems:'center', gap:6,
          }}>
            {t.label}
            {t.beta && <Tag color="warning" size="sm" style={{padding:'0 4px', fontSize:9}}>BETA</Tag>}
          </button>
        ))}
      </div>
      {tab === 'delta' && <Banner tone="warning" style={{marginBottom:14}}>Delta export is experimental. Validate that your target agent benefits from deltas before relying on this export.</Banner>}
      <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
        <FormField label="Scope">
          <Select value={scope} onChange={setScope} options={['Entire app','Specific workflow','Specific node']} aria-label="Scope" style={{width:'100%'}}/>
        </FormField>
        {tab !== 'delta' && (
          <FormField label="Format">
            <div style={{ display:'flex', gap:8 }}>
              {[{v:'json',l:'JSON'},{v:'yaml',l:'YAML', beta:true}].map(f=>(
                <label key={f.v} style={{
                  flex:1, padding:'10px 14px', borderRadius:5,
                  border:`1px solid ${format===f.v?'#ff6d5a':'#dbdcdf'}`,
                  background: format===f.v?'#fef0ed':'#fff',
                  cursor:'pointer', display:'flex', alignItems:'center', gap:8,
                  fontSize:13, fontWeight: format===f.v?600:500,
                  color: format===f.v?'#c75541':'#525457',
                }}>
                  <input type="radio" name="fmt" value={f.v} checked={format===f.v} onChange={()=>setFormat(f.v)} style={{accentColor:'#ff6d5a'}}/>
                  {f.l}
                  {f.beta && <Tag color="warning" size="sm" style={{padding:'0 4px', fontSize:9}}>BETA</Tag>}
                </label>
              ))}
            </div>
          </FormField>
        )}
        {tab === 'delta' && (
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
            <FormField label="From version"><Select options={['v1.0.0','v1.1.0','v2.0.0']} placeholder="From…" aria-label="From version" style={{width:'100%'}}/></FormField>
            <FormField label="To version"><Select options={['v1.1.0','v1.2.0','v2.0.1']} placeholder="To…" aria-label="To version" style={{width:'100%'}}/></FormField>
          </div>
        )}
        <FormField label="File tree preview">
          <pre style={{
            background:'#1f1f1f', color:'#cdd5e0',
            fontFamily:'ui-monospace,"SF Mono",monospace', fontSize:11.5,
            padding:'12px 14px', borderRadius:5, overflow:'auto',
            margin:0, lineHeight:1.6,
          }}>{fileTree}</pre>
        </FormField>
      </div>
    </Dialog>
  );
}

Object.assign(window, { NodePicker, NodeDetailDrawer, ReviewPanel, NotificationCenter, ExportModal });
