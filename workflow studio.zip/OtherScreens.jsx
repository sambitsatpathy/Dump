// OtherScreens.jsx — Home, Review Queue, Review Panel, Notification Center, Node Detail

// ─── Mock Data ────────────────────────────────────────────────────────────────
const QUEUE_DATA = [
  { id:'q1', name:'order-form',        type:'Node',     version:'v1.2.0', submittedBy:'alice', submittedAt:'2026-04-21 09:14', status:'IN_REVIEW',        category:'UI'     },
  { id:'q2', name:'validate-order',    type:'Node',     version:'v2.1.0', submittedBy:'bob',   submittedAt:'2026-04-21 10:32', status:'SUBMITTED',        category:'Logic'  },
  { id:'q3', name:'submit-order',      type:'Workflow', version:'v3.0.0', submittedBy:'alice', submittedAt:'2026-04-20 16:05', status:'CHANGES_REQUESTED',category:'—'      },
  { id:'q4', name:'payment-gateway',   type:'Node',     version:'v1.4.0', submittedBy:'carol', submittedAt:'2026-04-20 11:20', status:'SUBMITTED',        category:'Infra'  },
  { id:'q5', name:'audit-log',         type:'Node',     version:'v1.2.0', submittedBy:'bob',   submittedAt:'2026-04-19 14:55', status:'REJECTED',         category:'Data'   },
  { id:'q6', name:'send-confirmation', type:'Node',     version:'v1.1.0', submittedBy:'carol', submittedAt:'2026-04-18 08:30', status:'IN_REVIEW',        category:'Data'   },
];
const NOTIFICATIONS = [
  { id:'notif1', unread:true,  type:'Submission', title:'alice submitted order-form v1.2.0 for review', time:'2m ago',  icon:'info'    },
  { id:'notif2', unread:true,  type:'Comment',    title:'bob commented on validate-order v2.1.0',       time:'15m ago', icon:'warning' },
  { id:'notif3', unread:true,  type:'Upgrade',    title:'payment-gateway v1.4.0 is now APPROVED',       time:'1h ago',  icon:'success' },
  { id:'notif4', unread:false, type:'Rejection',  title:'audit-log v1.1.1 was rejected by checker-dan',time:'3h ago',  icon:'error'   },
  { id:'notif5', unread:false, type:'Approval',   title:'route-request v1.0.0 was approved',            time:'1d ago',  icon:'success' },
  { id:'notif6', unread:false, type:'Comment',    title:'carol replied to your comment on submit-order', time:'2d ago', icon:'warning' },
];

// ─── Home Screen ──────────────────────────────────────────────────────────────
function HomeScreen({ onNavigate }) {
  const kpis = [
    { label:'Total Workflows', value:'12',   icon:'⬡', color:'var(--salt-accent-foreground)'           },
    { label:'Total Nodes',     value:'48',   icon:'◈', color:'var(--cat-logic)'                        },
    { label:'Pending Review',  value:'6',    icon:'⏳', color:'var(--salt-status-warning-foreground)', warn:true },
    { label:'Approved',        value:'31',   icon:'✓', color:'var(--salt-status-success-foreground)'   },
  ];
  const recentActivity = [
    { time:'09:14', user:'alice', action:'submitted', spec:'order-form v1.2.0', status:'IN_REVIEW' },
    { time:'08:55', user:'bob',   action:'commented on', spec:'validate-order v2.1.0', status:'IN_REVIEW' },
    { time:'Yesterday', user:'carol', action:'rejected', spec:'audit-log v1.1.1', status:'REJECTED' },
    { time:'Yesterday', user:'dan',   action:'approved', spec:'route-request v1.0.0', status:'APPROVED' },
  ];
  const statusColors = { IN_REVIEW:'warning', APPROVED:'success', REJECTED:'error', SUBMITTED:'info' };
  return (
    <div style={{ flex:1, overflow:'auto', padding:'20px 24px' }}>
      {/* Page header */}
      <div style={{ marginBottom:20 }}>
        <div style={{ fontSize:11, color:'var(--salt-content-secondary-foreground)', marginBottom:4 }}>
          MyApp / Workflows
        </div>
        <div style={{ display:'flex', alignItems:'baseline', gap:12, marginBottom:3 }}>
          <h2 style={{ fontSize:20, fontWeight:600, color:'var(--salt-content-primary-foreground)' }}>submit-order</h2>
          <Chip appearance="bordered" sentiment="positive" style={{ fontSize:10 }}>APPROVED</Chip>
        </div>
        <span style={{ fontSize:11, color:'var(--salt-content-secondary-foreground)', fontFamily:'var(--salt-text-code-fontFamily)' }}>
          Last updated Apr 21, 2026 at 10:32 · v3.0.0
        </span>
      </div>

      {/* KPI cards */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, marginBottom:24 }}>
        {kpis.map(k => (
          <Card key={k.label} style={{ padding:'14px 16px' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:8 }}>
              <span style={{ fontSize:11, color:'var(--salt-content-secondary-foreground)', fontWeight:500 }}>{k.label}</span>
              {k.warn && <StatusIndicator status="warning" />}
            </div>
            <div style={{ fontSize:28, fontWeight:700, color:k.color, lineHeight:1 }}>{k.value}</div>
          </Card>
        ))}
      </div>

      {/* Two-col layout */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 320px', gap:16 }}>
        {/* Workflow mini-canvas */}
        <Card style={{ padding:0, overflow:'hidden' }}>
          <div style={{ padding:'10px 14px', borderBottom:'1px solid var(--salt-separable-primary-borderColor)', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <span style={{ fontSize:13, fontWeight:600 }}>Workflow Graph</span>
            <Button appearance="bordered" size="sm" onClick={()=>onNavigate('flow')}>Open in Editor →</Button>
          </div>
          <div style={{ padding:20, display:'flex', gap:16, alignItems:'center', justifyContent:'center', minHeight:200 }}>
            {/* Mini workflow visualization */}
            {[
              { label:'order-form', cat:'UI', status:'APPROVED' },
              { label:'validate-order', cat:'Logic', status:'IN_REVIEW' },
              { label:'payment-gateway', cat:'Infra', status:'APPROVED' },
              { label:'send-confirm…', cat:'Data', status:'DRAFT' },
            ].map((n,i,arr) => (
              <React.Fragment key={n.label}>
                <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:6 }}>
                  <div style={{
                    width:100, padding:'8px 10px', background:'var(--salt-container-tertiary-background)',
                    border:`1px solid var(--salt-separable-primary-borderColor)`,
                    borderLeft:`3px solid ${Object.values({UI:'var(--cat-ui)',Logic:'var(--cat-logic)',Infra:'var(--cat-infra)',Data:'var(--cat-data)'})[i]}`,
                    borderRadius:3, fontSize:10,
                  }}>
                    <div style={{ fontWeight:600, marginBottom:3, fontSize:11 }}>{n.label}</div>
                    <StatusIndicator status={n.status==='APPROVED'?'success':n.status==='IN_REVIEW'?'warning':'info'} size="sm" />
                    <span style={{ fontSize:10, color:'var(--salt-content-secondary-foreground)', marginLeft:4 }}>{n.status}</span>
                  </div>
                </div>
                {i < arr.length-1 && <span style={{ color:'var(--salt-separable-primary-borderColor)', fontSize:16 }}>→</span>}
              </React.Fragment>
            ))}
          </div>
        </Card>

        {/* Recent activity */}
        <Card style={{ padding:0, overflow:'hidden' }}>
          <div style={{ padding:'10px 14px', borderBottom:'1px solid var(--salt-separable-primary-borderColor)' }}>
            <span style={{ fontSize:13, fontWeight:600 }}>Recent Activity</span>
          </div>
          <div style={{ padding:'8px 0' }}>
            {recentActivity.map((a,i) => (
              <div key={i} style={{ padding:'8px 14px', borderBottom:'1px solid var(--salt-separable-secondary-borderColor)', display:'flex', gap:10, alignItems:'flex-start' }}>
                <StatusIndicator status={statusColors[a.status] || 'info'} size="sm" style={{ marginTop:3 }} />
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontSize:12 }}>
                    <span style={{ fontWeight:600, color:'var(--salt-accent-foreground)' }}>{a.user}</span>
                    {' '}{a.action}{' '}
                    <span style={{ fontFamily:'var(--salt-text-code-fontFamily)', fontSize:11 }}>{a.spec}</span>
                  </div>
                  <div style={{ fontSize:10, color:'var(--salt-content-secondary-foreground)', marginTop:2 }}>{a.time}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

// ─── Review Queue ─────────────────────────────────────────────────────────────
function ReviewQueue({ onOpenReview }) {
  const [search, setSearch] = React.useState('');
  const [statusF, setStatusF] = React.useState('');
  const [typeF, setTypeF] = React.useState('');
  const cols = ['Name','Type','Version','Submitted By','Submitted At','Status'];
  const statusColors = { IN_REVIEW:'warning', SUBMITTED:'info', CHANGES_REQUESTED:'warning', REJECTED:'error', APPROVED:'success' };
  const filtered = QUEUE_DATA.filter(r => {
    if (search && !r.name.toLowerCase().includes(search.toLowerCase())) return false;
    if (statusF && r.status !== statusF) return false;
    if (typeF && r.type !== typeF) return false;
    return true;
  });
  return (
    <div style={{ flex:1, overflow:'hidden', display:'flex', flexDirection:'column' }}>
      {/* Header */}
      <div style={{ padding:'16px 24px 12px', borderBottom:'1px solid var(--salt-separable-primary-borderColor)', flexShrink:0 }}>
        <div style={{ fontSize:11, color:'var(--salt-content-secondary-foreground)', marginBottom:4 }}>MyApp / Review Queue</div>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <h2 style={{ fontSize:18, fontWeight:600 }}>Review Queue</h2>
          <span style={{ fontFamily:'var(--salt-text-code-fontFamily)', fontSize:11, color:'var(--salt-status-warning-foreground)' }}>
            {QUEUE_DATA.filter(r=>r.status==='IN_REVIEW'||r.status==='SUBMITTED').length} pending
          </span>
        </div>
      </div>
      {/* Filter bar */}
      <div style={{ padding:'10px 24px', borderBottom:'1px solid var(--salt-separable-primary-borderColor)', display:'flex', gap:10, flexShrink:0 }}>
        <Input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search…" startAdornment="⌕" aria-label="Search queue" style={{ width:220 }} />
        <Dropdown value={statusF} options={['IN_REVIEW','SUBMITTED','CHANGES_REQUESTED','REJECTED','APPROVED']}
          placeholder="Status" onChange={setStatusF} aria-label="Status filter" style={{ width:160 }} />
        <Dropdown value={typeF} options={['Node','Workflow']} placeholder="Type" onChange={setTypeF} aria-label="Type filter" style={{ width:110 }} />
        {(search||statusF||typeF) && <Button appearance="transparent" size="sm" onClick={()=>{setSearch('');setStatusF('');setTypeF('');}}>✕ Clear</Button>}
      </div>
      {/* Table */}
      <div style={{ flex:1, overflow:'auto' }}>
        <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
          <thead>
            <tr style={{ borderBottom:'1px solid var(--salt-separable-primary-borderColor)', position:'sticky', top:0, background:'var(--salt-container-secondary-background)', zIndex:1 }}>
              {cols.map(c=>(
                <th key={c} style={{ padding:'8px 16px', textAlign:'left', fontSize:11, fontWeight:600, color:'var(--salt-content-secondary-foreground)', whiteSpace:'nowrap' }}>{c}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map(row => (
              <tr key={row.id} onClick={()=>onOpenReview(row)} style={{ borderBottom:'1px solid var(--salt-separable-secondary-borderColor)', cursor:'pointer', transition:'background 0.1s' }}
                onMouseEnter={e=>e.currentTarget.style.background='var(--salt-container-tertiary-background)'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                <td style={{ padding:'9px 16px', fontWeight:500 }}>{row.name}</td>
                <td style={{ padding:'9px 16px', color:'var(--salt-content-secondary-foreground)' }}>{row.type}</td>
                <td style={{ padding:'9px 16px', fontFamily:'var(--salt-text-code-fontFamily)', fontSize:11 }}>{row.version}</td>
                <td style={{ padding:'9px 16px', color:'var(--salt-accent-foreground)' }}>{row.submittedBy}</td>
                <td style={{ padding:'9px 16px', fontFamily:'var(--salt-text-code-fontFamily)', fontSize:11, color:'var(--salt-content-secondary-foreground)' }}>{row.submittedAt}</td>
                <td style={{ padding:'9px 16px' }}>
                  <Chip sentiment={statusColors[row.status]==='warning'?'caution':statusColors[row.status]==='error'?'negative':statusColors[row.status]==='success'?'positive':'info'}>
                    <StatusIndicator status={statusColors[row.status]||'info'} size="sm" />
                    <span style={{ marginLeft:4 }}>{row.status.replace(/_/g,' ')}</span>
                  </Chip>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div style={{ padding:40, textAlign:'center', color:'var(--salt-content-secondary-foreground)', fontSize:13 }}>
            No items match the current filters.
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Review Panel Drawer ──────────────────────────────────────────────────────
const DIFF_LINES = [
  { type:'unchanged', text:'id: validate-order' },
  { type:'unchanged', text:'category: Logic' },
  { type:'removed',   text:'version: 2.0.1' },
  { type:'added',     text:'version: 2.1.0' },
  { type:'unchanged', text:'label: Validate Order' },
  { type:'removed',   text:'description: Basic validation' },
  { type:'added',     text:'description: Full validation with null-guard on order_id' },
  { type:'unchanged', text:'tags: [validation]' },
  { type:'added',     text:'properties:' },
  { type:'added',     text:'  strictMode: true' },
  { type:'added',     text:'  maxRetries: 3' },
];

function ReviewPanel({ item, onClose }) {
  const [comment, setComment] = React.useState('');
  const [dialog, setDialog] = React.useState(null);
  const [rejectReason, setRejectReason] = React.useState('');
  const comments = [
    { author:'alice', time:'Apr 21 09:14', body:'Added null-guard for order_id as requested. Also bumped strictMode to true.', fromPrev: false },
    { author:'checker-dan', time:'Apr 20 16:30', body:'Please add null-guard on order_id before processing. This caused prod issues.', fromPrev: true },
  ];
  if (!item) return null;
  const lineColor = t => t==='added' ? 'var(--salt-status-success-foreground)' : t==='removed' ? 'var(--salt-status-error-foreground)' : 'var(--salt-content-secondary-foreground)';
  const linePrefix = t => t==='added' ? '+' : t==='removed' ? '-' : ' ';
  return (
    <>
      <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.4)', zIndex:200 }} onClick={onClose} />
      <div style={{
        position:'fixed', top:0, right:0, bottom:0, width:'62%', zIndex:201,
        background:'var(--salt-container-secondary-background)',
        borderLeft:'1px solid var(--salt-separable-primary-borderColor)',
        display:'flex', flexDirection:'column', boxShadow:'-8px 0 32px rgba(0,0,0,0.4)',
      }}>
        {/* Drawer header */}
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 18px', borderBottom:'1px solid var(--salt-separable-primary-borderColor)', flexShrink:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <h3 style={{ fontSize:15, fontWeight:600 }}>{item.name}</h3>
            <span style={{ fontFamily:'var(--salt-text-code-fontFamily)', fontSize:12, color:'var(--salt-content-secondary-foreground)' }}>{item.version}</span>
          </div>
          <div style={{ display:'flex', gap:8, alignItems:'center' }}>
            <Button sentiment="accented" onClick={()=>setDialog('approve')}>Approve</Button>
            <Button sentiment="caution" appearance="bordered" onClick={()=>setDialog('changes')}>Request Changes</Button>
            <Button sentiment="negative" appearance="bordered" onClick={()=>setDialog('reject')}>Reject</Button>
            <Button appearance="transparent" onClick={onClose} aria-label="Close">✕</Button>
          </div>
        </div>

        <div style={{ flex:1, overflow:'auto', padding:'16px 18px', display:'flex', flexDirection:'column', gap:16 }}>
          {/* Blocking deps if workflow */}
          {item.type==='Workflow' && (
            <Banner sentiment="caution">
              ⚠ This workflow contains node refs with non-APPROVED status. Approval is blocked until all dependencies are APPROVED.
            </Banner>
          )}

          {/* Diff view */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:0, border:'1px solid var(--salt-separable-primary-borderColor)', borderRadius:4, overflow:'hidden' }}>
            {['v1.1.0 (current APPROVED)','v1.2.0 (incoming)'].map((col,ci) => (
              <div key={ci} style={{ borderRight: ci===0?'1px solid var(--salt-separable-primary-borderColor)':'none' }}>
                <div style={{ padding:'7px 12px', background:'var(--salt-container-tertiary-background)', borderBottom:'1px solid var(--salt-separable-primary-borderColor)', fontSize:11, color:'var(--salt-content-secondary-foreground)', fontWeight:600 }}>{col}</div>
                <div style={{ padding:'10px 12px', fontFamily:'var(--salt-text-code-fontFamily)', fontSize:11, lineHeight:'18px' }}>
                  {DIFF_LINES.map((line,i)=>{
                    const show = ci===0 ? line.type!=='added' : line.type!=='removed';
                    return show ? (
                      <div key={i} style={{ color:lineColor(line.type), background: line.type!=='unchanged'?(ci===0?'rgba(239,68,68,0.08)':'rgba(34,197,94,0.08)'):'transparent', padding:'0 4px', borderRadius:1 }}>
                        <span style={{ opacity:0.5, marginRight:8 }}>{linePrefix(line.type)}</span>{line.text}
                      </div>
                    ) : <div key={i} style={{ opacity:0 }}>—</div>;
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* Comment thread */}
          <div>
            <div style={{ fontSize:12, fontWeight:600, marginBottom:10, color:'var(--salt-content-secondary-foreground)' }}>COMMENTS</div>
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              {comments.map((c,i)=>(
                <Card key={i} style={{ padding:'10px 12px' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:6 }}>
                    <div style={{ width:22, height:22, borderRadius:'50%', background:'var(--salt-accent-background)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:10, fontWeight:700, color:'#fff' }}>
                      {c.author[0].toUpperCase()}
                    </div>
                    <span style={{ fontSize:12, fontWeight:600 }}>{c.author}</span>
                    <span style={{ fontSize:10, color:'var(--salt-content-secondary-foreground)', fontFamily:'var(--salt-text-code-fontFamily)' }}>{c.time}</span>
                    {c.fromPrev && <Chip appearance="bordered" sentiment="caution" style={{ fontSize:9 }}>from previous review</Chip>}
                    <span style={{ flex:1 }} />
                    <Button appearance="transparent" size="sm" aria-label="Resolve">Resolve</Button>
                  </div>
                  <p style={{ fontSize:12, lineHeight:1.5, color:'var(--salt-content-primary-foreground)' }}>{c.body}</p>
                </Card>
              ))}
            </div>
            <div style={{ marginTop:12, display:'flex', flexDirection:'column', gap:6 }}>
              <label style={{ fontSize:11, color:'var(--salt-content-secondary-foreground)', fontWeight:500 }}>Add comment</label>
              <Textarea value={comment} onChange={e=>setComment(e.target.value)} placeholder="Write a comment…" rows={2} aria-label="Add comment" />
              <Button appearance="solid" disabled={!comment.trim()} style={{ alignSelf:'flex-end' }}>Submit</Button>
            </div>
          </div>
        </div>
      </div>

      {/* Confirm dialogs */}
      <Dialog open={dialog==='approve'} title="Approve Submission" onClose={()=>setDialog(null)}
        actions={[<Button key="cancel" appearance="bordered" onClick={()=>setDialog(null)}>Cancel</Button>, <Button key="confirm" sentiment="accented">Confirm Approval</Button>]}>
        <p style={{ fontSize:13, lineHeight:1.6 }}>Approve <strong>{item.name} {item.version}</strong>? This will move the spec to APPROVED status and notify the maker.</p>
      </Dialog>
      <Dialog open={dialog==='reject'} title="Reject Submission" onClose={()=>setDialog(null)}
        actions={[<Button key="cancel" appearance="bordered" onClick={()=>setDialog(null)}>Cancel</Button>, <Button key="confirm" sentiment="negative" appearance="bordered" disabled={!rejectReason.trim()}>Confirm Rejection</Button>]}>
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          <p style={{ fontSize:13 }}>Rejecting <strong>{item.name} {item.version}</strong>. Please provide a reason:</p>
          <Textarea value={rejectReason} onChange={e=>setRejectReason(e.target.value)} placeholder="Reason for rejection…" rows={3} aria-label="Rejection reason" />
        </div>
      </Dialog>
      <Dialog open={dialog==='changes'} title="Request Changes" onClose={()=>setDialog(null)}
        actions={[<Button key="cancel" appearance="bordered" onClick={()=>setDialog(null)}>Cancel</Button>, <Button key="confirm" sentiment="caution" appearance="bordered" disabled={!rejectReason.trim()}>Send Request</Button>]}>
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          <p style={{ fontSize:13 }}>Specify what changes are needed for <strong>{item.name} {item.version}</strong>:</p>
          <Textarea value={rejectReason} onChange={e=>setRejectReason(e.target.value)} placeholder="Describe required changes…" rows={3} aria-label="Changes description" />
        </div>
      </Dialog>
    </>
  );
}

// ─── Notification Center ──────────────────────────────────────────────────────
function NotificationCenter({ onClose }) {
  const [notifs, setNotifs] = React.useState(NOTIFICATIONS);
  const [filter, setFilter] = React.useState('all');
  const [typeF, setTypeF] = React.useState('');
  const unreadCount = notifs.filter(n=>n.unread).length;
  const markAllRead = () => setNotifs(ns => ns.map(n=>({...n,unread:false})));
  const filtered = notifs.filter(n => {
    if (filter==='unread' && !n.unread) return false;
    if (typeF && n.type!==typeF) return false;
    return true;
  });
  return (
    <>
      <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.3)', zIndex:200 }} onClick={onClose} />
      <div style={{
        position:'fixed', top:0, right:0, bottom:0, width:420, zIndex:201,
        background:'var(--salt-container-secondary-background)',
        borderLeft:'1px solid var(--salt-separable-primary-borderColor)',
        display:'flex', flexDirection:'column', boxShadow:'-6px 0 24px rgba(0,0,0,0.35)',
      }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 16px', borderBottom:'1px solid var(--salt-separable-primary-borderColor)', flexShrink:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <h3 style={{ fontSize:14, fontWeight:600 }}>Notifications</h3>
            {unreadCount > 0 && <Chip sentiment="info" style={{ fontSize:10 }}>{unreadCount}</Chip>}
          </div>
          <div style={{ display:'flex', gap:6 }}>
            <Button appearance="transparent" size="sm" onClick={markAllRead}>Mark all read</Button>
            <Button appearance="transparent" onClick={onClose} aria-label="Close">✕</Button>
          </div>
        </div>
        <div style={{ padding:'8px 12px', borderBottom:'1px solid var(--salt-separable-secondary-borderColor)', display:'flex', gap:8, flexShrink:0 }}>
          <ToggleButtonGroup options={[{value:'all',label:'All'},{value:'unread',label:'Unread'},{value:'mentions',label:'Mentions'}]} value={filter} onChange={setFilter} />
          <Dropdown value={typeF} options={['Submission','Approval','Rejection','Comment','Upgrade']} placeholder="Type" onChange={setTypeF} aria-label="Event type filter" style={{ flex:1 }} />
        </div>
        <div style={{ flex:1, overflow:'auto' }}>
          {filtered.length === 0 ? (
            <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:'100%', gap:12, color:'var(--salt-content-secondary-foreground)' }}>
              <span style={{ fontSize:28 }}>🔔</span>
              <span style={{ fontSize:13 }}>You're all caught up.</span>
            </div>
          ) : filtered.map(n => (
            <div key={n.id} onClick={()=>setNotifs(ns=>ns.map(x=>x.id===n.id?{...x,unread:false}:x))}
              style={{
                display:'flex', gap:10, padding:'11px 14px',
                borderBottom:'1px solid var(--salt-separable-secondary-borderColor)',
                borderLeft: n.unread ? '3px solid var(--salt-status-info-foreground)' : '3px solid transparent',
                cursor:'pointer', transition:'background 0.1s',
                background: n.unread ? 'rgba(59,130,246,0.04)' : 'transparent',
              }}
              onMouseEnter={e=>e.currentTarget.style.background='var(--salt-container-tertiary-background)'}
              onMouseLeave={e=>e.currentTarget.style.background=n.unread?'rgba(59,130,246,0.04)':'transparent'}>
              <StatusIndicator status={n.icon} size="sm" style={{ marginTop:4, flexShrink:0 }} />
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:12, lineHeight:1.4, color: n.unread ? 'var(--salt-content-primary-foreground)' : 'var(--salt-content-secondary-foreground)' }}>{n.title}</div>
                <div style={{ fontSize:10, color:'var(--salt-content-secondary-foreground)', marginTop:3, fontFamily:'var(--salt-text-code-fontFamily)' }}>{n.time}</div>
              </div>
              <Menu items={[{label:'Mark read'},{label:'Open spec'},{label:'Mute this spec'}]}
                trigger={<Button appearance="transparent" size="sm" aria-label="More options">⋯</Button>} />
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// ─── Node Detail Drawer ───────────────────────────────────────────────────────
function NodeDetailDrawer({ node, onClose }) {
  const [activeTab, setActiveTab] = React.useState('details');
  const [comment, setComment] = React.useState('');
  if (!node) return null;
  const catColor = CATEGORY_COLORS[node.category] || '#888';
  const sc = STATUS_CONFIGS[node.status] || STATUS_CONFIGS.DRAFT;
  const versionHistory = [
    { ver:'v1.1.0', status:'APPROVED', author:'alice', date:'Mar 12, 2026', msg:'Initial approval' },
    { ver:'v1.0.1', status:'APPROVED', author:'bob',   date:'Feb 28, 2026', msg:'Fix null-guard on order_id' },
    { ver:'v1.0.0', status:'REJECTED', author:'alice', date:'Feb 20, 2026', msg:'Missing validation logic' },
  ];
  const tabs = [
    { id:'details',    label:'Details'   },
    { id:'properties', label:'Properties', badge: node.status==='CHANGES_REQUESTED' },
    { id:'lifecycle',  label:'Lifecycle'  },
    { id:'comments',   label:'Comments'   },
    { id:'versions',   label:'Versions'   },
  ];
  return (
    <>
      <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.3)', zIndex:200 }} onClick={onClose} />
      <div style={{
        position:'fixed', top:0, right:0, bottom:0, width:640, zIndex:201,
        background:'var(--salt-container-secondary-background)',
        borderLeft:'1px solid var(--salt-separable-primary-borderColor)',
        display:'flex', flexDirection:'column', boxShadow:'-8px 0 32px rgba(0,0,0,0.4)',
      }}>
        {/* Header */}
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 16px', borderBottom:'1px solid var(--salt-separable-primary-borderColor)', flexShrink:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <span style={{ width:4, height:20, background:catColor, borderRadius:2 }} />
            <h3 style={{ fontSize:15, fontWeight:600 }}>{node.label}</h3>
            <Chip sentiment={sc.saltStatus==='success'?'positive':sc.saltStatus==='error'?'negative':sc.saltStatus==='warning'?'caution':'info'}>
              <StatusIndicator status={sc.saltStatus} size="sm" />
              <span style={{ marginLeft:4 }}>{sc.label}</span>
            </Chip>
            <span style={{ fontFamily:'var(--salt-text-code-fontFamily)', fontSize:11, color:'var(--salt-content-secondary-foreground)' }}>{node.version}</span>
          </div>
          <Button appearance="transparent" onClick={onClose} aria-label="Close">✕</Button>
        </div>

        {/* Tabs */}
        <Tabs tabs={tabs} activeTab={activeTab} onTabChange={setActiveTab}>
          {activeTab === 'details' && (
            <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
              <FormField label="ID"><Input value={node.id} readOnly style={{ width:'100%', fontFamily:'var(--salt-text-code-fontFamily)', fontSize:11 }} /></FormField>
              <FormField label="Label"><Input value={node.label} readOnly style={{ width:'100%' }} /></FormField>
              <FormField label="Category"><Input value={node.category} readOnly style={{ width:'100%' }} /></FormField>
              <FormField label="Tags">
                <div style={{ display:'flex', gap:4, flexWrap:'wrap' }}>
                  {node.tags.map(t=><Chip key={t} appearance="bordered">{t}</Chip>)}
                </div>
              </FormField>
              <FormField label="Description"><Textarea value="Handles order submission form with client-side validation. Integrates with validate-order and payment-gateway nodes." readOnly rows={3} aria-label="Description" /></FormField>
            </div>
          )}
          {activeTab === 'properties' && (
            <div style={{ display:'flex', flexDirection:'column', gap:0 }}>
              {node.status==='CHANGES_REQUESTED' && <Banner sentiment="caution" style={{ marginBottom:12 }}>Schema validation errors found. Fix before saving.</Banner>}
              <table style={{ width:'100%', borderCollapse:'collapse', fontSize:12 }}>
                <thead><tr style={{ borderBottom:'1px solid var(--salt-separable-primary-borderColor)' }}>
                  <th style={{ padding:'6px 10px', textAlign:'left', fontSize:11, fontWeight:600, color:'var(--salt-content-secondary-foreground)', width:'40%' }}>Key</th>
                  <th style={{ padding:'6px 10px', textAlign:'left', fontSize:11, fontWeight:600, color:'var(--salt-content-secondary-foreground)' }}>Value</th>
                </tr></thead>
                <tbody>
                  {[{k:'strictMode',v:'true',err:null},{k:'maxRetries',v:'3',err:null},{k:'timeout',v:'-1',err:'Must be a positive integer'},{k:'schema',v:'v2.0',err:null}].map(row=>(
                    <tr key={row.k} style={{ borderBottom:'1px solid var(--salt-separable-secondary-borderColor)' }}>
                      <td style={{ padding:'7px 10px', fontFamily:'var(--salt-text-code-fontFamily)', fontSize:11 }}>{row.k}</td>
                      <td style={{ padding:'7px 10px' }}>
                        <Input value={row.v} aria-label={row.k} style={{ width:'100%' }} />
                        {row.err && <div style={{ fontSize:10, color:'var(--salt-status-error-foreground)', marginTop:3 }}>{row.err}</div>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div style={{ marginTop:12, fontSize:10, color:'var(--salt-content-secondary-foreground)', display:'flex', alignItems:'center', gap:4 }}>
                Schema: <span style={{ fontFamily:'var(--salt-text-code-fontFamily)' }}>/specs/schemas/logic.schema.json</span>
                <span style={{ color:'var(--salt-accent-foreground)', cursor:'pointer' }}>↗</span>
              </div>
            </div>
          )}
          {activeTab === 'lifecycle' && (
            <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
              {[{label:'Status',value:sc.label},{label:'Submitted By',value:'alice'},{label:'Submitted At',value:'Apr 21, 2026 09:14'},{label:'Reviewed By',value:'checker-dan'},{label:'Reviewed At',value:'Apr 21, 2026 15:30'}].map(f=>(
                <FormField key={f.label} label={f.label}><Input value={f.value} readOnly style={{ width:'100%' }} /></FormField>
              ))}
              <div style={{ display:'flex', gap:8, marginTop:4 }}>
                <Button appearance="bordered" sentiment="accented" size="sm">Submit for Review</Button>
                <Button appearance="transparent" size="sm">Withdraw</Button>
              </div>
            </div>
          )}
          {activeTab === 'comments' && (
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              <div style={{ display:'flex', justifyContent:'flex-end' }}>
                <Dropdown value="unresolved" options={['unresolved','all','orphaned']} aria-label="Comment filter" style={{ width:130 }} />
              </div>
              {[
                { author:'checker-dan', time:'Apr 21', body:'Logic does not handle null order_id. Add validation guard.', fromPrev:true },
                { author:'alice', time:'Apr 21', body:'Acknowledged, will fix in next version.', fromPrev:false },
              ].map((c,i)=>(
                <Card key={i} style={{ padding:'10px 12px' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:5 }}>
                    <div style={{ width:20, height:20, borderRadius:'50%', background:'var(--salt-accent-background)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:9, fontWeight:700, color:'#fff' }}>{c.author[0].toUpperCase()}</div>
                    <span style={{ fontSize:12, fontWeight:600 }}>{c.author}</span>
                    <span style={{ fontSize:10, color:'var(--salt-content-secondary-foreground)', fontFamily:'var(--salt-text-code-fontFamily)' }}>{c.time}</span>
                    {c.fromPrev && <Chip appearance="bordered" sentiment="caution" style={{ fontSize:9 }}>from previous review</Chip>}
                  </div>
                  <p style={{ fontSize:12, lineHeight:1.5 }}>{c.body}</p>
                </Card>
              ))}
              <div style={{ marginTop:4, display:'flex', flexDirection:'column', gap:6 }}>
                <Textarea value={comment} onChange={e=>setComment(e.target.value)} placeholder="Add a comment…" rows={2} aria-label="Add comment" />
                <Button appearance="solid" disabled={!comment.trim()} style={{ alignSelf:'flex-end' }}>Submit</Button>
              </div>
            </div>
          )}
          {activeTab === 'versions' && (
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              <div style={{ display:'flex', justifyContent:'flex-end', marginBottom:4 }}>
                <Button appearance="bordered" size="sm">Compare versions</Button>
              </div>
              {versionHistory.map((v,i)=>(
                <Card key={i} accent={v.status==='APPROVED'?'var(--salt-status-success-foreground)':'var(--salt-status-error-foreground)'} style={{ padding:'10px 12px' }}>
                  <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                      <span style={{ fontFamily:'var(--salt-text-code-fontFamily)', fontSize:12, fontWeight:700 }}>{v.ver}</span>
                      <StatusIndicator status={v.status==='APPROVED'?'success':'error'} size="sm" />
                      <span style={{ fontSize:11, color:'var(--salt-content-secondary-foreground)' }}>{v.status}</span>
                    </div>
                    <Menu items={[{label:'View at this version'},{label:'Compare to…'},{label:'Duplicate as new DRAFT'}]}
                      trigger={<Button appearance="transparent" size="sm" aria-label="Version actions">⋯</Button>} />
                  </div>
                  <div style={{ fontSize:11, color:'var(--salt-content-secondary-foreground)', marginTop:6, fontFamily:'var(--salt-text-code-fontFamily)' }}>
                    {v.author} · {v.date}
                  </div>
                  <div style={{ fontSize:12, marginTop:4 }}>{v.msg}</div>
                </Card>
              ))}
            </div>
          )}
        </Tabs>
      </div>
    </>
  );
}

Object.assign(window, { HomeScreen, ReviewQueue, ReviewPanel, NotificationCenter, NodeDetailDrawer, QUEUE_DATA });
