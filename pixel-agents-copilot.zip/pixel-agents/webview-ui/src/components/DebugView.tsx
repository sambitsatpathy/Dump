import type { ToolActivity } from '../office/types.js';
import { vscode } from '../vscodeApi.js';
import { Button } from './ui/Button.js';

interface DebugViewProps {
  agents: number[];
  selectedAgent: number | null;
  agentTools: Record<number, ToolActivity[]>;
  agentStatuses: Record<number, string>;
  subagentTools: Record<number, Record<string, ToolActivity[]>>;
  onSelectAgent: (id: number) => void;
}

function ToolDot({ tool }: { tool: ToolActivity }) {
  const color = tool.done
    ? 'bg-status-success'
    : tool.permissionWait
      ? 'bg-status-permission'
      : 'bg-status-active';
  return (
    <span
      className={`w-6 h-6 rounded-full inline-block shrink-0 ${color} ${tool.done ? '' : 'pixel-pulse'}`}
    />
  );
}

function ToolLine({ tool }: { tool: ToolActivity }) {
  return (
    <span
      className={`text-base flex items-center gap-5 ${tool.done ? 'opacity-50' : 'opacity-80'}`}
    >
      <ToolDot tool={tool} />
      {tool.permissionWait && !tool.done ? 'Needs approval' : tool.status}
    </span>
  );
}

export function DebugView({
  agents,
  selectedAgent,
  agentTools,
  agentStatuses,
  subagentTools,
  onSelectAgent,
}: DebugViewProps) {
  const renderAgentCard = (id: number) => {
    const isSelected = selectedAgent === id;
    const tools = agentTools[id] || [];
    const subs = subagentTools[id] || {};
    const status = agentStatuses[id];
    const hasActiveTools = tools.some((t) => !t.done);
    return (
      <div
        key={id}
        className={`rounded-none py-6 px-8 border-2 cursor-pointer ${isSelected ? 'border-accent bg-active-bg' : 'border-border'}`}
        onClick={() => onSelectAgent(id)}
      >
        <span className="flex items-center justify-between">
          <span
            className={`rounded-none py-6 px-10 text-xl ${isSelected ? 'text-white font-bold' : ''}`}
          >
            Copilot Agent #{id}
          </span>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              vscode.postMessage({ type: 'closeAgent', id });
            }}
            className={`opacity-70 ${isSelected ? 'text-white' : ''}`}
            title="Remove agent"
          >
            ✕
          </Button>
        </span>
        {(tools.length > 0 || status === 'waiting') && (
          <div className="flex flex-col gap-[1px] mt-4 pl-4">
            {tools.map((tool) => (
              <div key={tool.toolId}>
                <ToolLine tool={tool} />
                {subs[tool.toolId] && subs[tool.toolId].length > 0 && (
                  <div className="ml-3 pl-8 mt-[1px] flex flex-col gap-[1px] border-l-2 border-border">
                    {subs[tool.toolId].map((subTool) => (
                      <ToolLine key={subTool.toolId} tool={subTool} />
                    ))}
                  </div>
                )}
              </div>
            ))}
            {status === 'waiting' && !hasActiveTools && (
              <span className="text-base opacity-85 flex items-center gap-5">
                <span className="w-6 h-6 rounded-full inline-block shrink-0 bg-status-permission" />
                Waiting for Copilot
              </span>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="absolute inset-0 overflow-auto bg-bg z-15">
      <div className="px-12 py-6 text-2xl">
        <h2 className="text-3xl font-bold mb-8">Debug View</h2>
        <div className="flex flex-col gap-6">{agents.map(renderAgentCard)}</div>
      </div>
    </div>
  );
}
