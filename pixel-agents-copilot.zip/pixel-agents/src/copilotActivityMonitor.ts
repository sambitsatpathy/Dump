import * as vscode from 'vscode';

export type ActivityType = 'typing' | 'reading' | 'searching' | 'waiting' | 'idle';

export class CopilotActivityMonitor {
  private idleTimer: ReturnType<typeof setTimeout> | null = null;
  private static readonly IDLE_TIMEOUT_MS = 10_000;
  private readonly onActivity: (type: ActivityType) => void;

  constructor(onActivity: (type: ActivityType) => void, context: vscode.ExtensionContext) {
    this.onActivity = onActivity;
    this.registerTools(context);
    this.subscribeToWorkspaceEvents(context);
    context.subscriptions.push({ dispose: () => this.dispose() });
  }

  private registerTools(context: vscode.ExtensionContext): void {
    context.subscriptions.push(
      vscode.lm.registerTool('pixel_agents_read', {
        invoke: async (_options, _token) => {
          this.emit('reading');
          return new vscode.LanguageModelToolResult([
            new vscode.LanguageModelTextPart('Pixel Agents: read activity noted'),
          ]);
        },
      }),
      vscode.lm.registerTool('pixel_agents_search', {
        invoke: async (_options, _token) => {
          this.emit('searching');
          return new vscode.LanguageModelToolResult([
            new vscode.LanguageModelTextPart('Pixel Agents: search activity noted'),
          ]);
        },
      }),
      vscode.lm.registerTool('pixel_agents_command', {
        invoke: async (_options, _token) => {
          this.emit('waiting');
          return new vscode.LanguageModelToolResult([
            new vscode.LanguageModelTextPart('Pixel Agents: command activity noted'),
          ]);
        },
      }),
    );
  }

  private subscribeToWorkspaceEvents(context: vscode.ExtensionContext): void {
    context.subscriptions.push(
      vscode.workspace.onDidChangeTextDocument(() => this.emit('typing')),
      vscode.workspace.onDidCreateFiles(() => this.emit('typing')),
      vscode.workspace.onDidSaveTextDocument(() => this.emit('typing')),
      vscode.window.onDidOpenTerminal(() => this.emit('waiting')),
    );
  }

  private emit(type: ActivityType): void {
    if (this.idleTimer !== null) {
      clearTimeout(this.idleTimer);
    }
    this.onActivity(type);
    this.idleTimer = setTimeout(() => {
      this.idleTimer = null;
      this.onActivity('idle');
    }, CopilotActivityMonitor.IDLE_TIMEOUT_MS);
  }

  dispose(): void {
    if (this.idleTimer !== null) {
      clearTimeout(this.idleTimer);
      this.idleTimer = null;
    }
  }
}
