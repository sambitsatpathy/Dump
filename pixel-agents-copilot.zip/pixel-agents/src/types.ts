export interface AgentState {
  id: number;
  sessionId: string;
  activityStatus: 'idle' | 'typing' | 'reading' | 'searching' | 'waiting';
  lastActivityAt: number;
}

export interface PersistedAgent {
  id: number;
  sessionId: string;
}
