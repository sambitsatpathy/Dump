import * as vscode from 'vscode';

import { WORKSPACE_KEY_AGENT_SEATS, WORKSPACE_KEY_AGENTS } from './constants.js';
import { migrateAndLoadLayout } from './layoutPersistence.js';
import type { AgentState, PersistedAgent } from './types.js';

export function createLocalAgent(
  nextAgentIdRef: { current: number },
  agents: Map<number, AgentState>,
  webview: vscode.Webview | undefined,
  persistAgentsFn: () => void,
): void {
  const id = nextAgentIdRef.current++;
  const agent: AgentState = {
    id,
    sessionId: crypto.randomUUID(),
    activityStatus: 'idle',
    lastActivityAt: 0,
  };
  agents.set(id, agent);
  persistAgentsFn();
  webview?.postMessage({ type: 'agentCreated', id });
}

export function removeAgent(
  agentId: number,
  agents: Map<number, AgentState>,
  persistAgentsFn: () => void,
): void {
  agents.delete(agentId);
  persistAgentsFn();
}

export function persistAgents(
  agents: Map<number, AgentState>,
  context: vscode.ExtensionContext,
): void {
  const persisted: PersistedAgent[] = [...agents.values()].map((a) => ({
    id: a.id,
    sessionId: a.sessionId,
  }));
  context.workspaceState.update(WORKSPACE_KEY_AGENTS, persisted);
}

export function restoreAgents(
  context: vscode.ExtensionContext,
  nextAgentIdRef: { current: number },
  agents: Map<number, AgentState>,
): void {
  const persisted = context.workspaceState.get<PersistedAgent[]>(WORKSPACE_KEY_AGENTS, []);
  let maxId = 0;
  for (const p of persisted) {
    if (agents.has(p.id)) continue;
    agents.set(p.id, {
      id: p.id,
      sessionId: p.sessionId,
      activityStatus: 'idle',
      lastActivityAt: 0,
    });
    if (p.id > maxId) maxId = p.id;
  }
  if (maxId >= nextAgentIdRef.current) {
    nextAgentIdRef.current = maxId + 1;
  }
}

export function sendExistingAgents(
  agents: Map<number, AgentState>,
  context: vscode.ExtensionContext,
  webview: vscode.Webview | undefined,
): void {
  if (!webview) return;
  const agentIds = [...agents.keys()].sort((a, b) => a - b);
  const agentMeta = context.workspaceState.get<
    Record<string, { palette?: number; seatId?: string }>
  >(WORKSPACE_KEY_AGENT_SEATS, {});
  webview.postMessage({
    type: 'existingAgents',
    agents: agentIds,
    agentMeta,
    folderNames: {},
    externalAgents: {},
  });
}

export function sendCurrentAgentStatuses(
  agents: Map<number, AgentState>,
  webview: vscode.Webview | undefined,
): void {
  if (!webview) return;
  for (const [agentId, agent] of agents) {
    if (agent.activityStatus !== 'idle') {
      const toolName = activityToToolName(agent.activityStatus);
      webview.postMessage({
        type: 'agentToolStart',
        id: agentId,
        toolId: 'copilot-activity',
        status: toolName,
        toolName,
      });
    }
  }
}

function activityToToolName(status: AgentState['activityStatus']): string {
  switch (status) {
    case 'typing':
      return 'Write';
    case 'reading':
      return 'Read';
    case 'searching':
      return 'WebSearch';
    case 'waiting':
      return 'Bash';
    default:
      return '';
  }
}

export function sendLayout(
  context: vscode.ExtensionContext,
  webview: vscode.Webview | undefined,
  defaultLayout?: Record<string, unknown> | null,
): void {
  if (!webview) return;
  const result = migrateAndLoadLayout(context, defaultLayout);
  webview.postMessage({
    type: 'layoutLoaded',
    layout: result?.layout ?? null,
    wasReset: result?.wasReset ?? false,
  });
}
