import * as vscode from "vscode";
import * as path from "path";
import { SaltKnowledgeBase } from "./sources/saltKnowledgeBase";
import { LocalKnowledgeBase } from "./sources/localKnowledgeBase";
import { PackageKnowledgeBase } from "./sources/packageKnowledgeBase";
import { UrlKnowledgeBase } from "./sources/urlKnowledgeBase";

// ---------------------------------------------------------------------------
// Core interfaces — implement these to add a new knowledge base source
// ---------------------------------------------------------------------------

export interface KnowledgeBaseContext {
  /** Raw text chunks relevant to the query, ready to inject into a system prompt */
  chunks: ContextChunk[];
  /** Human-readable label for what was loaded, e.g. "Salt v3.2.0" */
  sourceLabel: string;
  /** Optional metadata to surface in the chat response */
  meta?: Record<string, string>;
}

export interface ContextChunk {
  content: string;
  /** Where this chunk came from — file path, URL, package name, etc. */
  source: string;
  /** Optional relevance score (0–1) if the KB supports semantic ranking */
  score?: number;
}

export interface KnowledgeBase {
  /** Unique identifier, matches the --with flag value e.g. "salt", "local" */
  readonly id: string;
  /** Human-readable name shown in the UI */
  readonly displayName: string;
  /** Returns true if this KB is available in the current workspace/environment */
  isAvailable(workspaceRoot: string | null): Promise<boolean>;
  /**
   * Load and return context relevant to the query.
   * @param query     The user's natural language question
   * @param args      Full parsed args (so the KB can read --path etc.)
   * @param workspaceRoot  Absolute path to the workspace root
   */
  getContext(
    query: string,
    args: CookArgs,
    workspaceRoot: string | null
  ): Promise<KnowledgeBaseContext>;
}

// ---------------------------------------------------------------------------
// Argument parser
// ---------------------------------------------------------------------------

export interface CookArgs {
  /** The --with value, e.g. "salt" | "local" | "package" | "url" */
  with: string | null;
  /** The --path value — local folder path, URL, or npm package name */
  path: string | null;
  /** Remaining prompt text after stripping all --flags */
  query: string;
  /** Raw original prompt for debugging */
  raw: string;
}

/**
 * Parses a raw chat prompt into structured CookArgs.
 *
 * Supports:
 *   @cook --with salt what token should I use for a primary button?
 *   @cook --with local --path ./docs how do I set up theming?
 *   @cook --with url --path https://example.com/docs what is X?
 *   @cook --with package --path react-query how do I use useQuery?
 */
export function parseArgs(rawPrompt: string): CookArgs {
  const raw = rawPrompt.trim();
  let remaining = raw;

  const extract = (flag: string): string | null => {
    // Matches --flag value (quoted or unquoted, stops at next -- or end)
    const re = new RegExp(
      `--${flag}\\s+(?:"([^"]+)"|'([^']+)'|([^\\s-][^\\s]*)(?=\\s|$))`,
      "i"
    );
    const match = remaining.match(re);
    if (!match) return null;
    remaining = remaining.replace(match[0], "").trim();
    return (match[1] ?? match[2] ?? match[3] ?? "").trim();
  };

  const withVal = extract("with");
  const pathVal = extract("path");

  // Strip any remaining --flags we don't recognise to keep the query clean
  const query = remaining.replace(/--\w+\s*\S*/g, "").trim();

  return { with: withVal, path: pathVal, query, raw };
}

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------

export class KnowledgeBaseRouter {
  private static registry: Map<string, KnowledgeBase> = new Map();

  /** Register a knowledge base implementation. Call this in extension.ts activate(). */
  static register(kb: KnowledgeBase): void {
    this.registry.set(kb.id.toLowerCase(), kb);
  }

  /** Register all built-in knowledge bases. */
  static registerDefaults(): void {
    this.register(new SaltKnowledgeBase());
    this.register(new LocalKnowledgeBase());
    this.register(new PackageKnowledgeBase());
    this.register(new UrlKnowledgeBase());
  }

  /** Returns the KB for the given --with value, or null if not found. */
  static resolve(id: string | null): KnowledgeBase | null {
    if (!id) return null;
    return this.registry.get(id.toLowerCase()) ?? null;
  }

  /** Returns all registered KB ids. */
  static listIds(): string[] {
    return Array.from(this.registry.keys());
  }

  /** Returns availability status for each registered KB. */
  static async listAvailable(
    workspaceRoot: string | null
  ): Promise<Array<{ id: string; displayName: string; available: boolean }>> {
    const results = [];
    for (const kb of this.registry.values()) {
      results.push({
        id: kb.id,
        displayName: kb.displayName,
        available: await kb.isAvailable(workspaceRoot),
      });
    }
    return results;
  }
}

// ---------------------------------------------------------------------------
// Utility: get workspace root
// ---------------------------------------------------------------------------

export function getWorkspaceRoot(): string | null {
  const folders = vscode.workspace.workspaceFolders;
  return folders && folders.length > 0 ? folders[0].uri.fsPath : null;
}

// ---------------------------------------------------------------------------
// Utility: format context chunks into an LLM-ready string
// ---------------------------------------------------------------------------

export function formatContextForPrompt(ctx: KnowledgeBaseContext): string {
  const header = `## Knowledge Base: ${ctx.sourceLabel}\n\n`;
  const body = ctx.chunks
    .slice(0, 20) // cap to avoid blowing the context window
    .map(
      (chunk, i) =>
        `### Chunk ${i + 1} (${chunk.source}):\n${chunk.content.trim()}`
    )
    .join("\n\n---\n\n");

  return header + body;
}
