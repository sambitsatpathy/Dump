import * as vscode from "vscode";
import {
  parseArgs,
  KnowledgeBaseRouter,
  formatContextForPrompt,
  getWorkspaceRoot,
  CookArgs,
} from "./router";

// ---------------------------------------------------------------------------
// System prompt
// ---------------------------------------------------------------------------

function buildSystemPrompt(contextBlock: string): string {
  return `
You are Cook — an expert developer assistant that answers questions using a 
specific knowledge base provided to you below.

Your job is to answer the user's question ONLY using the knowledge base context 
provided. If the answer is not in the context, say so clearly and suggest where 
they might find it.

Rules:
1. Always ground your answer in the provided context. Quote relevant parts.
2. When showing code examples, use TypeScript unless the context suggests otherwise.
3. If the knowledge base contains version info, mention it in your response.
4. Be concise. Lead with the answer, then explain.
5. If multiple approaches exist in the context, list them with tradeoffs.
6. Never invent APIs, components, or tokens that aren't in the context.

---

${contextBlock}

---

Answer the user's question based on the above context.
`.trim();
}

// ---------------------------------------------------------------------------
// Help message
// ---------------------------------------------------------------------------

function buildHelpMessage(): string {
  const kbs = KnowledgeBaseRouter.listIds();
  return `
👨‍🍳 **Cook** — pluggable knowledge base assistant

**Usage:**
\`\`\`
@cook --with <source> [--path <value>] your question
\`\`\`

**Available sources:**
${kbs.map((id) => `- \`--with ${id}\``).join("\n")}

**Examples:**
\`\`\`
@cook --with salt what token should I use for a primary button background?
@cook --with local --path ./docs how do I configure theming?
@cook --with package --path react-hook-form how do I handle form validation?
@cook --with url --path https://tanstack.com/query/latest/docs how do I use useQuery?
\`\`\`

**Slash commands:**
- \`/sources\` — list all available knowledge bases and their status
- \`/help\` — show this message
`.trim();
}

// ---------------------------------------------------------------------------
// Slash command: /sources
// ---------------------------------------------------------------------------

async function handleSourcesCommand(
  stream: vscode.ChatResponseStream
): Promise<void> {
  stream.markdown("## 📚 Available Knowledge Bases\n\n");

  const workspaceRoot = getWorkspaceRoot();
  const sources = await KnowledgeBaseRouter.listAvailable(workspaceRoot);

  for (const { id, displayName, available } of sources) {
    const status = available ? "✅ Available" : "⚠️ Not available";
    stream.markdown(`- **\`--with ${id}\`** — ${displayName} — ${status}\n`);
  }

  stream.markdown(
    "\n> Run `@cook /help` to see usage examples for each source."
  );
}

// ---------------------------------------------------------------------------
// Main handler
// ---------------------------------------------------------------------------

type ChatHandler = Parameters<typeof vscode.chat.createChatParticipant>[1];

async function handleChatRequest(
  request: vscode.ChatRequest,
  _context: vscode.ChatContext,
  stream: vscode.ChatResponseStream,
  token: vscode.CancellationToken
): Promise<void> {
  // --- Slash commands ---
  if (request.command === "help") {
    stream.markdown(buildHelpMessage());
    return;
  }

  if (request.command === "sources") {
    await handleSourcesCommand(stream);
    return;
  }

  // --- Parse arguments ---
  const args: CookArgs = parseArgs(request.prompt);

  // If no --with flag provided, show help
  if (!args.with) {
    stream.markdown(
      "👋 Hi! I'm **Cook**. Use `--with` to tell me which knowledge base to use.\n\n"
    );
    stream.markdown(buildHelpMessage());
    return;
  }

  if (!args.query) {
    stream.markdown(
      `Got it — using **${args.with}** as the knowledge base. What's your question?`
    );
    return;
  }

  // --- Resolve knowledge base ---
  const kb = KnowledgeBaseRouter.resolve(args.with);

  if (!kb) {
    stream.markdown(
      `❌ Unknown knowledge base: \`--with ${args.with}\`\n\n` +
        `Available sources: ${KnowledgeBaseRouter.listIds()
          .map((id) => `\`${id}\``)
          .join(", ")}\n\n` +
        `Run \`@cook /help\` for usage examples.`
    );
    return;
  }

  // --- Check availability ---
  const workspaceRoot = getWorkspaceRoot();
  const available = await kb.isAvailable(workspaceRoot);

  if (!available) {
    stream.markdown(
      `⚠️ **${kb.displayName}** is not available in this workspace.\n\n`
    );
    if (args.with === "salt") {
      stream.markdown(
        "Make sure `@salt-ds/core` is installed:\n```\nnpm install @salt-ds/core\n```"
      );
    } else if (args.with === "package") {
      stream.markdown(
        `Make sure the package is installed:\n\`\`\`\nnpm install ${args.path ?? "<package-name>"}\n\`\`\``
      );
    }
    return;
  }

  // --- Load context from knowledge base ---
  stream.progress(`Loading ${kb.displayName}...`);

  let kbContext;
  try {
    kbContext = await kb.getContext(args.query, args, workspaceRoot);
  } catch (err: any) {
    stream.markdown(
      `❌ Failed to load knowledge base: ${err.message}`
    );
    return;
  }

  if (kbContext.chunks.length === 0) {
    stream.markdown(
      `⚠️ No content found in **${kb.displayName}**. ` +
        `Try a different path or check that the source is accessible.`
    );
    return;
  }

  stream.progress(`Searching ${kbContext.sourceLabel}...`);

  // --- Select language model ---
  const models = await vscode.lm.selectChatModels({
    vendor: "copilot",
    family: "gpt-4o",
  });

  if (!models || models.length === 0) {
    stream.markdown(
      "⚠️ No Copilot language model available. Make sure GitHub Copilot is installed and signed in."
    );
    return;
  }

  const model = models[0];

  // --- Build and send prompt ---
  const contextBlock = formatContextForPrompt(kbContext);
  const systemPrompt = buildSystemPrompt(contextBlock);

  const messages = [
    vscode.LanguageModelChatMessage.User(
      `${systemPrompt}\n\nQuestion: ${args.query}`
    ),
  ];

  // Show source attribution header before streaming
  stream.markdown(
    `> 📖 Answering from **${kbContext.sourceLabel}**\n\n`
  );

  try {
    const response = await model.sendRequest(messages, {}, token);
    for await (const chunk of response.text) {
      if (token.isCancellationRequested) break;
      stream.markdown(chunk);
    }
  } catch (err: any) {
    if (err instanceof vscode.LanguageModelError) {
      stream.markdown(
        `\n\n⚠️ Language model error: ${err.message} (code: \`${err.code}\`)`
      );
    } else {
      throw err;
    }
  }
}

// ---------------------------------------------------------------------------
// Registration
// ---------------------------------------------------------------------------

export function registerChatParticipant(
  context: vscode.ExtensionContext
): void {
  const participant = vscode.chat.createChatParticipant(
    "cook.assistant",
    handleChatRequest as ChatHandler
  );

  participant.iconPath = new vscode.ThemeIcon("book");

  participant.followupProvider = {
    provideFollowups(
      _result: vscode.ChatResult,
      _context: vscode.ChatContext,
      _token: vscode.CancellationToken
    ): vscode.ChatFollowup[] {
      return [
        {
          prompt: "",
          command: "sources",
          label: "$(list-unordered) List available knowledge bases",
        },
        {
          prompt: "",
          command: "help",
          label: "$(question) Show usage help",
        },
      ];
    },
  };

  context.subscriptions.push(participant);
}
