import * as vscode from "vscode";
import { KnowledgeBaseRouter } from "./router";
import { registerChatParticipant } from "./chatParticipant";

export async function activate(context: vscode.ExtensionContext): Promise<void> {
  console.log("[Cook] Activating...");

  // Register all built-in knowledge base sources
  KnowledgeBaseRouter.registerDefaults();

  // Register the @cook Copilot chat participant
  registerChatParticipant(context);

  console.log("[Cook] Ready ✅");
}

export function deactivate(): void {}
