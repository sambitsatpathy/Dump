import * as fs from "fs";
import * as path from "path";
import { KnowledgeBase, KnowledgeBaseContext, CookArgs, ContextChunk } from "../router";

// ---------------------------------------------------------------------------
// npm Package knowledge base
// Usage: @cook --with package --path react-query how do I use useQuery?
//        @cook --with package --path @tanstack/react-table how do I sort rows?
// Reads README, TypeScript declarations, and package.json from node_modules
// ---------------------------------------------------------------------------

export class PackageKnowledgeBase implements KnowledgeBase {
  readonly id = "package";
  readonly displayName = "npm Package";

  async isAvailable(workspaceRoot: string | null): Promise<boolean> {
    return workspaceRoot !== null && fs.existsSync(
      path.join(workspaceRoot, "node_modules")
    );
  }

  async getContext(
    query: string,
    args: CookArgs,
    workspaceRoot: string | null
  ): Promise<KnowledgeBaseContext> {
    const packageName = args.path;

    if (!packageName) {
      return {
        chunks: [
          {
            content:
              "Error: --path is required when using --with package.\n" +
              "Example: @cook --with package --path react-query your question here",
            source: "cook-error",
          },
        ],
        sourceLabel: "Package (no name provided)",
      };
    }

    if (!workspaceRoot) {
      return {
        chunks: [
          {
            content: "Error: No workspace open. Open a folder with node_modules.",
            source: "cook-error",
          },
        ],
        sourceLabel: `Package: ${packageName}`,
      };
    }

    const pkgRoot = path.join(workspaceRoot, "node_modules", packageName);

    if (!fs.existsSync(pkgRoot)) {
      return {
        chunks: [
          {
            content:
              `Package "${packageName}" not found in node_modules.\n` +
              `Run: npm install ${packageName}`,
            source: "cook-error",
          },
        ],
        sourceLabel: `Package: ${packageName} (not installed)`,
      };
    }

    const chunks: ContextChunk[] = [];

    // 1. package.json metadata
    const metaChunk = this.readPackageMeta(pkgRoot, packageName);
    if (metaChunk) chunks.push(metaChunk);

    // 2. README
    const readmeChunk = this.readReadme(pkgRoot, packageName, query);
    if (readmeChunk) chunks.push(...readmeChunk);

    // 3. TypeScript declarations
    const dtsChunks = this.readDeclarations(pkgRoot, packageName, query);
    chunks.push(...dtsChunks);

    // 4. CHANGELOG (for version-specific queries)
    if (/change|version|update|release|migrat/i.test(query)) {
      const changelogChunk = this.readChangelog(pkgRoot, packageName);
      if (changelogChunk) chunks.push(changelogChunk);
    }

    const version = this.readVersion(pkgRoot);
    return {
      chunks,
      sourceLabel: `${packageName}${version ? ` v${version}` : ""}`,
      meta: { packageName, pkgRoot, version: version ?? "unknown" },
    };
  }

  // -------------------------------------------------------------------------

  private readPackageMeta(pkgRoot: string, packageName: string): ContextChunk | null {
    try {
      const pkg = JSON.parse(
        fs.readFileSync(path.join(pkgRoot, "package.json"), "utf8")
      );
      const lines = [
        `Package: ${pkg.name}`,
        `Version: ${pkg.version}`,
        pkg.description ? `Description: ${pkg.description}` : null,
        pkg.keywords?.length
          ? `Keywords: ${pkg.keywords.join(", ")}`
          : null,
        pkg.main ? `Main: ${pkg.main}` : null,
        pkg.types ?? pkg.typings
          ? `Types: ${pkg.types ?? pkg.typings}`
          : null,
        pkg.exports ? `Has package exports map: yes` : null,
        pkg.peerDependencies
          ? `Peer deps: ${Object.keys(pkg.peerDependencies).join(", ")}`
          : null,
      ]
        .filter(Boolean)
        .join("\n");

      return { content: lines, source: `${packageName}/package.json` };
    } catch {
      return null;
    }
  }

  private readReadme(
    pkgRoot: string,
    packageName: string,
    query: string
  ): ContextChunk[] {
    const candidates = ["README.md", "readme.md", "Readme.md", "README.txt"];
    for (const name of candidates) {
      const filePath = path.join(pkgRoot, name);
      if (!fs.existsSync(filePath)) continue;

      try {
        const content = fs.readFileSync(filePath, "utf8");
        return this.extractRelevantSections(content, query, `${packageName}/${name}`);
      } catch {
        break;
      }
    }
    return [];
  }

  private readDeclarations(
    pkgRoot: string,
    packageName: string,
    query: string
  ): ContextChunk[] {
    // Find the types entry point
    let dtsPath: string | null = null;
    try {
      const pkg = JSON.parse(
        fs.readFileSync(path.join(pkgRoot, "package.json"), "utf8")
      );
      const typesField = pkg.types ?? pkg.typings;
      if (typesField) {
        const candidate = path.join(pkgRoot, typesField);
        if (fs.existsSync(candidate)) dtsPath = candidate;
      }
    } catch {
      /* ignore */
    }

    // Fallback candidates
    if (!dtsPath) {
      const fallbacks = [
        path.join(pkgRoot, "dist", "index.d.ts"),
        path.join(pkgRoot, "index.d.ts"),
        path.join(pkgRoot, "types", "index.d.ts"),
      ];
      dtsPath = fallbacks.find((p) => fs.existsSync(p)) ?? null;
    }

    if (!dtsPath) return [];

    try {
      const content = fs.readFileSync(dtsPath, "utf8");
      // Extract export declarations most relevant to the query
      return this.extractRelevantSections(
        content,
        query,
        path.relative(pkgRoot, dtsPath).replace(/\\/g, "/")
      );
    } catch {
      return [];
    }
  }

  private readChangelog(pkgRoot: string, packageName: string): ContextChunk | null {
    const candidates = [
      "CHANGELOG.md",
      "changelog.md",
      "CHANGES.md",
      "HISTORY.md",
    ];
    for (const name of candidates) {
      const filePath = path.join(pkgRoot, name);
      if (!fs.existsSync(filePath)) continue;
      try {
        const content = fs.readFileSync(filePath, "utf8");
        // Return just the first 3000 chars (recent releases)
        return {
          content: content.slice(0, 3000),
          source: `${packageName}/${name}`,
        };
      } catch {
        break;
      }
    }
    return null;
  }

  private readVersion(pkgRoot: string): string | null {
    try {
      const pkg = JSON.parse(
        fs.readFileSync(path.join(pkgRoot, "package.json"), "utf8")
      );
      return pkg.version ?? null;
    } catch {
      return null;
    }
  }

  /**
   * Splits text into sections and returns the ones most relevant to the query
   * using simple keyword overlap scoring.
   */
  private extractRelevantSections(
    text: string,
    query: string,
    source: string
  ): ContextChunk[] {
    const queryTerms = query
      .toLowerCase()
      .split(/\s+/)
      .filter((t) => t.length > 2);

    // Split on headings or blank lines
    const sections = text
      .split(/(?=^#{1,4}\s|\n\n)/m)
      .map((s) => s.trim())
      .filter((s) => s.length > 40 && s.length < 5000);

    const scored = sections.map((section) => {
      const lower = section.toLowerCase();
      const score = queryTerms.reduce(
        (acc, term) => acc + (lower.split(term).length - 1),
        0
      );
      return { content: section, source, score };
    });

    return scored
      .sort((a, b) => b.score - a.score)
      .slice(0, 8)
      .map(({ score, ...chunk }) => chunk);
  }
}
