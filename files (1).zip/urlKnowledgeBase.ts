import * as https from "https";
import * as http from "http";
import { KnowledgeBase, KnowledgeBaseContext, CookArgs, ContextChunk } from "../router";

// ---------------------------------------------------------------------------
// URL knowledge base
// Usage: @cook --with url --path https://tanstack.com/query/latest/docs how do I sort?
// Fetches a remote docs page, strips HTML, and uses it as context
// ---------------------------------------------------------------------------

const FETCH_TIMEOUT_MS = 8000;
const MAX_CONTENT_CHARS = 30000;

export class UrlKnowledgeBase implements KnowledgeBase {
  readonly id = "url";
  readonly displayName = "Remote URL";

  async isAvailable(_workspaceRoot: string | null): Promise<boolean> {
    // Always available as long as we have network
    return true;
  }

  async getContext(
    query: string,
    args: CookArgs,
    _workspaceRoot: string | null
  ): Promise<KnowledgeBaseContext> {
    const url = args.path;

    if (!url) {
      return {
        chunks: [
          {
            content:
              "Error: --path is required when using --with url.\n" +
              "Example: @cook --with url --path https://example.com/docs your question here",
            source: "cook-error",
          },
        ],
        sourceLabel: "URL (no path provided)",
      };
    }

    if (!url.startsWith("http://") && !url.startsWith("https://")) {
      return {
        chunks: [
          {
            content: `Error: --path must be a full URL starting with http:// or https://`,
            source: "cook-error",
          },
        ],
        sourceLabel: `URL: ${url}`,
      };
    }

    let html: string;
    try {
      html = await this.fetchUrl(url);
    } catch (err: any) {
      return {
        chunks: [
          {
            content: `Error fetching URL "${url}": ${err.message}`,
            source: "cook-error",
          },
        ],
        sourceLabel: `URL: ${url} (fetch failed)`,
      };
    }

    const text = this.extractText(html);
    const chunks = this.chunkAndRank(text, query, url);

    return {
      chunks,
      sourceLabel: `URL: ${url}`,
      meta: { url },
    };
  }

  // -------------------------------------------------------------------------

  private fetchUrl(url: string): Promise<string> {
    return new Promise((resolve, reject) => {
      const protocol = url.startsWith("https://") ? https : http;
      const req = protocol.get(
        url,
        {
          headers: {
            "User-Agent": "Mozilla/5.0 (VS Code Cook Extension)",
            Accept: "text/html,text/plain",
          },
        },
        (res) => {
          // Follow redirects (up to 3)
          if (
            res.statusCode &&
            res.statusCode >= 300 &&
            res.statusCode < 400 &&
            res.headers.location
          ) {
            resolve(this.fetchUrl(res.headers.location));
            return;
          }

          if (res.statusCode && res.statusCode >= 400) {
            reject(new Error(`HTTP ${res.statusCode}`));
            return;
          }

          let data = "";
          res.on("data", (chunk) => {
            data += chunk;
            if (data.length > MAX_CONTENT_CHARS * 3) {
              req.destroy();
              resolve(data);
            }
          });
          res.on("end", () => resolve(data));
          res.on("error", reject);
        }
      );

      req.setTimeout(FETCH_TIMEOUT_MS, () => {
        req.destroy();
        reject(new Error(`Timeout after ${FETCH_TIMEOUT_MS}ms`));
      });

      req.on("error", reject);
    });
  }

  private extractText(html: string): string {
    return html
      // Remove script, style, nav, header, footer blocks
      .replace(/<script[\s\S]*?<\/script>/gi, "")
      .replace(/<style[\s\S]*?<\/style>/gi, "")
      .replace(/<nav[\s\S]*?<\/nav>/gi, "")
      .replace(/<header[\s\S]*?<\/header>/gi, "")
      .replace(/<footer[\s\S]*?<\/footer>/gi, "")
      // Preserve heading text with markers
      .replace(/<h([1-4])[^>]*>([\s\S]*?)<\/h\1>/gi, (_, level, inner) => {
        const text = inner.replace(/<[^>]+>/g, "").trim();
        return `\n${"#".repeat(Number(level))} ${text}\n`;
      })
      // Preserve code blocks
      .replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, (_, inner) => {
        const code = inner.replace(/<[^>]+>/g, "").trim();
        return `\n\`\`\`\n${code}\n\`\`\`\n`;
      })
      // Strip remaining tags
      .replace(/<[^>]+>/g, " ")
      // Decode common entities
      .replace(/&nbsp;/g, " ")
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      // Collapse whitespace
      .replace(/[ \t]{2,}/g, " ")
      .replace(/\n{3,}/g, "\n\n")
      .trim()
      .slice(0, MAX_CONTENT_CHARS);
  }

  private chunkAndRank(text: string, query: string, url: string): ContextChunk[] {
    const queryTerms = query
      .toLowerCase()
      .split(/\s+/)
      .filter((t) => t.length > 2);

    // Split on headings
    const sections = text
      .split(/(?=^#{1,4}\s)/m)
      .map((s) => s.trim())
      .filter((s) => s.length > 60);

    const scored = sections.map((section) => {
      const lower = section.toLowerCase();
      const score = queryTerms.reduce(
        (acc, term) => acc + (lower.split(term).length - 1),
        0
      );
      return { content: section.slice(0, 2000), source: url, score };
    });

    return scored
      .sort((a, b) => b.score - a.score)
      .slice(0, 12)
      .map(({ score, ...chunk }) => chunk);
  }
}
