import * as fs from "fs";
import * as path from "path";
import { KnowledgeBase, KnowledgeBaseContext, CookArgs, ContextChunk } from "../router";

// ---------------------------------------------------------------------------
// Salt Design System knowledge base
// Reads @salt-ds CSS tokens + TypeScript declarations directly from node_modules
// ---------------------------------------------------------------------------

export class SaltKnowledgeBase implements KnowledgeBase {
  readonly id = "salt";
  readonly displayName = "Salt Design System";

  async isAvailable(workspaceRoot: string | null): Promise<boolean> {
    if (!workspaceRoot) return false;
    return fs.existsSync(
      path.join(workspaceRoot, "node_modules", "@salt-ds", "core")
    );
  }

  async getContext(
    query: string,
    _args: CookArgs,
    workspaceRoot: string | null
  ): Promise<KnowledgeBaseContext> {
    if (!workspaceRoot) {
      return this.emptyContext("Salt (workspace not found)");
    }

    const chunks: ContextChunk[] = [];

    // 1. Read package versions
    const versionChunk = this.readVersions(workspaceRoot);
    if (versionChunk) chunks.push(versionChunk);

    // 2. Read token CSS files
    const tokenChunks = this.readTokens(workspaceRoot, query);
    chunks.push(...tokenChunks);

    // 3. Read component declaration files
    const componentChunks = this.readComponents(workspaceRoot, query);
    chunks.push(...componentChunks);

    return {
      chunks,
      sourceLabel: this.buildVersionLabel(workspaceRoot),
      meta: { source: "node_modules/@salt-ds" },
    };
  }

  // -------------------------------------------------------------------------

  private readVersions(workspaceRoot: string): ContextChunk | null {
    try {
      const corePkg = JSON.parse(
        fs.readFileSync(
          path.join(workspaceRoot, "node_modules/@salt-ds/core/package.json"),
          "utf8"
        )
      );
      const lines = [`Salt Core version: ${corePkg.version}`];

      const labPkgPath = path.join(
        workspaceRoot,
        "node_modules/@salt-ds/lab/package.json"
      );
      if (fs.existsSync(labPkgPath)) {
        const labPkg = JSON.parse(fs.readFileSync(labPkgPath, "utf8"));
        lines.push(`Salt Lab version: ${labPkg.version}`);
      }

      return {
        content: lines.join("\n"),
        source: "node_modules/@salt-ds/*/package.json",
      };
    } catch {
      return null;
    }
  }

  private readTokens(workspaceRoot: string, query: string): ContextChunk[] {
    const chunks: ContextChunk[] = [];
    const cssDir = path.join(
      workspaceRoot,
      "node_modules/@salt-ds/theme/css"
    );

    if (!fs.existsSync(cssDir)) return chunks;

    // Only read files relevant to the query to keep context tight
    const relevantFiles = this.selectRelevantCssFiles(cssDir, query);

    for (const filePath of relevantFiles) {
      try {
        const content = fs.readFileSync(filePath, "utf8");
        // Extract just the custom property declarations
        const tokenLines = content
          .split("\n")
          .filter((line) => line.trim().startsWith("--salt-"))
          .slice(0, 80) // cap per file
          .join("\n");

        if (tokenLines.trim()) {
          chunks.push({
            content: `CSS Design Tokens from ${path.basename(filePath)}:\n${tokenLines}`,
            source: path.relative(workspaceRoot, filePath),
          });
        }
      } catch {
        // skip unreadable files
      }
    }

    return chunks;
  }

  private selectRelevantCssFiles(cssDir: string, query: string): string[] {
    const allFiles = fs
      .readdirSync(cssDir)
      .filter((f) => f.endsWith(".css"))
      .map((f) => path.join(cssDir, f));

    const lower = query.toLowerCase();

    // Pick files by keyword hints in the query
    const hints: Array<[RegExp, string]> = [
      [/color|colour|theme|palette/, "color"],
      [/spacing|margin|padding|gap/, "spacing"],
      [/font|text|typography/, "typography"],
      [/shadow|elevation/, "shadow"],
      [/border|radius|outline/, "border"],
      [/size|dimension|height|width/, "size"],
    ];

    const matched = new Set<string>();
    for (const [pattern, keyword] of hints) {
      if (pattern.test(lower)) {
        allFiles
          .filter((f) => path.basename(f).toLowerCase().includes(keyword))
          .forEach((f) => matched.add(f));
      }
    }

    // If nothing matched or query is generic, return all files (capped)
    return matched.size > 0 ? [...matched] : allFiles.slice(0, 4);
  }

  private readComponents(workspaceRoot: string, query: string): ContextChunk[] {
    const chunks: ContextChunk[] = [];

    const sources = [
      {
        pkg: "@salt-ds/core",
        label: "core",
        dts: path.join(workspaceRoot, "node_modules/@salt-ds/core/dist/index.d.ts"),
      },
      {
        pkg: "@salt-ds/lab",
        label: "lab",
        dts: path.join(workspaceRoot, "node_modules/@salt-ds/lab/dist/index.d.ts"),
      },
    ];

    for (const { pkg, label, dts } of sources) {
      if (!fs.existsSync(dts)) continue;

      try {
        const content = fs.readFileSync(dts, "utf8");

        // Extract export lines — component names + brief type signatures
        const exports = content
          .split("\n")
          .filter(
            (line) =>
              line.startsWith("export") &&
              (line.includes("declare function") ||
                line.includes("declare const") ||
                line.includes("interface") ||
                line.includes("type "))
          )
          .slice(0, 100)
          .join("\n");

        if (exports.trim()) {
          chunks.push({
            content: `Exports from ${pkg} (${label}):\n${exports}`,
            source: path.relative(workspaceRoot, dts),
          });
        }
      } catch {
        // skip
      }
    }

    return chunks;
  }

  private buildVersionLabel(workspaceRoot: string): string {
    try {
      const pkg = JSON.parse(
        fs.readFileSync(
          path.join(workspaceRoot, "node_modules/@salt-ds/core/package.json"),
          "utf8"
        )
      );
      return `Salt Design System v${pkg.version}`;
    } catch {
      return "Salt Design System";
    }
  }

  private emptyContext(label: string): KnowledgeBaseContext {
    return { chunks: [], sourceLabel: label };
  }
}
