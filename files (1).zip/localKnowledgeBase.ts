import * as fs from "fs";
import * as path from "path";
import { KnowledgeBase, KnowledgeBaseContext, CookArgs, ContextChunk } from "../router";

// ---------------------------------------------------------------------------
// Local file system knowledge base
// Usage: @cook --with local --path ./docs what is X?
//        @cook --with local --path /absolute/path/to/docs what is X?
// Reads .md, .txt, .html, .mdx files from the given directory
// ---------------------------------------------------------------------------

const SUPPORTED_EXTENSIONS = [".md", ".mdx", ".txt", ".html"];
const MAX_FILES = 50;
const MAX_CHARS_PER_FILE = 4000;
const MAX_TOTAL_CHARS = 40000;

export class LocalKnowledgeBase implements KnowledgeBase {
  readonly id = "local";
  readonly displayName = "Local Knowledge Base";

  async isAvailable(workspaceRoot: string | null): Promise<boolean> {
    // Always available — validity is checked at query time based on --path
    return true;
  }

  async getContext(
    query: string,
    args: CookArgs,
    workspaceRoot: string | null
  ): Promise<KnowledgeBaseContext> {
    const rawPath = args.path;

    if (!rawPath) {
      return {
        chunks: [
          {
            content:
              "Error: --path is required when using --with local.\n" +
              "Example: @cook --with local --path ./docs your question here",
            source: "cook-error",
          },
        ],
        sourceLabel: "Local (no path provided)",
      };
    }

    // Resolve relative paths against workspace root
    const resolvedPath =
      path.isAbsolute(rawPath)
        ? rawPath
        : path.join(workspaceRoot ?? process.cwd(), rawPath);

    if (!fs.existsSync(resolvedPath)) {
      return {
        chunks: [
          {
            content: `Error: Path not found: "${resolvedPath}"`,
            source: "cook-error",
          },
        ],
        sourceLabel: `Local (${rawPath})`,
      };
    }

    const stat = fs.statSync(resolvedPath);
    const files = stat.isDirectory()
      ? this.collectFiles(resolvedPath)
      : [resolvedPath];

    const chunks = this.loadAndRankChunks(files, query, resolvedPath);

    return {
      chunks,
      sourceLabel: `Local: ${rawPath} (${chunks.length} files)`,
      meta: { resolvedPath },
    };
  }

  // -------------------------------------------------------------------------

  /** Recursively collect all supported files under a directory */
  private collectFiles(dir: string): string[] {
    const results: string[] = [];

    const walk = (current: string) => {
      if (results.length >= MAX_FILES) return;

      let entries: fs.Dirent[];
      try {
        entries = fs.readdirSync(current, { withFileTypes: true });
      } catch {
        return;
      }

      for (const entry of entries) {
        if (entry.name.startsWith(".") || entry.name === "node_modules") {
          continue;
        }
        const fullPath = path.join(current, entry.name);
        if (entry.isDirectory()) {
          walk(fullPath);
        } else if (
          SUPPORTED_EXTENSIONS.includes(path.extname(entry.name).toLowerCase())
        ) {
          results.push(fullPath);
        }
      }
    };

    walk(dir);
    return results;
  }

  /**
   * Load each file, chunk it, and do a simple keyword-based relevance ranking
   * against the query to prioritise the most useful content.
   */
  private loadAndRankChunks(
    files: string[],
    query: string,
    baseDir: string
  ): ContextChunk[] {
    const queryTerms = query
      .toLowerCase()
      .split(/\s+/)
      .filter((t) => t.length > 2);

    const scored: Array<ContextChunk & { _score: number }> = [];
    let totalChars = 0;

    for (const filePath of files) {
      if (totalChars >= MAX_TOTAL_CHARS) break;

      let raw: string;
      try {
        raw = fs.readFileSync(filePath, "utf8");
      } catch {
        continue;
      }

      const ext = path.extname(filePath).toLowerCase();
      const cleaned =
        ext === ".html" ? this.stripHtml(raw) : raw;

      // Split into chunks by heading or paragraph (roughly 500–800 chars each)
      const fileChunks = this.chunkContent(cleaned, MAX_CHARS_PER_FILE);
      const relPath = path.relative(baseDir, filePath);

      for (const chunk of fileChunks) {
        const lower = chunk.toLowerCase();
        const score = queryTerms.reduce(
          (acc, term) => acc + (lower.split(term).length - 1),
          0
        );

        scored.push({
          content: chunk,
          source: relPath,
          score: score / Math.max(queryTerms.length, 1),
          _score: score,
        });

        totalChars += chunk.length;
        if (totalChars >= MAX_TOTAL_CHARS) break;
      }
    }

    // Sort by relevance score descending, then take top 20
    return scored
      .sort((a, b) => b._score - a._score)
      .slice(0, 20)
      .map(({ _score, ...chunk }) => chunk);
  }

  /** Split a document into manageable chunks, preferring heading boundaries */
  private chunkContent(text: string, maxChars: number): string[] {
    // Try to split on markdown headings first
    const sections = text.split(/(?=^#{1,3}\s)/m);

    const chunks: string[] = [];
    for (const section of sections) {
      if (section.length <= maxChars) {
        if (section.trim()) chunks.push(section.trim());
      } else {
        // Fall back to splitting on double newlines
        const paragraphs = section.split(/\n\n+/);
        let current = "";
        for (const para of paragraphs) {
          if ((current + para).length > maxChars) {
            if (current.trim()) chunks.push(current.trim());
            current = para;
          } else {
            current += (current ? "\n\n" : "") + para;
          }
        }
        if (current.trim()) chunks.push(current.trim());
      }
    }

    return chunks.filter((c) => c.length > 30);
  }

  /** Strip HTML tags for cleaner context */
  private stripHtml(html: string): string {
    return html
      .replace(/<script[\s\S]*?<\/script>/gi, "")
      .replace(/<style[\s\S]*?<\/style>/gi, "")
      .replace(/<[^>]+>/g, " ")
      .replace(/&nbsp;/g, " ")
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/\s{2,}/g, " ")
      .trim();
  }
}
