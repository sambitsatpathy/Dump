# Skill: execute-plan

Execute an implementation plan task-by-task with human checkpoints.

## Triggers
"execute the plan", "start implementing", "work through the tasks" — when subagents are not available. Prefer `subagent-dev` if subagents are supported.

## Process

1. **Read the plan once.** Load `docs/superpowers/plans/<plan-file>.md` and extract all tasks.

2. **Create a todo list** with every task before starting anything.

3. **For each task:**
   - Read the full task description before starting.
   - Invoke `tdd` — write the failing test first.
   - After implementation, invoke `verify`.
   - Check off the task in `plan.md`.

4. **Checkpoint every 3 tasks** (or at plan-specified points). Report:
   - Tasks completed
   - Tests passing
   - Any deviations from the plan and why

5. **If a task is blocked**, say so explicitly. Do not silently work around it.

6. **Ask for clarification rather than guessing.** Ambiguous task? Stop and ask.

## Rules

- Never work directly on `main` — use `worktree` first.
- Every implementation task requires a failing test before code.
- Deviating from the plan requires explicit approval.
- When all tasks are done → invoke `finish-branch`.
