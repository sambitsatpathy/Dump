# Skill: tdd

Implement code using strict RED → GREEN → REFACTOR. Never write implementation before a failing test.

## Triggers
"implement X", "write the code for", "add feature", "create function", any implementation task.

## The Cycle

### RED — Write a Failing Test
- Write the test for the behaviour you want.
- Run it. Watch it fail. If it passes immediately, the test is wrong — fix it.
- A test that passes before implementation proves nothing.

### GREEN — Write Minimal Code
- Write the minimum code to make the test pass. No more.
- No extra features. No "while I'm here" additions.
- Run tests. All must pass.

### REFACTOR — Clean Up
- With tests green, clean the code.
- Remove duplication. Improve names. Extract functions.
- Run tests again. Still green? Commit.

## Rules (Non-Negotiable)

- **Tests first. Always.** No exceptions for "simple" code.
- **Watch the test fail.** Skipping this means you don't know if the test works.
- **Delete code written before tests.** It's technical debt. Rewrite with TDD.
- **One failing test at a time.** Write one, implement, write next.
- **Tests-after is not TDD.** Tests-after verify what you built. Tests-first define what to build.

## Anti-Patterns → All Mean: Delete Code, Start Over With TDD

- "I'll add tests after" → No.
- "It's too simple to need tests" → No.
- "I already wrote the code" → Delete it.
- "Tests immediately passed" → Test is wrong. Fix it.
- "Manual testing is fine" → No record, can't re-run.

## Example

```js
// RED: write failing test
test('rejects empty email', async () => {
  const result = await submitForm({ email: '' });
  expect(result.error).toBe('Email required');
});
// Run → FAILS ✓

// GREEN: minimal implementation
function submitForm(data) {
  if (!data.email?.trim()) return { error: 'Email required' };
}
// Run → PASSES ✓

// REFACTOR if needed, run again → PASSES ✓ → Commit
```

## Checklist Before Committing

- [ ] Test written before implementation?
- [ ] Test was watched to fail?
- [ ] Minimal code written to pass?
- [ ] All tests pass?
- [ ] Code refactored with tests still green?

Can't check all boxes? You skipped TDD. Go back.
