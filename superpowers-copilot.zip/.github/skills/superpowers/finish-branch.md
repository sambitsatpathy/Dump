# Skill: finish-branch

Complete a development branch — verify, then merge, PR, keep, or discard.

## Triggers
All plan tasks are complete, "I'm done", "ready to merge", "wrap this up".

## Process

### 1. Final Verification
```bash
npm test        # full suite must pass
git status      # no uncommitted changes
git log --oneline origin/main..HEAD   # review what you're about to ship
```

If tests fail → stop. Invoke `investigate` before proceeding.

### 2. Final Code Review
Invoke `review` on the full diff (not just the last task). This is the last gate before shipping.

### 3. Choose an Option

Present the user with these options:

**a) Merge to main**
```bash
git checkout main
git merge feature/<n> --no-ff -m "feat: <description>"
git worktree remove ../feature-<n>
git branch -d feature/<n>
```

**b) Open a Pull Request**
```bash
git push origin feature/<n>
gh pr create --title "<title>" --body "<description>"
git worktree remove ../feature-<n>
# keep branch until PR is merged
```

**c) Keep branch (not ready)**
```bash
git worktree remove ../feature-<n>
# branch stays for later
```

**d) Discard (abandon)**
```bash
git worktree remove ../feature-<n>
git branch -D feature/<n>
```

## Rules

- Never merge with failing tests.
- Never merge without a final code review pass.
- Always clean up the worktree when done (whether merging, PRing, or discarding).
- The user chooses the option — do not assume merge.
