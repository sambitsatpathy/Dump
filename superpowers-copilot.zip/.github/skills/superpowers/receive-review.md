# Skill: receive-review

Process and respond to code review feedback systematically.

## Triggers
"here's the review", "feedback on my code", "reviewer said", after `review` outputs issues.

## Process

1. **Categorise every issue:**
   - `crit` — Fix immediately. Non-negotiable.
   - `warn` — Fix unless you have a specific, articulable reason not to.
   - `nit` — Fix if trivial; defer with explanation if not worth it now.

2. **For each issue, decide and document:**
   - **Fix** — explain what changed and why.
   - **Defer** — explain why it's not worth fixing now and when it will be.
   - **Disagree** — make the case. The reviewer may be wrong.

3. **Apply fixes in order:** crits first, then warns, then nits.

4. **Run the full test suite after each fix.** Do not batch all fixes and test once.

5. **Commit after each logical group** with a clear message.

6. **Respond to reviewer issue-by-issue:**

```
L14 (crit) — Fixed: switched to parameterized query in auth.ts:47
L22 (warn) — Fixed: moved fetchData() outside loop, added batch method
L45 (nit)  — Fixed: renamed `d` to `durationMs`
```

## Rules

- Do not mark tasks complete until all crits and warns are resolved (or explicitly deferred with approval).
- Disagreements are fine — make the case clearly and let the human decide.
- After all fixes → invoke `verify`.
