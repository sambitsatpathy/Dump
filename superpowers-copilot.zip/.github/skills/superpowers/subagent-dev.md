# Skill: subagent-dev

Execute a plan using fresh subagents per task with two-stage review after each.

## Triggers
After `write-plan` completes, when subagents are available. Preferred over `execute-plan`.

## Core Principle

Fresh subagent per task + two-stage review (spec compliance → code quality) = high quality, fast iteration. Each subagent receives only the context it needs — never the parent session's history.

## Decision Tree

```
Have a plan?
  → Tasks mostly independent?
      → Yes → subagent-dev ✓
      → No (tightly coupled) → execute-plan
  → No plan → brainstorm → write-plan first
```

## Per-Task Loop

For each task in the plan:

1. **Dispatch implementer subagent** with:
   - Full task description and required context only
   - Instruction to use `tdd` (failing test before code)
   - Specific files to create/modify

2. **Dispatch spec compliance reviewer** — does the implementation match the spec exactly? Nothing extra, nothing missing?

3. **Dispatch code quality reviewer** — clean code, good tests, no anti-patterns?

4. **If issues found** → dispatch implementer to fix, re-review.

5. **Mark task complete** — check off in `plan.md`.

After all tasks → dispatch final code quality reviewer for the full implementation → invoke `finish-branch`.

## Model Selection

- Mechanical tasks (isolated functions, clear specs, 1–2 files): use a fast/cheap model
- Integration tasks (multi-file coordination, judgment calls): use a standard model
- Reviewers: fast model is usually sufficient

## Rules

- Never start without a written plan.
- Never skip the two-stage review.
- Subagents never inherit the parent session's context.
- Always use `worktree` before starting.
