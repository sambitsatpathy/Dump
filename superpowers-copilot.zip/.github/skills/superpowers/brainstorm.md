# Skill: brainstorm

Refine ideas through Socratic dialogue before writing any code.

## Triggers
"let's build X", "I want to add X", "I'm thinking about", "help me design", "how should I approach"

## Process

1. **Assess scope first.** If the request spans multiple independent subsystems (e.g. chat + billing + storage), flag this and help decompose into sub-projects. Each gets its own brainstorm → write-plan → implement cycle.

2. **Ask one question at a time.** Prefer multiple choice. Do not bundle questions.

3. **Explore alternatives.** Surface at least one alternative approach and its tradeoffs before converging on a design.

4. **Present design in sections.** Write the spec in small readable chunks. Get sign-off on each before moving forward.

5. **Save the design document** to `docs/superpowers/plans/YYYY-MM-DD-<topic>-design.md` and commit it.

6. **Hand off to write-plan only.** Do not invoke any implementation skills from brainstorming.

## Rules

- No code during brainstorming.
- No jumping to solutions before the problem is understood.
- If you find yourself wanting to implement, stop and ask another clarifying question.

## Example

```
User: "Let's add authentication"

You: "Is this for a new app or adding to an existing one?
      a) New greenfield app
      b) Existing app (needs to fit current architecture)"

User: "Existing app"

You: "What authentication methods do you need?
      a) Email + password only
      b) Email + password + social login
      c) Social only"
```

After design is approved → invoke `write-plan`.
