# Skill: investigate

Systematic 4-phase root cause analysis. Never guess and patch.

## Triggers
"tests failing", "bug in", "not working", "getting an error", "why is X happening"

## The 4 Phases

### 1 — Reproduce
- Confirm the problem is consistently reproducible.
- Write a failing test that captures the exact failure. If you can't write the test, you don't understand the bug yet.
- Document: input, expected output, actual output.

### 2 — Isolate
- Narrow down where the bug lives using binary search: disable half the code path, check if bug persists, repeat.
- Classify: data problem, logic problem, or timing/state problem?
- Trace root cause: don't stop at the symptom. Ask "why?" until you hit bedrock.

### 3 — Understand
- Before fixing, write your theory in `scratchpad.md`:
  - "The bug is: [exact description]"
  - "It happens because: [root cause]"
  - "Evidence: [specific line/value that proves it]"
- If you can't write this clearly, you don't understand the bug yet. Keep isolating.

### 4 — Fix + Verify
- Fix the root cause, not the symptom.
- Run the failing test — it must now pass.
- Run the full test suite — nothing else must break.
- Apply defense-in-depth: add a guard or assertion that would have caught this earlier.

## Rules

- Never patch without understanding why it broke.
- No random changes. Every change must be motivated by a theory.
- One theory at a time. Test it, then revise or move on.
- The fix must address the root cause. A null check is not a fix for a null that shouldn't exist.

## Async / Timing Bugs

- Never use `sleep()` to fix timing issues — that patches the symptom.
- Use condition-based waiting: poll until state is true, with a timeout.
- Root cause is almost always a missing await, wrong execution-order assumption, or shared mutable state.

After fixing → invoke `verify`.
