# Skill: worktree

Create an isolated git workspace before any implementation begins.

## Triggers
After `write-plan` completes, before starting any implementation. "create a branch", "start implementing".

## Process

```bash
# Create worktree on a new branch
git worktree add ../feature-<name> -b feature/<name>
cd ../feature-<name>

# Run setup and verify clean baseline
npm install        # or pip install, bundle install, etc.
npm test           # ALL tests must pass before you start
```

If tests fail before you start, fix them first. Never build on a broken foundation.

## With Explicit User Consent: Working on Main

If the user explicitly says "work on main" or "skip the worktree", you may proceed — but state the implications clearly:
- Changes go directly on main
- Harder to abandon if the approach is wrong
- Risk of affecting others' work

## Cleanup

When work is complete, invoke `finish-branch` — it handles worktree cleanup.

Manual cleanup:
```bash
cd ../original-workspace
git worktree remove ../feature-<name>
git branch -d feature/<name>   # after merging
```

## Rules

- Always verify a clean test baseline before starting.
- Never start implementation without a worktree (unless user explicitly consents).
- Name the worktree to match the feature or ticket for clarity.
