# Skill: verify

Confirm a fix or implementation actually works before declaring done.

## Triggers
"done", "fixed", "implemented", "should work now", before any commit or task sign-off.

## Checklist

Before saying anything is complete, every item must be checked:

- [ ] The specific failing test now passes (run it explicitly — don't assume)
- [ ] The full test suite passes with no regressions
- [ ] The fix addresses the root cause, not just the symptom
- [ ] Edge cases are covered (empty input, null, large values, concurrent calls)
- [ ] No new compiler or linter warnings introduced
- [ ] The change is committed with a clear message explaining what and why

## Rules

- "Tests pass" means you ran them and watched them pass — not "they should pass."
- If any checklist item cannot be confirmed, the task is NOT done.
- Do not mark a task complete in `plan.md` until all items are checked.

## Output Format

```
Verification complete:
✅ Failing test now passes: test('rejects empty email')
✅ Full suite: 47 tests passing, 0 failing
✅ Root cause fixed: removed incorrect null guard in submitForm()
✅ Edge case covered: whitespace-only email now rejected
✅ Committed: fix(auth): reject empty and whitespace-only emails
```

If anything fails → go back and fix it. Do not say it's done.
