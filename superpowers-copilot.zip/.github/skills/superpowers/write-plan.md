# Skill: write-plan

Break an approved design into a detailed, task-by-task implementation plan.

## Triggers
"create a plan", "write the plan", "plan this out", after `brainstorm` completes.

## Process

1. **Map files first.** Before defining tasks, list every file to be created or modified and its single responsibility. Lock in decomposition decisions here.

2. **Break into 2–5 minute tasks.** If a task feels large, split it. Every task must be independently verifiable.

3. **Each task must specify:**
   - Exact file paths (no vague references)
   - The test to write first (RED phase)
   - The implementation required to pass it (GREEN phase)
   - Verification step (how to confirm it worked)

4. **Save the plan** to `docs/superpowers/plans/YYYY-MM-DD-<feature-name>.md` using checkbox syntax (`- [ ]`).

5. **For large features** covering multiple independent subsystems, split into separate plans — one per subsystem.

## Plan Format

```markdown
# [Feature Name] Implementation Plan

## Files Involved
- `src/auth/middleware.ts` — JWT validation
- `src/auth/routes.ts` — Login/logout endpoints
- `tests/auth.test.ts` — Auth test suite

## Tasks

- [ ] **Task 1: Failing auth middleware tests**
  - Write tests for: valid token, expired token, missing token
  - File: `tests/auth.test.ts`
  - Verify: `npm test` shows 3 failing tests

- [ ] **Task 2: Implement JWT middleware**
  - File: `src/auth/middleware.ts`
  - Implement `validateToken(req, res, next)`
  - Verify: all 3 tests pass
```

## Rules

- Tasks must list the test before the implementation.
- No vague tasks. Every task must be followable with zero project context.
- After plan is written → invoke `worktree` then `subagent-dev` (or `execute-plan`).
