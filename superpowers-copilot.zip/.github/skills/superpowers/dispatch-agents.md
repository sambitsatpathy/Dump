# Skill: dispatch-agents

Run multiple subagents concurrently for independent tasks.

## Triggers
"these tasks can run in parallel", "do these simultaneously", tasks in a plan with no dependencies on each other.

## When to Use

Use when:
- Two or more plan tasks are fully independent (different files, no shared state)
- Speed matters more than sequential review
- Tasks can each be verified independently

Do NOT use when:
- Tasks share files or state
- Task B depends on the output of Task A
- You're unsure — default to `subagent-dev` (sequential) instead

## Process

1. **Identify independent task groups** from the plan. Map dependencies explicitly.

2. **For each parallel group:**
   - Dispatch one subagent per task simultaneously
   - Each subagent gets only its task's context — no cross-task context
   - Each subagent uses `tdd` independently

3. **Wait for all subagents in the group to complete.**

4. **Review each result independently:**
   - Spec compliance review per task
   - Code quality review per task
   - Integration review across the group (do the pieces fit together?)

5. **Fix issues**, re-review if needed, mark tasks complete.

6. **Move to the next independent group** or finish with `finish-branch`.

## Rules

- Parallel only for truly independent tasks. When in doubt, go sequential.
- Each subagent is isolated — no shared context between parallel workers.
- Integration review is mandatory after each parallel group merges.
