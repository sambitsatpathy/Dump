# Skill: write-skill

Create a new Superpowers skill using TDD principles applied to process documentation.

## Triggers
"create a new skill", "I want to teach the agent to", "add a skill for".

## Core Principle

Writing skills IS TDD applied to documentation:
- Write test cases (pressure scenarios with subagents)
- Watch them fail (baseline behaviour without the skill)
- Write the skill (the documentation)
- Watch tests pass (agents comply)
- Refactor (close loopholes)

If you didn't watch an agent fail without the skill, you don't know if the skill teaches the right thing.

## Process

### 1. Define the Problem
- What behaviour does the agent do by default that you don't want?
- What should it do instead?
- Write one concrete example of the wrong behaviour and one of the right behaviour.

### 2. Write a Pressure Scenario (The Test)
- Run a subagent WITHOUT the skill on a scenario where the wrong behaviour would occur.
- Document exactly what it does. This is your failing test.

### 3. Write the Skill
Place the skill in `.github/skills/superpowers/<skill-name>.md`.

Required structure:
```markdown
# Skill: <name>

One-line description.

## Triggers
Exact phrases or contexts that should invoke this skill.

## Process
Step-by-step instructions.

## Rules
Non-negotiable constraints. Address known rationalisations explicitly.

## Example
Concrete before/after or do/don't example.
```

Skill writing rules:
- Triggers describe conditions, not workflow ("use when implementing features" not "write test, watch it fail, write code")
- Address real rationalisations you observed in the pressure test — don't invent hypothetical ones
- Keep it concise. Agents read the whole skill. Longer is not more effective.

### 4. Test the Skill
- Run the same pressure scenario WITH the skill active.
- Agent complies? ✓
- Agent found a new rationalisation? Add an explicit counter. Re-test.

### 5. Add to Instructions
Add the skill name and description to `.github/instructions/superpowers.instructions.md` skill table.

## Rules

- Never deploy an untested skill.
- Personal/project-specific skills stay in `.github/skills/` — don't try to contribute them upstream without evidence they help all users.
