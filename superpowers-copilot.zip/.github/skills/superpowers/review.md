# Skill: review

Systematic code review against the plan — catch issues before they cascade.

## Triggers
"review this", "check my code", "is this good", after completing an implementation task, before marking done.

## Two-Stage Review

### Stage 1: Spec Compliance
- Does the implementation match the plan exactly?
- Is anything in the plan missing from the implementation?
- Is anything in the implementation NOT in the plan (scope creep)?

### Stage 2: Code Quality
- [ ] Tests written before implementation (TDD)?
- [ ] All tests passing?
- [ ] No magic numbers, god functions, or deep nesting?
- [ ] Error cases handled?
- [ ] Names clear and consistent with codebase conventions?
- [ ] No dead code?
- [ ] No secrets or credentials in code?
- [ ] Input validation where needed?

## Output Format

One line per issue:

```
L<line>: <severity> <problem>. <fix>.
```

Severity: `crit` (must fix before proceeding), `warn` (should fix), `nit` (optional)

Example:
```
L14: crit user input passed to query unsanitized → SQL injection. Use parameterized query.
L22: warn fetchData() called inside loop → N+1 queries. Move outside, batch fetch.
L45: nit variable `d` → rename to `durationMs`.

3 issue(s): 1 crit, 1 warn, 1 nit
Assessment: Fix crit before proceeding.
```

## Rules

- Review happens between tasks, not only at the end.
- `crit` issues block progress — fix before moving to next task.
- After fixes → invoke `verify` before marking the task complete.
