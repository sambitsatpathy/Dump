# Skill: superpowers

Overview of the Superpowers framework — how it works and when to use each skill.

## What is Superpowers?

A complete software development methodology for coding agents. A set of composable skills that enforce best practices so the agent doesn't cut corners, skip tests, or guess at bugs.

## The Core Workflow (in order)

```
brainstorm → write-plan → worktree → subagent-dev → finish-branch
```

Every step is gated: you cannot move forward without completing the previous step correctly.

## Full Skill Map

### Planning
| Skill | When |
|-------|------|
| `brainstorm` | Before writing any code — refine the idea first |
| `write-plan` | After design is approved — make the task list |

### Execution
| Skill | When |
|-------|------|
| `worktree` | Before implementation — isolated git workspace |
| `subagent-dev` | Execute plan with fresh subagents + two-stage review |
| `execute-plan` | Execute plan without subagents (fallback) |
| `dispatch-agents` | Run independent tasks in parallel |

### Quality
| Skill | When |
|-------|------|
| `tdd` | Every implementation task — test first, always |
| `verify` | Before declaring anything done |
| `review` | Between tasks and before merging |
| `receive-review` | When processing review feedback |

### Debugging
| Skill | When |
|-------|------|
| `investigate` | When something is broken — 4-phase root cause analysis |

### Finishing
| Skill | When |
|-------|------|
| `finish-branch` | When all tasks are complete — merge/PR/keep/discard |

### Meta
| Skill | When |
|-------|------|
| `write-skill` | To create a new skill for the system |

## The Iron Laws

1. No implementation without a failing test first.
2. No declaring done without running `verify`.
3. No working on `main` without explicit user consent.
4. No guessing at bugs — always find the root cause.
5. If there is a 1% chance a skill applies, invoke it.

## Original Project

Based on [Superpowers by Jesse Vincent](https://github.com/obra/superpowers). MIT License.
