# Spec Visualizer & Workflow Editor — Project Plan (Merged)

> **Document history:** v1 established the foundation; v2 addressed ten structural gaps. This file is the single authoritative plan incorporating all v2 changes. Where v2 supersedes v1, the v2 version is canonical. Where v1 content was unchanged, it is preserved verbatim.

---

## Overview

A visual spec management system that reads application specs, renders them as an interactive node-based graph (n8n-style), and allows users to create and edit workflows. Edited workflows are exported as structured specs intended to be consumed by AI agents for implementation.

**Out of scope:** AI agents that build code from specs.

**Premise to validate before investing in the full build:** that a structured JSON spec produced by this tool measurably improves downstream AI agent output versus a well-written markdown equivalent. If it doesn't, the tool's value proposition collapses and the build should be reconsidered. Phase 0 exists to answer this question.

---

## Tech Stack

| Concern | Choice |
|---|---|
| Framework | React + Vite + TypeScript |
| Graph / Canvas | React Flow |
| Layout Algorithm | Dagre |
| Spec Format | JSON (canonical); YAML export as optional stretch |
| Design System | Salt DS (dark, high density) |
| Storage (initial) | Local filesystem / file upload; backend-agnostic |

---

## Spec File Architecture

### Nested File Structure

```
/specs
  app.spec.json                      ← root manifest
  /workflows
    submit-order.workflow.json
    load-positions.workflow.json
  /nodes
    order-form.node.json             ← contains ALL versions of this node
    validate-order.node.json
    positions-grid.node.json
  /edges
    submit-order.edges.json
    load-positions.edges.json
  /comments
    submit-order.comments.json       ← comments keyed to workflow + version
    order-form.comments.json         ← comments keyed to node + version
  /schemas
    ui.schema.json                   ← optional category property schemas
    infra.schema.json
```

### Root Manifest (`app.spec.json`)

```json
{
  "app": "MyApp",
  "specVersion": "1.0.0",
  "description": "...",
  "createdAt": "2026-04-23",
  "updatedAt": "2026-04-23",
  "workflows": [
    { "ref": "workflows/submit-order", "version": "1.2.0" },
    { "ref": "workflows/load-positions", "version": "1.0.1" }
  ],
  "nodes": [
    { "ref": "nodes/positions-grid", "version": "1.3.1" },
    { "ref": "nodes/order-form", "version": "2.0.0" }
  ]
}
```

Manifest refs always pin to a specific version. Workflows pin to specific node versions — changing a node does not break an approved workflow.

---

## Node Schema

Only `id` and `category` are immutable across versions. Within a version, only `label` is required; everything else is optional and freeform — **but** if the category has a registered schema, `properties` are validated against it on save.

**All versions of a node live in a single file, in a `versions` array.**

```json
{
  "id": "order-form",
  "category": "ui",
  "createdAt": "2026-04-01T10:00:00Z",
  "versions": [
    {
      "version": "1.0.0",
      "label": "Order Form",
      "description": "Initial version",
      "properties": { "fields": ["symbol", "quantity"] },
      "tags": ["ui", "form"],
      "lifecycle": {
        "status": "approved",
        "submittedBy": "alice",
        "submittedAt": "2026-04-05T10:00:00Z",
        "reviewedBy": "bob",
        "reviewedAt": "2026-04-06T09:00:00Z"
      }
    },
    {
      "version": "1.1.0",
      "label": "Order Form",
      "description": "Added quantity validation",
      "properties": { "fields": ["symbol", "quantity"], "validate": true },
      "tags": ["ui", "form", "validated"],
      "lifecycle": { "status": "draft", "submittedBy": "alice" }
    }
  ]
}
```

**Suggested categories (non-exhaustive, user-extensible):**

- `ui` — anything the user interacts with
- `logic` — processing, transformation, validation, branching
- `infra` — queues, functions, schedulers, cloud services
- `data` — databases, caches, views, queries
- `external` — third-party APIs, services outside the system

### Category Schemas

Each category may register an optional JSON Schema that its nodes' `properties` must conform to. Schemas live in `/specs/schemas/{category}.schema.json`.

**Example: `schemas/ui.schema.json`**

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "type": "object",
  "properties": {
    "trigger": { "enum": ["click", "submit", "hover", "focus"] },
    "form": { "type": "string" }
  },
  "additionalProperties": true
}
```

- `additionalProperties: true` preserves the freeform principle — extra keys are always allowed.
- Registered keys are validated on save and catch naming inconsistencies (e.g. `click` vs `onClick`).
- Validation runs on save inside the editor; invalid specs cannot be submitted.
- Categories without a schema behave fully freeform, exactly as in the original design.

---

## Edge Schema

Edges are node-version-aware. An edge between `order-form@1.1.0` and `validate-order@1.0.0` is different from one between `order-form@1.0.0` and `validate-order@1.0.0`. In practice, edges live on workflows and inherit the workflow's pinned versions. Only `source` and `target` are required.

```json
{
  "id": "edge-001",
  "source": "order-form",
  "target": "validate-order",
  "label": "on submit",
  "description": "Triggers order validation when the user submits the form",
  "properties": { "async": true, "condition": "form.isValid" }
}
```

---

## Workflow Schema

A workflow is a named, versioned grouping of pinned node refs and edge refs. All versions live in a single file in a `versions` array, mirroring the node schema.

```json
{
  "id": "submit-order",
  "versions": [
    {
      "version": "1.2.0",
      "label": "Submit Trade Order",
      "description": "End-to-end flow from order form submission to DB persistence",
      "nodeRefs": [
        { "id": "order-form", "version": "1.1.0" },
        { "id": "validate-order", "version": "1.0.0" },
        { "id": "persist-order", "version": "1.3.1" }
      ],
      "edges": ["edge-001", "edge-002"],
      "lifecycle": { "status": "submitted", "submittedBy": "alice" }
    }
  ]
}
```

Node refs are always pinned. The workflow is self-contained at any given version.

---

## Versioning — Fully Specified Mechanics

### One file per logical entity. All versions stored in a `versions` array.

### Explicit rules

| Question | Answer |
|---|---|
| What is a new version? | A new entry in the `versions` array. Not a new file. |
| How many DRAFT versions per node? | Exactly one. A maker cannot start a second DRAFT while one is in flight. |
| Once APPROVED, can a version be edited? | No. Approved versions are immutable. Further changes create a new DRAFT version. |
| What does the canvas show by default? | The latest APPROVED version of each node. |
| What does the canvas show when editing a workflow? | The version the workflow pins to. Pinning is per-workflow, per-node. |
| What happens to a workflow when a referenced node gets a new version? | Nothing automatic. The workflow continues pinning to its original version. A UI indicator appears: "newer version available (v1.2.0)." The maker must explicitly re-pin via an upgrade action that creates a new workflow version. |
| Can two workflows pin to different versions of the same node? | Yes. This is expected. |
| What is a workflow version? | A snapshot of the workflow's pinned refs. Editing a workflow creates a new workflow version in DRAFT. |

### Version bump semantics

| Bump | When |
|---|---|
| **Patch** | Label change, description update, cosmetic config |
| **Minor** | New property added (additive), new connection (additive) |
| **Major** | Property removed, property type changed, node restructured or breaking change |

---

## Maker-Checker Lifecycle

Every spec file (node, edge, workflow, manifest) travels through a defined lifecycle tracked per file.

### Status flow

```
DRAFT → SUBMITTED → IN REVIEW → APPROVED
                             ↘ CHANGES REQUESTED → DRAFT (with comments)
                   ↘ REJECTED → DRAFT (with comments)
```

### Rules

- `DRAFT` — editable by the maker; visible on canvas in edit mode.
- `SUBMITTED` — locked; no edits allowed; awaiting review.
- `IN REVIEW` — checker has picked it up; still locked.
- `APPROVED` — can be referenced by other specs; immutable. New changes create a new DRAFT version.
- `CHANGES REQUESTED / REJECTED` — returns to `DRAFT`; reviewer comments persist and are flagged "from previous review" until resolved.
- A workflow version **cannot be submitted** if any of its pinned node versions are still in DRAFT.
- A workflow version **cannot be approved** unless all pinned node versions are APPROVED.

---

## Roles & Permissions

Four roles, scope-aware in the data model from Phase 1. The Phase 4 UI exposes global roles only; scoped role UI ships in Phase 6 without requiring a data migration.

| Role | Permissions |
|---|---|
| `maker` | Create, edit, submit (within scope) |
| `checker` | Review, approve, reject, comment (within scope) |
| `viewer` | Read-only (within scope) |
| `admin` | Override, reassign, force-approve (global) |

### Scope

Each role assignment carries an optional scope:

```json
{ "user": "alice", "role": "checker", "scope": { "category": "infra" } }
```

Supported scope types:

- `{ "category": "infra" }` — role applies only to nodes of that category
- `{ "workflow": "submit-order" }` — role applies only to this workflow and its referenced nodes
- `{}` or omitted — global scope

---

## Comments Model

Comments are a first-class subsystem. They live in separate files so commenting never triggers spec version bumps.

### File location

`/specs/comments/{spec-id}.comments.json`

### Schema

```json
{
  "specId": "order-form",
  "specType": "node",
  "comments": [
    {
      "id": "c-001",
      "targetVersion": "1.1.0",
      "targetElement": { "type": "property", "path": "properties.validate" },
      "author": "bob",
      "createdAt": "2026-04-22T14:00:00Z",
      "resolvedAt": null,
      "body": "Should this be a boolean or a validator function?",
      "replies": [
        {
          "id": "c-001-r1",
          "author": "alice",
          "createdAt": "2026-04-22T15:00:00Z",
          "body": "Boolean for now. Can extend later."
        }
      ],
      "reviewCycle": "submit-cycle-3"
    }
  ]
}
```

### Rules

- Every comment is anchored to a **specific version** of a spec, not to a canvas position.
- A comment can target the whole spec, a specific property path, or an edge. `targetElement` is optional.
- Comments on deleted elements become "orphaned" — readable but not repliable; visible in a dedicated panel.
- When a version returns to DRAFT after CHANGES REQUESTED, its comments persist and are flagged "from previous review." The maker can resolve them; the next checker sees them as context.
- Canvas rendering: a small comment count indicator appears on nodes with unresolved comments at the current rendered version.

---

## Notifications

A governance tool without notifications requires Slack or email to function in practice.

### In scope for Phase 4

- **In-app notification center.** Bell icon in the app shell with an unread count badge.
- **Event triggers:** spec submitted (notifies relevant checkers), changes requested or rejected (notifies submitter), approved (notifies submitter), comment added (notifies the spec owner and thread participants).
- **Optional outbound webhook.** A single configurable URL receives a POST for each event — Slack / email / Teams integration stays a user concern.

### Out of scope for Phase 4

- Per-user email delivery
- Digest emails
- Configurable subscription preferences beyond mute/unmute

---

## Export

| Export type | Description |
|---|---|
| **Full** | Entire spec tree, all files, all versions, all statuses |
| **Approved-only** | Only files stripped to their APPROVED versions |
| **Delta** | ⚠️ Stretch goal only — revisit after real AI agent workflows validate the use case |

**Scope options:** single node | single workflow | full app.

**Format:** JSON (canonical). YAML as optional stretch.

Delta export structure (for reference, when built):

```json
{
  "deltaFrom": "1.2.0",
  "deltaTo": "1.4.0",
  "added": [...],
  "modified": [{ "id": "...", "before": {...}, "after": {...} }],
  "removed": [...]
}
```

---

## Application Modules

### 1. Spec Parser / Importer

- Accept a folder, zip, or single manifest
- Validate manifest references resolve
- Validate every node/workflow version against the manifest's pinning
- Validate properties against category schemas where registered
- Normalize into internal graph state
- Auto-layout with Dagre
- Surface broken references, schema violations, and orphaned comments as warnings

### 2. Canvas (Graph Editor)

- React Flow canvas
- Left palette sidebar, drag-to-add — dragging creates a ref pinned to the latest APPROVED version
- Right property panel (Slide-in Drawer)
- **Swim lanes** — toggleable, grouped by category (UI | Logic | Infra | Data | External) — Phase 2
- **Canvas search and filters** — search by label, filter by tag, status, category, version — Phase 2
- Minimap
- Zoom levels: workflow view / flow view / node detail
- Color coding by lifecycle status
- "Newer version available" indicators on nodes whose pinned version is behind the latest APPROVED
- Comment count indicators on nodes with unresolved comments

### 3. Workflow Authoring

- Create a new workflow (named, described)
- Drag nodes from palette — auto-pins to latest APPROVED version
- Draw edges between node ports
- Configure node and edge properties (new DRAFT version created on first edit of an APPROVED spec)
- Save as DRAFT
- **Upgrade node version:** explicit action that re-pins a workflow to a newer node version and creates a new workflow DRAFT

### 4. Maker-Checker UI

- Submission queue — filterable by type, status, submitter, and category scope
- Review panel — side-by-side diff of the version under review vs the previous APPROVED version
- Blocking dependency panel — lists all node refs and their lifecycle status; Approve disabled if any are not APPROVED
- Approve / Reject / Request Changes actions (confirmation dialog; reason required for non-approvals)
- Comment threads, version-anchored, with "from previous review" flags
- Lifecycle status badge on every canvas node

### 5. Notifications

- In-app bell with unread count
- Notification center panel (list view, mark as read, jump to spec)
- Outbound webhook configuration in admin settings

### 6. Spec Exporter

- Full export (zip of spec tree, all versions)
- Approved-only export (stripped tree)
- Scope selector (node / workflow / app)
- Export format: JSON
- Delta export: stretch goal only

---

## Phase Plan

### Phase 0 — Validation *(GATE — gates everything else)*

- [ ] Draft schemas on paper
- [ ] Hand-author one example spec (one workflow, four to six nodes)
- [ ] Hand-author semantically equivalent markdown for the same workflow
- [ ] Run both through the target AI coding agent with the same build prompt
- [ ] Write up findings: does structured JSON help, hurt, or produce no detectable difference?
- [ ] **Decision gate:** proceed / reframe / stop

**Exit criteria:** Spec-driven output is measurably better than markdown-driven output on at least one dimension (completeness, fewer hallucinations, better file structure, correct framework choice).

**Time budget:** 3–5 days. This is a real gate, not a checkbox.

---

### Phase 1 — Foundation + Thin End-to-End Slice

- [ ] Project scaffold (Vite + React + TypeScript + Salt DS)
- [ ] Final schemas for node, edge, workflow, manifest, comments
- [ ] Category schema registry (loader only; enforcement in Phase 2)
- [ ] Spec parser: load manifest, resolve refs, validate structure
- [ ] Static canvas render
- [ ] **Thin slice:** one hardcoded workflow, three nodes, togglable lifecycle states, working JSON export
- [ ] App shell with navigation (scope-aware role data model in place from day one)

**Exit criteria:** can load a spec, see it on the canvas, toggle lifecycle states, export the JSON. End to end. No authoring yet.

---

### Phase 2 — Canvas & Authoring

- [ ] Node palette sidebar with drag-to-add
- [ ] Edge drawing between nodes
- [ ] Property editor panel with **category schema validation on save**
- [ ] Freeform property editor for unschematized categories
- [ ] **Swim lanes toggle** (promoted from polish)
- [ ] **Canvas search and filters** (label, tag, status, category)
- [ ] Save canvas state back to spec file structure
- [ ] Auto-create new DRAFT version on first edit of an APPROVED spec

---

### Phase 3 — Versioning

- [ ] Version creation on edit (new DRAFT entry in `versions` array)
- [ ] Version pinning UI on workflow node refs
- [ ] "Newer version available" indicators on canvas
- [ ] **Workflow upgrade action** (re-pin to newer node version, creates new workflow DRAFT)
- [ ] Version history viewer (timeline per spec, filterable)
- [ ] Changelog auto-population on save

---

### Phase 4 — Maker-Checker + Comments + Notifications

- [ ] Lifecycle state transitions with validation rules
- [ ] Role system (scope-aware data model; global UI only at this phase)
- [ ] Submission queue
- [ ] Review panel with version diff
- [ ] Blocking dependency panel
- [ ] Comments model and threads (version-anchored, "from previous review" flags)
- [ ] In-app notification center
- [ ] Outbound webhook configuration
- [ ] Blocking dependency indicators on canvas

---

### Phase 5 — Export

- [ ] Full export (zip of spec tree, all versions)
- [ ] Approved-only export (stripped tree, APPROVED versions only)
- [ ] Scope selector (node / workflow / app)
- [ ] JSON export canonical
- [ ] **Delta export: stretch goal only** — build only if Phase 0 validation showed AI agents benefit from deltas

---

### Phase 6 — Polish & Enterprise

- [ ] Scoped roles UI (exposing the data model from Phase 1)
- [ ] Zoom levels (workflow view ↔ flow view)
- [ ] Rejected node inline annotations
- [ ] Import validation warnings UI (schema violations, orphaned comments)
- [ ] Minimap polish
- [ ] Optional YAML export
- [ ] Orphaned comments panel
- [ ] Swim lane refinements (cross-lane edge styling, drag-to-reassign category)

---

## Key Design Principles

1. **Validate the thesis before building the product.** Phase 0 is not optional.
2. **Freeform by default, schema where it matters.** Categories can declare schemas; properties outside declared keys remain freeform.
3. **Versioning mechanics are explicit.** One file per logical node, versions as array, immutable once approved, pinned by workflows.
4. **Governance is in the data model.** Scoped roles, version-anchored comments, notifications — all designed from day one to avoid later migrations.
5. **Ship end-to-end slices, not vertical layers.** Every phase produces something a user can exercise end to end.
6. **Loosely coupled specs.** Nodes carry no architectural assumptions; properties are freeform.
7. **AI-agent ready.** The spec format is the contract between this tool and the downstream build agents.
8. **Delta export is earned, not assumed.** Build it only when an AI agent that consumes deltas exists.
