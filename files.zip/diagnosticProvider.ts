import * as vscode from "vscode";
import { findTokensForValue, SaltToken } from "./saltResolver";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const DIAGNOSTIC_SOURCE = "salt-copilot";
const DIAGNOSTIC_CODE = "hardcoded-value";

// Languages to scan for hardcoded values
const SUPPORTED_LANGUAGES = [
  "css",
  "scss",
  "less",
  "typescriptreact",
  "javascriptreact",
  "typescript",
  "javascript",
];

// Patterns that could match hardcoded values Salt tokens already cover
const DETECTION_PATTERNS: Array<{
  regex: RegExp;
  label: string;
}> = [
  // Hex colours — 3, 4, 6, or 8 digit
  { regex: /#([0-9A-Fa-f]{8}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{3,4})\b/g, label: "hex color" },
  // rgb / rgba / hsl / hsla
  { regex: /(rgba?|hsla?)\([^)]+\)/g, label: "color function" },
  // px spacing / size values (only common Salt scale values to reduce noise)
  {
    regex: /\b(2|4|6|8|10|12|14|16|18|20|24|28|32|36|40|44|48|56|64|72|80|96|112|128)px\b/g,
    label: "spacing value",
  },
  // Bare font-size / font-weight declarations with raw values
  { regex: /font-size\s*:\s*(\d+(?:\.\d+)?(?:px|rem|em))/g, label: "font size" },
  { regex: /font-weight\s*:\s*(100|200|300|400|500|600|700|800|900)\b/g, label: "font weight" },
];

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Extracts the raw matched value from a regex match, stripping property names
 * (e.g. "font-size: 16px" → "16px").
 */
function extractValue(matchText: string, label: string): string {
  if (label === "font size") {
    const m = matchText.match(/font-size\s*:\s*(.+)/);
    return m ? m[1].trim() : matchText;
  }
  if (label === "font weight") {
    const m = matchText.match(/font-weight\s*:\s*(.+)/);
    return m ? m[1].trim() : matchText;
  }
  return matchText;
}

function buildDiagnosticMessage(rawValue: string, tokens: SaltToken[]): string {
  if (tokens.length === 0) {
    return `Hardcoded value "${rawValue}" — consider using a Salt design token instead.`;
  }
  const suggestions = tokens
    .slice(0, 3)
    .map((t) => t.tokenName)
    .join(", ");
  return `Hardcoded value "${rawValue}" — consider using Salt token: ${suggestions}`;
}

// ---------------------------------------------------------------------------
// Diagnostic collection
// ---------------------------------------------------------------------------

let _diagnosticCollection: vscode.DiagnosticCollection | null = null;

function getDiagnosticCollection(): vscode.DiagnosticCollection {
  if (!_diagnosticCollection) {
    _diagnosticCollection = vscode.languages.createDiagnosticCollection(
      DIAGNOSTIC_SOURCE
    );
  }
  return _diagnosticCollection;
}

// ---------------------------------------------------------------------------
// Core scanner
// ---------------------------------------------------------------------------

export async function scanDocument(
  document: vscode.TextDocument
): Promise<void> {
  if (!SUPPORTED_LANGUAGES.includes(document.languageId)) {
    return;
  }

  const text = document.getText();
  const diagnostics: vscode.Diagnostic[] = [];

  for (const { regex, label } of DETECTION_PATTERNS) {
    // Clone regex to reset lastIndex for global regexes
    const re = new RegExp(regex.source, regex.flags);
    let match: RegExpExecArray | null;

    while ((match = re.exec(text)) !== null) {
      const rawValue = extractValue(match[0], label);

      // Skip if this is already inside a CSS custom property definition
      // (i.e. the token itself is being declared, not consumed)
      const lineStart = text.lastIndexOf("\n", match.index) + 1;
      const lineText = text.substring(lineStart, text.indexOf("\n", match.index));
      if (/--[\w-]+\s*:/.test(lineText)) {
        continue;
      }

      // Look for matching Salt tokens
      const matchingTokens = await findTokensForValue(rawValue);

      const startPos = document.positionAt(match.index);
      const endPos = document.positionAt(match.index + match[0].length);
      const range = new vscode.Range(startPos, endPos);

      const message = buildDiagnosticMessage(rawValue, matchingTokens);
      const diagnostic = new vscode.Diagnostic(
        range,
        message,
        matchingTokens.length > 0
          ? vscode.DiagnosticSeverity.Warning
          : vscode.DiagnosticSeverity.Information
      );

      diagnostic.source = DIAGNOSTIC_SOURCE;
      diagnostic.code = DIAGNOSTIC_CODE;

      // Attach token suggestions as related information so the quick-fix
      // code action can read them back without re-scanning.
      if (matchingTokens.length > 0) {
        (diagnostic as any)._saltTokenSuggestions = matchingTokens
          .slice(0, 5)
          .map((t) => t.tokenName);
      }

      diagnostics.push(diagnostic);
    }
  }

  getDiagnosticCollection().set(document.uri, diagnostics);
}

export function clearDocumentDiagnostics(uri: vscode.Uri): void {
  getDiagnosticCollection().delete(uri);
}

// ---------------------------------------------------------------------------
// Quick Fix — Code Action Provider
// ---------------------------------------------------------------------------

export class SaltQuickFixProvider implements vscode.CodeActionProvider {
  static readonly providedCodeActionKinds = [vscode.CodeActionKind.QuickFix];

  provideCodeActions(
    document: vscode.TextDocument,
    range: vscode.Range | vscode.Selection,
    context: vscode.CodeActionContext
  ): vscode.CodeAction[] {
    const actions: vscode.CodeAction[] = [];

    for (const diagnostic of context.diagnostics) {
      if (diagnostic.code !== DIAGNOSTIC_CODE) {
        continue;
      }

      const suggestions: string[] =
        (diagnostic as any)._saltTokenSuggestions ?? [];

      if (suggestions.length === 0) {
        continue;
      }

      for (const tokenName of suggestions) {
        const action = new vscode.CodeAction(
          `Replace with Salt token: var(${tokenName})`,
          vscode.CodeActionKind.QuickFix
        );

        action.diagnostics = [diagnostic];
        action.isPreferred = suggestions.indexOf(tokenName) === 0;

        action.edit = new vscode.WorkspaceEdit();
        action.edit.replace(
          document.uri,
          diagnostic.range,
          `var(${tokenName})`
        );

        actions.push(action);
      }
    }

    return actions;
  }
}

// ---------------------------------------------------------------------------
// Registration helper
// ---------------------------------------------------------------------------

export function registerDiagnosticProvider(
  context: vscode.ExtensionContext
): void {
  const collection = getDiagnosticCollection();
  context.subscriptions.push(collection);

  // Scan already-open documents
  vscode.workspace.textDocuments.forEach(scanDocument);

  // Scan on open
  context.subscriptions.push(
    vscode.workspace.onDidOpenTextDocument(scanDocument)
  );

  // Scan on save
  context.subscriptions.push(
    vscode.workspace.onDidSaveTextDocument(scanDocument)
  );

  // Scan on edit (debounced to avoid thrashing on every keystroke)
  let debounceTimer: NodeJS.Timeout | undefined;
  context.subscriptions.push(
    vscode.workspace.onDidChangeTextDocument((event) => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => scanDocument(event.document), 600);
    })
  );

  // Clear diagnostics when a file is closed
  context.subscriptions.push(
    vscode.workspace.onDidCloseTextDocument((doc) =>
      clearDocumentDiagnostics(doc.uri)
    )
  );

  // Register quick-fix provider
  const quickFixProvider = vscode.languages.registerCodeActionsProvider(
    SUPPORTED_LANGUAGES.map((language) => ({ language })),
    new SaltQuickFixProvider(),
    { providedCodeActionKinds: SaltQuickFixProvider.providedCodeActionKinds }
  );

  context.subscriptions.push(quickFixProvider);
}
