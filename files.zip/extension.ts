import * as vscode from "vscode";
import { activate as activateSaltResolver, deactivate as deactivateSaltResolver, getTokenMap } from "./saltResolver";
import { registerCompletionProvider } from "./completionProvider";
import { registerDiagnosticProvider } from "./diagnosticProvider";
import { registerHoverProvider } from "./hoverProvider";
import { registerChatParticipant } from "./chatParticipant";

// ---------------------------------------------------------------------------
// Activation
// ---------------------------------------------------------------------------

export async function activate(context: vscode.ExtensionContext): Promise<void> {
  console.log("[Salt Copilot Assistant] Activating...");

  // 1. Boot the resolver — reads node_modules and sets up the file watcher
  await activateSaltResolver(context);

  // 2. Register all language feature providers
  registerCompletionProvider(context);
  registerDiagnosticProvider(context);
  registerHoverProvider(context);

  // 3. Register the Copilot chat participant (@salt)
  registerChatParticipant(context);

  // 4. Register the token quick-pick command (used by /tokens slash command
  //    and the status bar item)
  registerTokenSearchCommand(context);

  // 5. Status bar item — shows Salt version and quick access
  registerStatusBarItem(context);

  console.log("[Salt Copilot Assistant] Ready ✅");
}

// ---------------------------------------------------------------------------
// Deactivation
// ---------------------------------------------------------------------------

export function deactivate(): void {
  deactivateSaltResolver();
}

// ---------------------------------------------------------------------------
// Token search quick-pick command
// ---------------------------------------------------------------------------

function registerTokenSearchCommand(context: vscode.ExtensionContext): void {
  const command = vscode.commands.registerCommand(
    "salt-copilot.searchTokens",
    async () => {
      const tokenMap = await getTokenMap();
      const tokens = Object.values(tokenMap);

      if (tokens.length === 0) {
        vscode.window.showWarningMessage(
          "Salt Copilot: No tokens found. Make sure @salt-ds/theme is installed in this workspace."
        );
        return;
      }

      // Build quick-pick items
      const items: vscode.QuickPickItem[] = tokens.map((token) => {
        const lightVal = token.themes.light ?? "";
        const darkVal = token.themes.dark ?? "";
        const valuePreview =
          lightVal && darkVal
            ? `☀️ ${lightVal}  🌙 ${darkVal}`
            : lightVal || darkVal;

        return {
          label: token.tokenName,
          description: valuePreview,
          detail: `${token.category}${token.semantic ? "" : "  ⚠️ foundation token"}`,
        };
      });

      const picked = await vscode.window.showQuickPick(items, {
        placeHolder: "Search Salt tokens — press Enter to copy var(token) to clipboard",
        matchOnDescription: true,
        matchOnDetail: true,
      });

      if (!picked) {
        return;
      }

      const toCopy = `var(${picked.label})`;
      await vscode.env.clipboard.writeText(toCopy);

      vscode.window.showInformationMessage(
        `Copied to clipboard: ${toCopy}`
      );
    }
  );

  context.subscriptions.push(command);
}

// ---------------------------------------------------------------------------
// Status bar item
// ---------------------------------------------------------------------------

async function registerStatusBarItem(
  context: vscode.ExtensionContext
): Promise<void> {
  const statusBarItem = vscode.window.createStatusBarItem(
    vscode.StatusBarAlignment.Right,
    100
  );

  statusBarItem.command = "salt-copilot.searchTokens";
  statusBarItem.tooltip = "Salt Copilot Assistant — click to search tokens";

  // Populate version info once resolver has run
  const { getSaltInstallInfo } = await import("./saltResolver");
  const info = await getSaltInstallInfo();

  if (info.isInstalled) {
    statusBarItem.text = `$(symbol-color) Salt ${info.coreVersion ?? ""}`;
    statusBarItem.backgroundColor = undefined;
    statusBarItem.show();
  } else {
    // Don't show the status bar item if Salt isn't installed
    statusBarItem.hide();
  }

  context.subscriptions.push(statusBarItem);
}
