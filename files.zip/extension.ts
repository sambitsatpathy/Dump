import * as vscode from 'vscode';
import { ContextManager } from './contextManager';
import { ContextSidebarProvider } from './sidebarProvider';

export function activate(context: vscode.ExtensionContext) {
  const manager = new ContextManager();
  const sidebar = new ContextSidebarProvider(context, manager);

  // Register the sidebar webview
  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider(
      ContextSidebarProvider.viewId,
      sidebar,
      { webviewOptions: { retainContextWhenHidden: true } }
    )
  );

  // ── Commands ──────────────────────────────────────────────────────

  // Show panel (focus the sidebar)
  context.subscriptions.push(
    vscode.commands.registerCommand('chatContext.showPanel', () => {
      vscode.commands.executeCommand('chatContextSidebar.focus');
    })
  );

  // Add current file
  context.subscriptions.push(
    vscode.commands.registerCommand('chatContext.addFile', async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) {
        // Let user pick a file
        const uris = await vscode.window.showOpenDialog({
          canSelectMany: true,
          title: 'Add file(s) to context',
        });
        if (uris) {
          let count = 0;
          for (const uri of uris) {
            const item = await manager.addFile(uri);
            if (item) count++;
          }
          if (count > 0) {
            vscode.window.showInformationMessage(`Added ${count} file(s) to context`);
            sidebar.refresh();
          }
        }
        return;
      }

      const item = await manager.addFile(editor.document.uri);
      if (item) {
        vscode.window.showInformationMessage(
          `Added to context: ${item.label} (~${item.tokenCount.toLocaleString()} tokens)`
        );
        sidebar.refresh();
        vscode.commands.executeCommand('chatContextSidebar.focus');
      }
    })
  );

  // Add selection
  context.subscriptions.push(
    vscode.commands.registerCommand('chatContext.addSelection', async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) {
        vscode.window.showWarningMessage('Open a file first.');
        return;
      }
      const item = await manager.addSelection(editor);
      if (item) {
        vscode.window.showInformationMessage(
          `Selection added to context: ${item.label} (~${item.tokenCount.toLocaleString()} tokens)`
        );
        sidebar.refresh();
        vscode.commands.executeCommand('chatContextSidebar.focus');
      }
    })
  );

  // Clear all
  context.subscriptions.push(
    vscode.commands.registerCommand('chatContext.clearAll', async () => {
      const answer = await vscode.window.showWarningMessage(
        'Clear all context items?',
        { modal: true },
        'Clear All'
      );
      if (answer === 'Clear All') {
        manager.clearAll();
        sidebar.refresh();
      }
    })
  );

  // Refresh
  context.subscriptions.push(
    vscode.commands.registerCommand('chatContext.refresh', () => {
      sidebar.refresh();
    })
  );

  // ── Status bar item ───────────────────────────────────────────────
  const statusBar = vscode.window.createStatusBarItem(
    vscode.StatusBarAlignment.Right,
    100
  );
  statusBar.command = 'chatContext.showPanel';
  statusBar.tooltip = 'Chat Context — click to open panel';
  context.subscriptions.push(statusBar);

  function updateStatusBar() {
    const stats = manager.getStats();
    if (stats.itemCount === 0) {
      statusBar.text = '$(symbol-namespace) Context: empty';
      statusBar.color = undefined;
    } else {
      const pct = Math.round(stats.usagePercent);
      const tokenStr = stats.totalTokens >= 1000
        ? `${(stats.totalTokens / 1000).toFixed(1)}k`
        : `${stats.totalTokens}`;
      statusBar.text = `$(symbol-namespace) ${tokenStr} tok · ${stats.itemCount} items`;
      statusBar.color =
        pct > 75 ? new vscode.ThemeColor('editorWarning.foreground') :
        pct > 90 ? new vscode.ThemeColor('editorError.foreground') :
        undefined;
    }
    statusBar.show();
  }

  manager.onDidChange(() => {
    updateStatusBar();
    sidebar.refresh();
  });

  updateStatusBar();
}

export function deactivate() {}
