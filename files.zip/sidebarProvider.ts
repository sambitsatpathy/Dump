import * as vscode from 'vscode';
import { ContextManager, ContextItem, ContextStats } from './contextManager';
import * as path from 'path';

export class ContextSidebarProvider implements vscode.WebviewViewProvider {
  public static readonly viewId = 'chatContextSidebar';
  private _view?: vscode.WebviewView;

  constructor(
    private readonly ctx: vscode.ExtensionContext,
    private readonly manager: ContextManager
  ) {}

  resolveWebviewView(
    webviewView: vscode.WebviewView,
    _context: vscode.WebviewViewResolveContext,
    _token: vscode.CancellationToken
  ): void {
    this._view = webviewView;

    webviewView.webview.options = {
      enableScripts: true,
    };

    webviewView.webview.html = this.buildHtml(webviewView.webview);

    // Keep sidebar in sync
    this.manager.onDidChange(() => this.refresh());

    // Handle messages from webview
    webviewView.webview.onDidReceiveMessage(async (msg) => {
      switch (msg.command) {
        case 'remove':
          this.manager.remove(msg.id);
          break;
        case 'pin':
          this.manager.togglePin(msg.id);
          break;
        case 'clear':
          await vscode.window.showWarningMessage(
            'Clear all unpinned context items?',
            { modal: true },
            'Clear'
          ).then(v => { if (v === 'Clear') this.manager.clear(); });
          break;
        case 'clearAll':
          await vscode.window.showWarningMessage(
            'Clear ALL context items including pinned?',
            { modal: true },
            'Clear All'
          ).then(v => { if (v === 'Clear All') this.manager.clearAll(); });
          break;
        case 'openFile':
          if (msg.filePath) {
            const uri = vscode.Uri.file(msg.filePath);
            const doc = await vscode.workspace.openTextDocument(uri);
            await vscode.window.showTextDocument(doc, {
              selection: msg.lineStart ? new vscode.Range(
                msg.lineStart - 1, 0,
                (msg.lineEnd ?? msg.lineStart) - 1, 0
              ) : undefined,
            });
          }
          break;
        case 'addFile':
          vscode.commands.executeCommand('chatContext.addFile');
          break;
        case 'export':
          {
            const text = this.manager.exportAsText();
            const doc = await vscode.workspace.openTextDocument({
              content: text,
              language: 'markdown',
            });
            vscode.window.showTextDocument(doc);
          }
          break;
        case 'copyItem':
          {
            const item = this.manager.getItem(msg.id);
            if (item) {
              await vscode.env.clipboard.writeText(item.content);
              vscode.window.showInformationMessage('Copied to clipboard');
            }
          }
          break;
      }
    });
  }

  refresh(): void {
    if (!this._view) return;
    const items = this.manager.getItems();
    const stats = this.manager.getStats();
    this._view.webview.postMessage({ command: 'update', items, stats });
  }

  private buildHtml(_webview: vscode.Webview): string {
    return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Chat Context</title>
<style>
  :root {
    --bg: var(--vscode-sideBar-background, #1e1e2e);
    --bg2: var(--vscode-editor-background, #181825);
    --bg3: var(--vscode-input-background, #2a2a3e);
    --fg: var(--vscode-foreground, #cdd6f4);
    --fg2: var(--vscode-descriptionForeground, #a6adc8);
    --accent: var(--vscode-focusBorder, #89b4fa);
    --green: var(--vscode-testing-iconPassed, #a6e3a1);
    --yellow: var(--vscode-editorWarning-foreground, #f9e2af);
    --red: var(--vscode-editorError-foreground, #f38ba8);
    --pink: var(--vscode-charts-pink, #f5c2e7);
    --mauve: var(--vscode-charts-purple, #cba6f7);
    --border: var(--vscode-panel-border, #313244);
    --hover: var(--vscode-list-hoverBackground, rgba(255,255,255,0.05));
    --radius: 6px;
    --font-mono: var(--vscode-editor-font-family, 'JetBrains Mono', 'Fira Code', monospace);
    --font-ui: var(--vscode-font-family, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif);
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: var(--font-ui);
    font-size: 12px;
    color: var(--fg);
    background: var(--bg);
    height: 100vh;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }

  /* ── Header ── */
  .header {
    padding: 10px 12px 8px;
    background: var(--bg2);
    border-bottom: 1px solid var(--border);
    flex-shrink: 0;
  }

  .header-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 8px;
  }

  .title {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    color: var(--fg2);
  }

  .title-dot {
    width: 7px; height: 7px;
    border-radius: 50%;
    background: var(--green);
    box-shadow: 0 0 6px var(--green);
    animation: pulse 2s ease-in-out infinite;
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.4; }
  }

  .header-actions {
    display: flex;
    gap: 2px;
  }

  .icon-btn {
    background: none;
    border: none;
    color: var(--fg2);
    cursor: pointer;
    padding: 3px 5px;
    border-radius: 4px;
    font-size: 13px;
    transition: color 0.15s, background 0.15s;
    line-height: 1;
  }
  .icon-btn:hover { color: var(--fg); background: var(--hover); }
  .icon-btn.danger:hover { color: var(--red); }

  /* ── Token meter ── */
  .token-meter {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  .token-row {
    display: flex;
    justify-content: space-between;
    align-items: baseline;
  }

  .token-label {
    font-size: 11px;
    color: var(--fg2);
  }

  .token-count {
    font-family: var(--font-mono);
    font-size: 11px;
    font-weight: 600;
    color: var(--fg);
  }

  .token-count .slash { color: var(--fg2); font-weight: 400; }
  .token-count .max { color: var(--fg2); font-weight: 400; }

  .progress-track {
    height: 4px;
    background: var(--border);
    border-radius: 2px;
    overflow: hidden;
  }

  .progress-fill {
    height: 100%;
    border-radius: 2px;
    transition: width 0.35s ease, background 0.35s ease;
  }

  .fill-low  { background: linear-gradient(90deg, var(--green), #74c7ec); }
  .fill-mid  { background: linear-gradient(90deg, var(--yellow), #fab387); }
  .fill-high { background: linear-gradient(90deg, var(--red), #f38ba8); }

  .stats-chips {
    display: flex;
    gap: 6px;
    margin-top: 6px;
    flex-wrap: wrap;
  }

  .chip {
    display: flex;
    align-items: center;
    gap: 3px;
    background: var(--bg3);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 2px 7px;
    font-size: 10px;
    color: var(--fg2);
    font-family: var(--font-mono);
  }

  .chip-dot {
    width: 5px; height: 5px;
    border-radius: 50%;
  }

  /* ── Items list ── */
  .scroll-area {
    flex: 1;
    overflow-y: auto;
    padding: 6px 0;
  }

  .scroll-area::-webkit-scrollbar { width: 4px; }
  .scroll-area::-webkit-scrollbar-track { background: transparent; }
  .scroll-area::-webkit-scrollbar-thumb { background: var(--border); border-radius: 2px; }

  .section-label {
    padding: 6px 12px 3px;
    font-size: 10px;
    font-weight: 600;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--fg2);
    opacity: 0.6;
  }

  .item {
    position: relative;
    padding: 7px 10px;
    margin: 1px 6px;
    border-radius: var(--radius);
    border: 1px solid transparent;
    cursor: default;
    transition: background 0.12s, border-color 0.12s;
  }

  .item:hover {
    background: var(--hover);
    border-color: var(--border);
  }

  .item:hover .item-actions { opacity: 1; }

  .item.pinned {
    border-left: 2px solid var(--mauve);
  }

  .item-header {
    display: flex;
    align-items: center;
    gap: 6px;
    min-width: 0;
  }

  .item-icon {
    flex-shrink: 0;
    font-size: 13px;
    line-height: 1;
  }

  .item-name {
    flex: 1;
    font-size: 12px;
    font-weight: 500;
    color: var(--fg);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    min-width: 0;
  }

  .item-tokens {
    flex-shrink: 0;
    font-family: var(--font-mono);
    font-size: 10px;
    color: var(--fg2);
    background: var(--bg3);
    padding: 1px 5px;
    border-radius: 3px;
  }

  .item-desc {
    font-size: 10px;
    color: var(--fg2);
    margin-top: 2px;
    padding-left: 19px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .item-actions {
    position: absolute;
    right: 6px;
    top: 50%;
    transform: translateY(-50%);
    display: flex;
    gap: 1px;
    opacity: 0;
    background: var(--bg2);
    border: 1px solid var(--border);
    border-radius: 5px;
    padding: 2px;
    transition: opacity 0.12s;
  }

  .action-btn {
    background: none;
    border: none;
    color: var(--fg2);
    cursor: pointer;
    padding: 2px 4px;
    border-radius: 3px;
    font-size: 11px;
    line-height: 1;
    transition: color 0.1s, background 0.1s;
  }

  .action-btn:hover { color: var(--fg); background: var(--hover); }
  .action-btn.pin-active { color: var(--mauve); }
  .action-btn.remove:hover { color: var(--red); }

  /* ── Type badges ── */
  .type-file     .item-icon { color: #89b4fa; }
  .type-selection .item-icon { color: var(--green); }
  .type-terminal .item-icon { color: var(--yellow); }
  .type-manual   .item-icon { color: var(--pink); }

  /* ── Empty state ── */
  .empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    gap: 10px;
    color: var(--fg2);
    padding: 24px;
    text-align: center;
  }

  .empty-icon {
    font-size: 32px;
    opacity: 0.3;
    line-height: 1;
  }

  .empty-title {
    font-size: 13px;
    font-weight: 500;
    color: var(--fg2);
    opacity: 0.7;
  }

  .empty-hint {
    font-size: 11px;
    color: var(--fg2);
    opacity: 0.5;
    line-height: 1.5;
  }

  .empty-btn {
    margin-top: 4px;
    background: var(--bg3);
    border: 1px solid var(--border);
    color: var(--accent);
    border-radius: var(--radius);
    padding: 5px 12px;
    font-size: 11px;
    cursor: pointer;
    transition: background 0.12s, border-color 0.12s;
    font-family: var(--font-ui);
  }

  .empty-btn:hover {
    background: var(--hover);
    border-color: var(--accent);
  }

  /* ── Footer ── */
  .footer {
    flex-shrink: 0;
    padding: 7px 10px;
    background: var(--bg2);
    border-top: 1px solid var(--border);
    display: flex;
    gap: 6px;
  }

  .footer-btn {
    flex: 1;
    background: var(--bg3);
    border: 1px solid var(--border);
    color: var(--fg2);
    border-radius: var(--radius);
    padding: 5px 8px;
    font-size: 10px;
    cursor: pointer;
    transition: color 0.12s, border-color 0.12s, background 0.12s;
    font-family: var(--font-ui);
    white-space: nowrap;
    text-align: center;
  }

  .footer-btn:hover {
    color: var(--fg);
    border-color: var(--accent);
    background: var(--hover);
  }

  /* ── Animations ── */
  .item { animation: slide-in 0.15s ease; }
  @keyframes slide-in {
    from { opacity: 0; transform: translateY(-4px); }
    to   { opacity: 1; transform: translateY(0); }
  }
</style>
</head>
<body>

<div class="header">
  <div class="header-top">
    <div class="title">
      <span class="title-dot"></span>
      Context
    </div>
    <div class="header-actions">
      <button class="icon-btn" onclick="addFile()" title="Add current file">＋</button>
      <button class="icon-btn" onclick="exportContext()" title="Export context">↗</button>
      <button class="icon-btn danger" onclick="clearContext()" title="Clear unpinned">⊘</button>
    </div>
  </div>

  <div class="token-meter">
    <div class="token-row">
      <span class="token-label">Context window</span>
      <span class="token-count" id="tokenCount">
        <span id="tokenUsed">0</span>
        <span class="slash"> / </span>
        <span class="max" id="tokenMax">200k</span>
      </span>
    </div>
    <div class="progress-track">
      <div class="progress-fill fill-low" id="progressBar" style="width:0%"></div>
    </div>
    <div class="stats-chips" id="statsChips">
      <span class="chip">
        <span class="chip-dot" style="background: #89b4fa"></span>
        <span id="fileCount">0</span> files
      </span>
      <span class="chip">
        <span class="chip-dot" style="background: #a6e3a1"></span>
        <span id="selCount">0</span> selections
      </span>
    </div>
  </div>
</div>

<div class="scroll-area" id="itemList">
  <div class="empty" id="emptyState">
    <div class="empty-icon">◫</div>
    <div class="empty-title">No context yet</div>
    <div class="empty-hint">Add files or text selections to your<br>chat context window.</div>
    <button class="empty-btn" onclick="addFile()">＋ Add current file</button>
  </div>
</div>

<div class="footer" id="footer" style="display:none">
  <button class="footer-btn" onclick="exportContext()">↗ Export</button>
  <button class="footer-btn" onclick="clearContext()">⊘ Clear unpinned</button>
  <button class="footer-btn" onclick="clearAll()" style="color:var(--red)">✕ Clear all</button>
</div>

<script>
const vscode = acquireVsCodeApi();

const TYPE_ICONS = {
  file: '⬡',
  selection: '▣',
  terminal: '⊞',
  manual: '◈',
  folder: '⊟',
};

let currentItems = [];
let currentStats = null;

window.addEventListener('message', event => {
  const { command, items, stats } = event.data;
  if (command === 'update') {
    currentItems = items;
    currentStats = stats;
    render(items, stats);
  }
});

function render(items, stats) {
  const listEl = document.getElementById('itemList');
  const emptyEl = document.getElementById('emptyState');
  const footer = document.getElementById('footer');

  updateHeader(stats);

  if (!items || items.length === 0) {
    listEl.innerHTML = '';
    listEl.appendChild(emptyEl);
    emptyEl.style.display = 'flex';
    footer.style.display = 'none';
    return;
  }

  emptyEl.style.display = 'none';
  footer.style.display = 'flex';

  const pinned = items.filter(i => i.pinned);
  const rest = items.filter(i => !i.pinned);
  let html = '';

  if (pinned.length > 0) {
    html += '<div class="section-label">📌 Pinned</div>';
    html += pinned.map(renderItem).join('');
  }

  if (rest.length > 0) {
    if (pinned.length > 0) html += '<div class="section-label">Recent</div>';
    html += rest.map(renderItem).join('');
  }

  listEl.innerHTML = html;
}

function renderItem(item) {
  const icon = TYPE_ICONS[item.type] || '◈';
  const tokStr = formatTokens(item.tokenCount);
  const pinClass = item.pinned ? 'pin-active' : '';
  const pinnedClass = item.pinned ? 'pinned' : '';

  return \`
  <div class="item type-\${item.type} \${pinnedClass}" data-id="\${item.id}">
    <div class="item-header">
      <span class="item-icon">\${icon}</span>
      <span class="item-name" title="\${item.description}">\${escHtml(item.label)}</span>
      <span class="item-tokens">\${tokStr}</span>
    </div>
    <div class="item-desc">\${escHtml(item.description)}</div>
    <div class="item-actions">
      \${item.filePath ? \`<button class="action-btn" onclick="openFile('\${item.id}')" title="Open file">⤤</button>\` : ''}
      <button class="action-btn" onclick="copyItem('\${item.id}')" title="Copy content">⎘</button>
      <button class="action-btn \${pinClass}" onclick="pinItem('\${item.id}')" title="\${item.pinned ? 'Unpin' : 'Pin'}">📌</button>
      <button class="action-btn remove" onclick="removeItem('\${item.id}')" title="Remove">✕</button>
    </div>
  </div>\`;
}

function updateHeader(stats) {
  if (!stats) return;
  document.getElementById('tokenUsed').textContent = formatTokens(stats.totalTokens);
  document.getElementById('tokenMax').textContent = formatTokens(stats.maxTokens);
  document.getElementById('fileCount').textContent = stats.fileCount;
  document.getElementById('selCount').textContent = stats.selectionCount;

  const pct = stats.usagePercent;
  const bar = document.getElementById('progressBar');
  bar.style.width = pct + '%';
  bar.className = 'progress-fill ' + (pct < 40 ? 'fill-low' : pct < 75 ? 'fill-mid' : 'fill-high');
}

function formatTokens(n) {
  if (n >= 1000) return (n / 1000).toFixed(1) + 'k';
  return n.toString();
}

function escHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function removeItem(id) { vscode.postMessage({ command: 'remove', id }); }
function pinItem(id)    { vscode.postMessage({ command: 'pin', id }); }
function openFile(id) {
  const item = currentItems.find(i => i.id === id);
  if (item) vscode.postMessage({ command: 'openFile', filePath: item.filePath, lineStart: item.lineStart, lineEnd: item.lineEnd });
}
function copyItem(id)   { vscode.postMessage({ command: 'copyItem', id }); }
function addFile()      { vscode.postMessage({ command: 'addFile' }); }
function exportContext(){ vscode.postMessage({ command: 'export' }); }
function clearContext() { vscode.postMessage({ command: 'clear' }); }
function clearAll()     { vscode.postMessage({ command: 'clearAll' }); }
</script>
</body>
</html>`;
  }
}
