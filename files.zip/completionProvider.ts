import * as vscode from "vscode";
import { getTokenMap, SaltToken } from "./saltResolver";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const SUPPORTED_LANGUAGES = ["css", "scss", "less", "typescriptreact", "javascriptreact", "typescript", "javascript"];

/** Derive a human-readable label for the category. */
function categoryLabel(category: string): string {
  const labels: Record<string, string> = {
    color: "🎨 Color",
    spacing: "📐 Spacing",
    size: "📏 Size",
    typography: "🔤 Typography",
    shadow: "🌑 Shadow",
    zIndex: "📚 Z-Index",
    duration: "⏱ Duration",
    border: "⬜ Border",
    opacity: "👁 Opacity",
    cursor: "🖱 Cursor",
    icon: "🔷 Icon",
    other: "🔧 Other",
  };
  return labels[category] ?? category;
}

/**
 * Returns a markdown color swatch block if the value looks like a colour,
 * otherwise returns the raw value string.
 */
function buildDocumentation(token: SaltToken): vscode.MarkdownString {
  const md = new vscode.MarkdownString(undefined, true);
  md.supportHtml = true;

  const lightVal = token.themes.light ?? "—";
  const darkVal = token.themes.dark ?? "—";

  // Colour swatch via inline SVG data URI (VSCode renders these in markdown)
  const isColor =
    token.category === "color" &&
    (lightVal.startsWith("#") ||
      lightVal.startsWith("rgb") ||
      lightVal.startsWith("hsl"));

  if (isColor) {
    md.appendMarkdown(
      `<span style="background:${lightVal};border:1px solid #888;display:inline-block;` +
        `width:14px;height:14px;border-radius:2px;vertical-align:middle;"></span> ` +
        `**Light:** \`${lightVal}\`\n\n`
    );
    if (darkVal !== "—") {
      md.appendMarkdown(
        `<span style="background:${darkVal};border:1px solid #888;display:inline-block;` +
          `width:14px;height:14px;border-radius:2px;vertical-align:middle;"></span> ` +
          `**Dark:** \`${darkVal}\`\n\n`
      );
    }
  } else {
    md.appendMarkdown(`**Light:** \`${lightVal}\`\n\n`);
    if (darkVal !== "—") {
      md.appendMarkdown(`**Dark:** \`${darkVal}\`\n\n`);
    }
  }

  md.appendMarkdown(
    `**Category:** ${categoryLabel(token.category)}\n\n` +
      `**Layer:** ${token.semantic ? "Semantic (alias)" : "Foundation (primitive)"}\n\n`
  );

  if (!token.semantic) {
    md.appendMarkdown(
      `> ⚠️ Prefer semantic tokens over foundation tokens where possible.\n\n`
    );
  }

  return md;
}

// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------

export class SaltTokenCompletionProvider implements vscode.CompletionItemProvider {
  async provideCompletionItems(
    document: vscode.TextDocument,
    position: vscode.Position,
    _token: vscode.CancellationToken,
    _context: vscode.CompletionContext
  ): Promise<vscode.CompletionItem[]> {
    const linePrefix = document
      .lineAt(position)
      .text.substring(0, position.character);

    // Only trigger when the user has started typing --salt
    if (!linePrefix.includes("--salt")) {
      return [];
    }

    // Extract the partial token typed so far
    const partialMatch = linePrefix.match(/(--salt[\w-]*)$/);
    const partial = partialMatch ? partialMatch[1].toLowerCase() : "--salt";

    const tokenMap = await getTokenMap();
    const items: vscode.CompletionItem[] = [];

    for (const token of Object.values(tokenMap)) {
      if (!token.tokenName.toLowerCase().startsWith(partial)) {
        continue;
      }

      const item = new vscode.CompletionItem(
        token.tokenName,
        vscode.CompletionItemKind.Color
      );

      item.detail = `${categoryLabel(token.category)} — ${token.themes.light ?? token.themes.dark ?? ""}`;
      item.documentation = buildDocumentation(token);
      item.insertText = token.tokenName;

      // Semantic tokens are sorted before foundation tokens
      item.sortText = (token.semantic ? "0" : "1") + token.tokenName;

      // Mark foundation tokens as lower priority with a tag
      if (!token.semantic) {
        item.tags = [vscode.CompletionItemTag.Deprecated];
      }

      items.push(item);
    }

    return items;
  }
}

// ---------------------------------------------------------------------------
// Registration helper
// ---------------------------------------------------------------------------

export function registerCompletionProvider(
  context: vscode.ExtensionContext
): void {
  const provider = new SaltTokenCompletionProvider();

  const disposable = vscode.languages.registerCompletionItemProvider(
    SUPPORTED_LANGUAGES.map((language) => ({ language })),
    provider,
    "-" // trigger character — fires when user types the second '-' in '--salt'
  );

  context.subscriptions.push(disposable);
}
