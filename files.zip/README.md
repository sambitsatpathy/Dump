# Chat Context Viewer

A VS Code extension that lets you inspect and manage your AI chat session context — similar to how `/context` works in Claude Code.

## Features

- 📊 **Live token meter** — see how much of your context window you're using at a glance
- 📁 **Add files** — add any open file to your context with one click or keyboard shortcut
- ✂️ **Add selections** — highlight code and add just that snippet to context
- 📌 **Pin items** — keep important context locked even when you clear the rest
- 📤 **Export** — dump your full context as a markdown file, ready to paste into any chat
- 🔴 **Status bar** — always-visible token count in the bottom bar

## Usage

### Adding Context

| Action | How |
|--------|-----|
| Add current file | `Ctrl+Shift+X, Ctrl+Shift+A` or right-click → *Chat Context: Add Current File* |
| Add selection | Select text → right-click → *Chat Context: Add Selection* |
| Open panel | `Ctrl+Shift+X, Ctrl+Shift+C` or click the `◧` icon in the Activity Bar |

### Managing Context

In the **Chat Context** sidebar:

- **⤤** — Jump to the file in the editor
- **⎘** — Copy item content to clipboard
- **📌** — Pin/unpin (pinned items survive "Clear unpinned")
- **✕** — Remove from context

### Footer actions

- **↗ Export** — Open a markdown file with all context items
- **⊘ Clear unpinned** — Remove everything except pinned items
- **✕ Clear all** — Remove everything including pinned

## Token Counting

Token counts are estimated (~3.8 chars/token) and will differ slightly from the actual model's tokenizer. The progress bar turns yellow above 40% and red above 75%.

The default max context shown is **200,000 tokens** (Claude's context window). You can adjust this in Settings.

## Installation

### From source

```bash
npm install
npm run compile
# Then press F5 in VS Code to launch Extension Development Host
```

### Package as VSIX

```bash
npm install -g @vscode/vsce
npm run package
# Installs the generated .vsix:
code --install-extension chat-context-viewer-0.1.0.vsix
```

## Why?

When using AI chat assistants (Claude.ai, ChatGPT, etc.) alongside VS Code, it's easy to lose track of what you've added to the conversation. This extension gives you Claude Code's `/context` experience — right inside your editor — for any chat session.
