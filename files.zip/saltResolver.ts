import * as vscode from "vscode";
import * as fs from "fs";
import * as path from "path";
import * as ts from "typescript";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface SaltToken {
  tokenName: string; // e.g. "--salt-color-blue-500"
  category: string; // e.g. "color" | "spacing" | "typography" | "shadow" | "zIndex" | "duration" | "other"
  semantic: boolean; // true = semantic/alias token; false = foundation/primitive token
  themes: {
    light: string | null;
    dark: string | null;
  };
}

export interface SaltTokenMap {
  [tokenName: string]: SaltToken;
}

export interface SaltComponentProp {
  name: string;
  type: string;
  optional: boolean;
  jsDoc?: string;
}

export interface SaltComponent {
  name: string;
  source: "@salt-ds/core" | "@salt-ds/lab";
  props: SaltComponentProp[];
  jsDoc?: string;
}

export interface SaltInstallInfo {
  isInstalled: boolean;
  coreVersion: string | null;
  labVersion: string | null;
  themePath: string | null;
  coreDtsPath: string | null;
  labDtsPath: string | null;
  workspaceRoot: string | null;
}

// ---------------------------------------------------------------------------
// Internal cache
// ---------------------------------------------------------------------------

let _tokenMap: SaltTokenMap | null = null;
let _components: SaltComponent[] | null = null;
let _installInfo: SaltInstallInfo | null = null;
let _fileWatcher: vscode.FileSystemWatcher | null = null;

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Call once in `extension.ts` activate(). Sets up cache + file watcher.
 */
export async function activate(context: vscode.ExtensionContext): Promise<void> {
  _installInfo = await resolveSaltInstallInfo();

  if (_installInfo.isInstalled) {
    await buildTokenMap(_installInfo);
    await buildComponentList(_installInfo);
    registerFileWatcher(context, _installInfo);
  } else {
    vscode.window.showInformationMessage(
      "Salt Copilot Assistant: No Salt installation detected in this workspace. " +
        "Open a project with @salt-ds/core installed to enable full features."
    );
  }
}

/** Dispose the file watcher on deactivation. */
export function deactivate(): void {
  _fileWatcher?.dispose();
}

/** Returns metadata about the workspace's Salt installation. */
export async function getSaltInstallInfo(): Promise<SaltInstallInfo> {
  if (!_installInfo) {
    _installInfo = await resolveSaltInstallInfo();
  }
  return _installInfo;
}

/** Returns the full token map (reads from cache after first load). */
export async function getTokenMap(): Promise<SaltTokenMap> {
  if (!_tokenMap) {
    const info = await getSaltInstallInfo();
    await buildTokenMap(info);
  }
  return _tokenMap ?? {};
}

/** Returns the list of all Salt components (reads from cache). */
export async function getComponents(): Promise<SaltComponent[]> {
  if (!_components) {
    const info = await getSaltInstallInfo();
    await buildComponentList(info);
  }
  return _components ?? [];
}

/** Returns tokens filtered by category. */
export async function getTokensByCategory(category: string): Promise<SaltToken[]> {
  const map = await getTokenMap();
  return Object.values(map).filter((t) => t.category === category);
}

/**
 * Given a raw CSS value (e.g. "#0A7EB4" or "16px"), returns matching tokens
 * so the diagnostic provider can suggest the correct Salt token.
 */
export async function findTokensForValue(rawValue: string): Promise<SaltToken[]> {
  const map = await getTokenMap();
  const normalised = rawValue.trim().toLowerCase();
  return Object.values(map).filter(
    (t) =>
      t.themes.light?.toLowerCase() === normalised ||
      t.themes.dark?.toLowerCase() === normalised
  );
}

// ---------------------------------------------------------------------------
// Install info resolution
// ---------------------------------------------------------------------------

async function resolveSaltInstallInfo(): Promise<SaltInstallInfo> {
  const workspaceRoot = getWorkspaceRoot();

  if (!workspaceRoot) {
    return nullInstallInfo();
  }

  const coreRoot = path.join(workspaceRoot, "node_modules", "@salt-ds", "core");
  const labRoot = path.join(workspaceRoot, "node_modules", "@salt-ds", "lab");
  const themeRoot = path.join(workspaceRoot, "node_modules", "@salt-ds", "theme");

  if (!fs.existsSync(coreRoot)) {
    return nullInstallInfo(workspaceRoot);
  }

  return {
    isInstalled: true,
    workspaceRoot,
    coreVersion: readPackageVersion(coreRoot),
    labVersion: fs.existsSync(labRoot) ? readPackageVersion(labRoot) : null,
    themePath: fs.existsSync(themeRoot) ? themeRoot : null,
    coreDtsPath: resolveDeclarationFile(coreRoot),
    labDtsPath: fs.existsSync(labRoot) ? resolveDeclarationFile(labRoot) : null,
  };
}

function nullInstallInfo(workspaceRoot: string | null = null): SaltInstallInfo {
  return {
    isInstalled: false,
    workspaceRoot,
    coreVersion: null,
    labVersion: null,
    themePath: null,
    coreDtsPath: null,
    labDtsPath: null,
  };
}

function getWorkspaceRoot(): string | null {
  const folders = vscode.workspace.workspaceFolders;
  return folders && folders.length > 0 ? folders[0].uri.fsPath : null;
}

function readPackageVersion(pkgRoot: string): string | null {
  try {
    const pkgJson = JSON.parse(
      fs.readFileSync(path.join(pkgRoot, "package.json"), "utf8")
    );
    return pkgJson.version ?? null;
  } catch {
    return null;
  }
}

function resolveDeclarationFile(pkgRoot: string): string | null {
  // Prefer explicit "types" field in package.json, then fall back to
  // common dist locations.
  const candidates = [
    (() => {
      try {
        const pkg = JSON.parse(
          fs.readFileSync(path.join(pkgRoot, "package.json"), "utf8")
        );
        const typesField: string | undefined = pkg.types ?? pkg.typings;
        return typesField ? path.join(pkgRoot, typesField) : null;
      } catch {
        return null;
      }
    })(),
    path.join(pkgRoot, "dist", "index.d.ts"),
    path.join(pkgRoot, "dist", "cjs", "index.d.ts"),
    path.join(pkgRoot, "index.d.ts"),
  ];

  for (const candidate of candidates) {
    if (candidate && fs.existsSync(candidate)) {
      return candidate;
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// Token map builder — parses Salt CSS theme files
// ---------------------------------------------------------------------------

const CATEGORY_PATTERNS: Array<[RegExp, string]> = [
  [/--salt-color/, "color"],
  [/--salt-spacing/, "spacing"],
  [/--salt-size/, "size"],
  [/--salt-text|--salt-typography|--salt-font/, "typography"],
  [/--salt-shadow/, "shadow"],
  [/--salt-z-?index|--salt-zIndex/, "zIndex"],
  [/--salt-duration|--salt-animation/, "duration"],
  [/--salt-border|--salt-radius/, "border"],
  [/--salt-opacity/, "opacity"],
  [/--salt-cursor/, "cursor"],
  [/--salt-icon/, "icon"],
];

function deriveCategory(tokenName: string): string {
  for (const [pattern, cat] of CATEGORY_PATTERNS) {
    if (pattern.test(tokenName)) {
      return cat;
    }
  }
  return "other";
}

/**
 * A token is considered *semantic* (alias layer) if it lives anywhere outside
 * of a file that contains "foundation" in its name.
 */
function isSemantic(fromFile: string): boolean {
  return !path.basename(fromFile).toLowerCase().includes("foundation");
}

async function buildTokenMap(info: SaltInstallInfo): Promise<void> {
  const map: SaltTokenMap = {};

  if (!info.themePath) {
    _tokenMap = map;
    return;
  }

  const cssDir = path.join(info.themePath, "css");
  if (!fs.existsSync(cssDir)) {
    _tokenMap = map;
    return;
  }

  const cssFiles = fs
    .readdirSync(cssDir)
    .filter((f) => f.endsWith(".css"))
    .map((f) => path.join(cssDir, f));

  // Also look for theme subdirectories (some Salt versions nest them)
  for (const entry of fs.readdirSync(cssDir)) {
    const sub = path.join(cssDir, entry);
    if (fs.statSync(sub).isDirectory()) {
      for (const f of fs.readdirSync(sub)) {
        if (f.endsWith(".css")) {
          cssFiles.push(path.join(sub, f));
        }
      }
    }
  }

  for (const filePath of cssFiles) {
    const isLight = filePath.includes("light");
    const isDark = filePath.includes("dark");
    const semantic = isSemantic(filePath);

    const content = fs.readFileSync(filePath, "utf8");
    const tokenRegex = /(--salt-[\w-]+)\s*:\s*([^;}\n]+)/g;
    let match: RegExpExecArray | null;

    while ((match = tokenRegex.exec(content)) !== null) {
      const tokenName = match[1].trim();
      const rawValue = match[2].trim();

      if (!map[tokenName]) {
        map[tokenName] = {
          tokenName,
          category: deriveCategory(tokenName),
          semantic,
          themes: { light: null, dark: null },
        };
      }

      if (isLight) {
        map[tokenName].themes.light = rawValue;
      } else if (isDark) {
        map[tokenName].themes.dark = rawValue;
      } else {
        // Foundation / neutral file — set as light fallback if not already set
        map[tokenName].themes.light ??= rawValue;
      }
    }
  }

  _tokenMap = map;
}

// ---------------------------------------------------------------------------
// Component list builder — parses TypeScript declaration files
// ---------------------------------------------------------------------------

async function buildComponentList(info: SaltInstallInfo): Promise<void> {
  const components: SaltComponent[] = [];

  const sources: Array<{
    dtsPath: string | null;
    pkg: "@salt-ds/core" | "@salt-ds/lab";
  }> = [
    { dtsPath: info.coreDtsPath, pkg: "@salt-ds/core" },
    { dtsPath: info.labDtsPath, pkg: "@salt-ds/lab" },
  ];

  for (const { dtsPath, pkg } of sources) {
    if (!dtsPath || !fs.existsSync(dtsPath)) {
      continue;
    }

    const extracted = extractComponentsFromDts(dtsPath, pkg);
    components.push(...extracted);
  }

  _components = components;
}

function extractComponentsFromDts(
  dtsPath: string,
  source: "@salt-ds/core" | "@salt-ds/lab"
): SaltComponent[] {
  const components: SaltComponent[] = [];

  const program = ts.createProgram([dtsPath], {
    declaration: true,
    emitDeclarationOnly: true,
    jsx: ts.JsxEmit.React,
  });

  const checker = program.getTypeChecker();
  const sourceFile = program.getSourceFile(dtsPath);

  if (!sourceFile) {
    return components;
  }

  // Walk top-level statements looking for exported function/const declarations
  // that have JSX-compatible signatures (i.e. return JSX.Element / ReactElement).
  ts.forEachChild(sourceFile, (node) => {
    if (!isExported(node)) {
      return;
    }

    let componentName: string | null = null;
    let propsTypeName: string | null = null;

    // function MyComponent(props: MyProps): JSX.Element
    if (
      ts.isFunctionDeclaration(node) &&
      node.name &&
      isJsxReturnType(node, checker)
    ) {
      componentName = node.name.text;
      propsTypeName = extractPropsTypeName(node);
    }

    // export const MyComponent: React.FC<MyProps> = ...
    // export declare const MyComponent: ...
    if (ts.isVariableStatement(node)) {
      for (const decl of node.declarationList.declarations) {
        if (!ts.isIdentifier(decl.name)) {
          continue;
        }
        const name = decl.name.text;
        // Heuristic: exported PascalCase names are components
        if (/^[A-Z]/.test(name)) {
          componentName = name;
          if (decl.type) {
            propsTypeName = extractPropsTypeNameFromType(decl.type);
          }
        }
      }
    }

    if (!componentName) {
      return;
    }

    const jsDoc = extractJsDoc(node);
    const props = propsTypeName
      ? resolvePropsFromSourceFile(sourceFile, propsTypeName, checker)
      : [];

    components.push({
      name: componentName,
      source,
      props,
      jsDoc,
    });
  });

  return components;
}

// ---------------------------------------------------------------------------
// TypeScript AST helpers
// ---------------------------------------------------------------------------

function isExported(node: ts.Node): boolean {
  const modifiers =
    ts.canHaveModifiers(node) ? ts.getModifiers(node) : undefined;
  return (
    modifiers?.some((m) => m.kind === ts.SyntaxKind.ExportKeyword) ?? false
  );
}

function isJsxReturnType(
  node: ts.FunctionDeclaration,
  checker: ts.TypeChecker
): boolean {
  if (!node.type) {
    return false;
  }
  const typeText = node.type.getText();
  return (
    typeText.includes("JSX.Element") ||
    typeText.includes("ReactElement") ||
    typeText.includes("ReactNode")
  );
}

function extractPropsTypeName(node: ts.FunctionDeclaration): string | null {
  const firstParam = node.parameters[0];
  if (!firstParam?.type) {
    return null;
  }
  const typeText = firstParam.type.getText();
  // Strip generics to get the base type name
  return typeText.replace(/<.*>/, "").trim() || null;
}

function extractPropsTypeNameFromType(typeNode: ts.TypeNode): string | null {
  const text = typeNode.getText();
  // Match React.FC<Props>, React.ForwardRefExoticComponent<Props>, etc.
  const match = text.match(/[A-Za-z]+\s*<\s*([A-Za-z]+Props)\s*>/);
  return match ? match[1] : null;
}

function resolvePropsFromSourceFile(
  sourceFile: ts.SourceFile,
  propsTypeName: string,
  checker: ts.TypeChecker
): SaltComponentProp[] {
  const props: SaltComponentProp[] = [];

  ts.forEachChild(sourceFile, (node) => {
    const name =
      (ts.isInterfaceDeclaration(node) || ts.isTypeAliasDeclaration(node)) &&
      node.name.text === propsTypeName
        ? node.name.text
        : null;

    if (!name) {
      return;
    }

    if (ts.isInterfaceDeclaration(node)) {
      for (const member of node.members) {
        if (ts.isPropertySignature(member) && ts.isIdentifier(member.name)) {
          props.push({
            name: member.name.text,
            type: member.type?.getText() ?? "unknown",
            optional: !!member.questionToken,
            jsDoc: extractJsDoc(member),
          });
        }
      }
    }
  });

  return props;
}

function extractJsDoc(node: ts.Node): string | undefined {
  const fullText = node.getFullText();
  const jsDocMatch = fullText.match(/\/\*\*([\s\S]*?)\*\//);
  if (!jsDocMatch) {
    return undefined;
  }
  return jsDocMatch[1]
    .split("\n")
    .map((line) => line.replace(/^\s*\*\s?/, "").trim())
    .filter(Boolean)
    .join(" ");
}

// ---------------------------------------------------------------------------
// File watcher — invalidates cache when Salt packages change
// ---------------------------------------------------------------------------

function registerFileWatcher(
  context: vscode.ExtensionContext,
  info: SaltInstallInfo
): void {
  if (!info.workspaceRoot) {
    return;
  }

  const pattern = new vscode.RelativePattern(
    info.workspaceRoot,
    "node_modules/@salt-ds/**/*.{css,d.ts}"
  );

  _fileWatcher = vscode.workspace.createFileSystemWatcher(pattern);

  const invalidateAndRebuild = async () => {
    _tokenMap = null;
    _components = null;
    _installInfo = null;
    _installInfo = await resolveSaltInstallInfo();
    if (_installInfo.isInstalled) {
      await buildTokenMap(_installInfo);
      await buildComponentList(_installInfo);
    }
  };

  _fileWatcher.onDidChange(invalidateAndRebuild);
  _fileWatcher.onDidCreate(invalidateAndRebuild);
  _fileWatcher.onDidDelete(invalidateAndRebuild);

  context.subscriptions.push(_fileWatcher);
}

// ---------------------------------------------------------------------------
// Utility: build a summary string for use in Copilot system prompts
// ---------------------------------------------------------------------------

/**
 * Returns a concise text summary of installed components + tokens,
 * ready to inject into a Copilot LLM system prompt.
 */
export async function buildCopilotSystemContext(): Promise<string> {
  const info = await getSaltInstallInfo();

  if (!info.isInstalled) {
    return "Salt Design System is not installed in this workspace.";
  }

  const components = await getComponents();
  const tokenMap = await getTokenMap();

  const componentSummary = components
    .map((c) => `- ${c.name} (${c.source})${c.jsDoc ? ": " + c.jsDoc : ""}`)
    .join("\n");

  const tokenCategories = [...new Set(Object.values(tokenMap).map((t) => t.category))];

  return `
## Salt Design System Context
- Core version: ${info.coreVersion ?? "unknown"}
- Lab version: ${info.labVersion ?? "not installed"}

## Available Components (${components.length} total)
${componentSummary}

## Available Token Categories (${Object.keys(tokenMap).length} tokens total)
${tokenCategories.map((c) => `- ${c}`).join("\n")}

When suggesting components, always use the exact component name from the list above.
When suggesting tokens, use --salt-* CSS custom properties.
Prefer @salt-ds/core over @salt-ds/lab unless the user specifically needs a lab component.
Always wrap Salt components in <SaltProvider> at the app root.
`.trim();
}
