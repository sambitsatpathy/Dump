import * as vscode from "vscode";
import { getTokenMap, SaltToken } from "./saltResolver";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Regex to find any --salt-* token reference under the cursor. */
const SALT_TOKEN_REGEX = /(--salt-[\w-]+)/;

function categoryIcon(category: string): string {
  const icons: Record<string, string> = {
    color: "🎨",
    spacing: "📐",
    size: "📏",
    typography: "🔤",
    shadow: "🌑",
    zIndex: "📚",
    duration: "⏱",
    border: "⬜",
    opacity: "👁",
    cursor: "🖱",
    icon: "🔷",
    other: "🔧",
  };
  return icons[category] ?? "🔧";
}

function isColorValue(value: string): boolean {
  return (
    value.startsWith("#") ||
    value.startsWith("rgb") ||
    value.startsWith("hsl")
  );
}

function colorSwatch(value: string): string {
  return (
    `<span style="background:${value};border:1px solid #666;display:inline-block;` +
    `width:13px;height:13px;border-radius:2px;vertical-align:middle;margin-right:4px;"></span>`
  );
}

function buildHoverContent(token: SaltToken): vscode.MarkdownString {
  const md = new vscode.MarkdownString(undefined, true);
  md.supportHtml = true;
  md.isTrusted = true;

  // Header
  md.appendMarkdown(
    `### ${categoryIcon(token.category)} \`${token.tokenName}\`\n\n`
  );

  // Divider
  md.appendMarkdown("---\n\n");

  // Light theme value
  const lightVal = token.themes.light;
  if (lightVal) {
    const swatch = isColorValue(lightVal) ? colorSwatch(lightVal) : "";
    md.appendMarkdown(`**☀️ Light:** ${swatch}\`${lightVal}\`\n\n`);
  }

  // Dark theme value
  const darkVal = token.themes.dark;
  if (darkVal) {
    const swatch = isColorValue(darkVal) ? colorSwatch(darkVal) : "";
    md.appendMarkdown(`**🌙 Dark:** ${swatch}\`${darkVal}\`\n\n`);
  }

  if (!lightVal && !darkVal) {
    md.appendMarkdown("_No resolved value found in theme files._\n\n");
  }

  md.appendMarkdown("---\n\n");

  // Metadata
  md.appendMarkdown(
    `| | |\n|---|---|\n` +
      `| **Category** | ${categoryIcon(token.category)} ${token.category} |\n` +
      `| **Layer** | ${token.semantic ? "Semantic (alias)" : "Foundation (primitive)"} |\n` +
      `| **Responds to theme** | ${token.themes.dark ? "✅ Yes (light + dark)" : "⚠️ Light only"} |\n\n`
  );

  // Warning for foundation tokens
  if (!token.semantic) {
    md.appendMarkdown(
      `> ⚠️ **Foundation token** — This is a primitive value. ` +
        `Prefer a semantic token (e.g. \`--salt-color-*\` alias) so your UI ` +
        `automatically adapts to theme changes.\n\n`
    );
  }

  // Usage snippet
  md.appendMarkdown("**Usage:**\n");
  md.appendCodeblock(
    `.my-element {\n  color: var(${token.tokenName});\n}`,
    "css"
  );

  return md;
}

// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------

export class SaltTokenHoverProvider implements vscode.HoverProvider {
  async provideHover(
    document: vscode.TextDocument,
    position: vscode.Position,
    _token: vscode.CancellationToken
  ): Promise<vscode.Hover | null> {
    // Find the word range that matches a --salt-* token at this position
    const wordRange = document.getWordRangeAtPosition(
      position,
      SALT_TOKEN_REGEX
    );

    if (!wordRange) {
      return null;
    }

    const tokenName = document.getText(wordRange);
    if (!tokenName.startsWith("--salt-")) {
      return null;
    }

    const tokenMap = await getTokenMap();
    const token = tokenMap[tokenName];

    if (!token) {
      // Token name looks like Salt but isn't in the map — might be a custom
      // extension or typo. Show a lightweight "not found" hover.
      const md = new vscode.MarkdownString();
      md.appendMarkdown(
        `### \`${tokenName}\`\n\n` +
          `⚠️ Token not found in the installed Salt theme files. ` +
          `Check for typos or verify your \`@salt-ds/theme\` version.`
      );
      return new vscode.Hover(md, wordRange);
    }

    return new vscode.Hover(buildHoverContent(token), wordRange);
  }
}

// ---------------------------------------------------------------------------
// Registration helper
// ---------------------------------------------------------------------------

const SUPPORTED_LANGUAGES = [
  "css",
  "scss",
  "less",
  "typescriptreact",
  "javascriptreact",
  "typescript",
  "javascript",
];

export function registerHoverProvider(context: vscode.ExtensionContext): void {
  const provider = vscode.languages.registerHoverProvider(
    SUPPORTED_LANGUAGES.map((language) => ({ language })),
    new SaltTokenHoverProvider()
  );

  context.subscriptions.push(provider);
}
