---
name: ui-code-review
description: >
  Deep code review skill for React, Node.js, and TypeScript projects. Use this skill whenever
  the user asks to review, audit, analyse, or improve code written in React, Node.js, or
  TypeScript. Triggers include: "review my code", "audit this component", "check for anti-patterns",
  "find issues", "refactor this", "code quality", "best practices", "what's wrong with this",
  "clean up my code", "review my hooks", "check my types", or when the user pastes React
  components, Node.js modules, or TypeScript files expecting feedback. Performs systematic
  multi-pass analysis covering type safety, React correctness, Node.js patterns, redundancy,
  anti-patterns, performance, security, and accessibility. Always produces a structured
  REMEDIATION_PLAN.md as the final output — a prioritised, fix-ready document the user can
  reference in subsequent prompts to apply individual fixes one at a time.
---

# UI Code Review Skill — React · Node.js · TypeScript

Perform a systematic, multi-pass deep review of React, Node.js, and TypeScript code.
Every review ends with a **REMEDIATION_PLAN.md** — a structured, machine-readable document
the user can feed back into any subsequent prompt to apply fixes incrementally.

---

## How to Use This Skill

**Input**: The user pastes code (one file, multiple files, or a directory tree).
**Process**: Run all review phases below in sequence.
**Output**: Inline annotated findings + a `REMEDIATION_PLAN.md` file.

The remediation plan is designed to survive context resets.
Each item is self-contained so the user can say:
> "Fix ITEM-004 from the remediation plan" 
and receive a targeted, correct fix without re-explaining the codebase.

---

## Phase 0 — Intake & Scope

Before reviewing, establish context:

1. **Identify the stack layer** of each file:
   - `UI` — React component, hook, context, page
   - `API` — Node.js route handler, middleware, controller
   - `SERVICE` — Business logic, data transformation
   - `INFRA` — Config, build scripts, env handling
   - `TYPES` — Shared TypeScript type/interface definitions
   - `TEST` — Unit, integration, or e2e test files

2. **Detect framework signals**:
   - React version (hooks-era vs class components)
   - Node runtime (Express, Fastify, Next.js API routes, tRPC, NestJS)
   - TypeScript strictness (check for `strict: true`, `noImplicitAny`, `strictNullChecks`)
   - State management (useState, useReducer, Zustand, Redux, Jotai, Recoil)
   - Data fetching (fetch, axios, React Query, SWR, tRPC)

3. **Set severity scale** used throughout the review:

| Severity | Label | Meaning |
|----------|-------|---------|
| 🔴 | `CRITICAL` | Bug, security vulnerability, data loss risk, broken behaviour |
| 🟠 | `HIGH` | Performance regression, type unsafety, major anti-pattern |
| 🟡 | `MEDIUM` | Maintainability debt, minor anti-pattern, redundant code |
| 🔵 | `LOW` | Style, naming, minor improvement |
| ⚪ | `INFO` | Observation, suggestion, no action required |

---

## Phase 1 — TypeScript Deep Analysis

### 1.1 Type Safety

Check for every instance of:

```
❌ any  — explicit escape hatch; flag every single occurrence
❌ as X  — type assertion that bypasses inference; flag unless provably safe
❌ !  — non-null assertion; flag unless the null case is structurally impossible
❌ @ts-ignore / @ts-expect-error  — suppression comments; flag and demand justification
❌ object / Object  — overly broad types; demand specificity
❌ Function  — non-callable typed function; demand typed signature
```

For each occurrence, provide:
- The exact line and the unsafe pattern
- Why it is dangerous in this specific context
- The correctly typed replacement

### 1.2 Interface vs Type

Flag misuse:
- `interface` used for union types, mapped types, or conditional types → use `type`
- `type` used for extendable shapes that could be `interface` → prefer `interface` for public API contracts
- Inconsistency within the same file/module

### 1.3 Generics

Detect:
- Generic parameters named `T`, `T1`, `T2` with no semantic meaning → rename
- Missing generics where the same shape appears in multiple return types
- `any` inside a generic constraint (`<T extends any>`) → `<T extends unknown>`

### 1.4 Enums

Flag `const enum` used in cross-module boundaries (erasure issue with isolatedModules).
Suggest union string literal types as safer alternatives:
```ts
// ❌ const enum — erased, unsafe across module boundaries
const enum Status { Active, Inactive }

// ✅ union literal — explicit, portable
type Status = "active" | "inactive";
```

### 1.5 Utility Types

Detect manual re-implementation of built-in utility types:
```ts
// ❌ manual
type OptionalUser = { id?: string; name?: string; email?: string };

// ✅ utility
type OptionalUser = Partial<User>;
```
Check for: `Partial`, `Required`, `Readonly`, `Pick`, `Omit`, `Exclude`, `Extract`,
`NonNullable`, `ReturnType`, `Parameters`, `Awaited`.

### 1.6 Strict Null Checks

With `strictNullChecks: true`, verify:
- No unguarded property access on potentially undefined values
- Optional chaining (`?.`) used consistently
- Nullish coalescing (`??`) used over `||` where `0` or `""` are valid falsy values

---

## Phase 2 — React Deep Analysis

### 2.1 Hook Rules

Verify React's Rules of Hooks are respected:
- Hooks called unconditionally (not inside `if`, `for`, `switch`, or callbacks)
- Hooks called only from React function components or custom hooks
- Custom hooks prefixed with `use`

Flag:
```tsx
// ❌ conditional hook
if (isLoggedIn) {
  const [data, setData] = useState(null); // CRITICAL
}

// ❌ hook in event handler
const handleClick = () => {
  const [x, setX] = useState(0); // CRITICAL
};
```

### 2.2 useEffect Correctness

This is the single most common source of React bugs. For every `useEffect`:

**Dependency array audit**:
- Missing dependencies (stale closure) — list each missing dep and its risk
- Unnecessary dependencies (overcalling) — functions recreated on every render
- Object/array literals in dependency array → always a new reference per render

**Cleanup audit**:
- Effects that set up subscriptions, timers, or event listeners without returning a cleanup function → `CRITICAL`
- Effects that mutate external state without cleanup → `HIGH`

**Anti-patterns**:
```tsx
// ❌ useEffect for derived state
useEffect(() => {
  setFullName(`${firstName} ${lastName}`);
}, [firstName, lastName]);
// ✅ derive inline: const fullName = `${firstName} ${lastName}`;

// ❌ useEffect for event handler synchronisation
useEffect(() => {
  if (submitted) submitForm();
}, [submitted]);
// ✅ call submitForm() directly in the event handler

// ❌ fetch inside useEffect with no abort
useEffect(() => {
  fetch("/api/data").then(r => r.json()).then(setData);
}, []);
// ✅ use AbortController or a data-fetching library
```

### 2.3 Memoisation Audit

Detect **missing** memoisation (performance risk):
- Expensive computations in render body without `useMemo`
- Callback props passed to memoised children without `useCallback`
- Components that re-render on every parent render despite pure inputs → suggest `React.memo`

Detect **unnecessary** memoisation (adds complexity, no benefit):
- `useMemo` wrapping a primitive value or trivial expression
- `useCallback` on a function not passed as a prop
- `React.memo` on a component that always receives different props

```tsx
// ❌ pointless useMemo
const title = useMemo(() => "Hello World", []); // LOW

// ❌ missing useMemo
const sortedList = items.sort((a, b) => a.score - b.score); // HIGH if items is large
// ✅
const sortedList = useMemo(() => [...items].sort((a, b) => a.score - b.score), [items]);
```

### 2.4 Component Design

Flag:
- **God components** — component with more than ~150 lines of JSX or more than 3 distinct responsibilities
- **Prop drilling** — same prop passed through 3+ layers with no intermediate use → suggest context or composition
- **Inline object/array props** — creates new reference every render, breaking memoisation:
  ```tsx
  // ❌
  <Component style={{ margin: 0 }} options={["a", "b"]} />
  // ✅ hoist to module scope or useMemo
  ```
- **Index as key** in lists where items can reorder or be deleted → `HIGH`
- **Boolean trap props**: `<Button light />` is ambiguous → `<Button variant="light" />`

### 2.5 State Management

Detect:
- State that should be derived (computed from existing state/props) stored in `useState`
- State duplicated between sibling components (lift it up)
- `useReducer` warranted when more than 2–3 `useState` calls are interdependent
- State initialiser functions missing for expensive computations:
  ```tsx
  // ❌ runs heavyCompute() on every render
  const [state, setState] = useState(heavyCompute());
  // ✅ lazy initialiser
  const [state, setState] = useState(() => heavyCompute());
  ```

### 2.6 Event Handling

Flag:
- Missing `event.preventDefault()` on form submit handlers
- `onClick` attached to non-interactive elements (`div`, `span`) without ARIA role
- Async event handlers without error boundaries or try/catch

### 2.7 Rendering & Lists

```tsx
// ❌ mutation in render
const sorted = items.sort(...); // mutates original array — HIGH

// ❌ conditional rendering with &&  when value can be 0
{count && <Badge>{count}</Badge>} // renders "0" — HIGH
// ✅
{count > 0 && <Badge>{count}</Badge>}
// or
{count ? <Badge>{count}</Badge> : null}
```

### 2.8 React-Specific Anti-Patterns

Full checklist:
- `useLayoutEffect` used where `useEffect` is sufficient (causes SSR warnings)
- `forwardRef` missing on components that accept a `ref` prop
- `defaultProps` on function components (deprecated) → use default parameter values
- Class components without error boundaries where hooks-era alternatives exist
- Spreading unknown props onto DOM elements (`<div {...props}>` where `props` includes non-DOM attrs)
- Calling `setState` during render (causes infinite loop)
- Missing `key` prop on any mapped element

---

## Phase 3 — Node.js Deep Analysis

### 3.1 Async / Await Correctness

```ts
// ❌ floating promise — unhandled rejection crashes Node in production
fetchData(); // HIGH — no await, no .catch()

// ❌ sequential await inside a loop
for (const id of ids) {
  const item = await fetchItem(id); // HIGH — serialises what could be parallel
}
// ✅
const items = await Promise.all(ids.map(fetchItem));

// ❌ Promise constructor anti-pattern
const result = await new Promise((resolve) => {
  someAsyncFn().then(resolve); // wrapping a promise in a promise
});
// ✅
const result = await someAsyncFn();
```

### 3.2 Error Handling

Flag:
- Empty `catch` blocks — swallowed errors, no logging
- `catch(e)` where `e` is typed as `any` → type as `unknown`, then narrow
- Missing error propagation in Express/Fastify middleware (`next(err)` not called)
- Unhandled promise rejections at the process level
- Try/catch wrapping code that cannot throw (unnecessary noise)

```ts
// ❌ swallowed error
try {
  await db.query(sql);
} catch {} // CRITICAL — silent failure

// ❌ any-typed error
} catch (e: any) { // HIGH
  console.log(e.message);
}

// ✅ typed narrow
} catch (e) {
  if (e instanceof DatabaseError) { ... }
  else { throw e; } // re-throw unknown errors
}
```

### 3.3 Security

Flag every instance of:
- **SQL/NoSQL injection** — string-concatenated queries without parameterisation → `CRITICAL`
- **Command injection** — `child_process.exec` with user input → `CRITICAL`
- **Path traversal** — `path.join` or `fs.readFile` with unsanitised user input → `CRITICAL`
- **Hardcoded secrets** — API keys, passwords, tokens in source code → `CRITICAL`
- **Missing input validation** — route handlers accepting `req.body` without schema validation → `HIGH`
- **Prototype pollution** — unsafe `Object.assign({}, req.body)` patterns → `HIGH`
- **CORS misconfiguration** — `origin: "*"` in authenticated APIs → `HIGH`
- **JWT without expiry** — `sign(payload, secret)` with no `expiresIn` → `HIGH`
- **Missing rate limiting** on auth or sensitive endpoints → `MEDIUM`

### 3.4 Express / Fastify Patterns

```ts
// ❌ sync handler — blocks event loop
app.get("/data", (req, res) => {
  const data = fs.readFileSync("data.json"); // HIGH
  res.json(data);
});
// ✅ async
app.get("/data", async (req, res) => {
  const data = await fs.promises.readFile("data.json");
  res.json(JSON.parse(data.toString()));
});

// ❌ missing error forwarding in async middleware
app.get("/item/:id", async (req, res) => {
  const item = await db.find(req.params.id); // if this throws, Express hangs
  res.json(item);
});
// ✅
app.get("/item/:id", async (req, res, next) => {
  try {
    const item = await db.find(req.params.id);
    res.json(item);
  } catch (e) {
    next(e);
  }
});
```

### 3.5 Resource Management

Flag:
- Database connections opened per-request instead of pooled
- File streams opened without `on("error")` handlers and without closing
- Missing `finally` blocks for cleanup after async operations
- `setTimeout`/`setInterval` references not stored for potential `clearTimeout`/`clearInterval`

### 3.6 Environment & Config

```ts
// ❌ direct process.env access without validation
const dbUrl = process.env.DATABASE_URL; // type is string | undefined — HIGH
db.connect(dbUrl); // could be undefined

// ✅ validated config module (zod, envalid, or manual)
import { config } from "./config"; // validated at startup, throws early if missing
db.connect(config.DATABASE_URL); // string guaranteed
```

---

## Phase 4 — Redundancy & Dead Code Analysis

This pass identifies code that exists but provides no value — a direct maintenance liability.

### 4.1 Dead Code Detection

Scan for:
- Exported functions/components/types with zero import sites in the project
- Variables assigned but never read
- Branches that can never be reached:
  ```ts
  // ❌ unreachable else
  const x: true = true;
  if (x) { doThing(); } else { doOtherThing(); } // else is dead
  ```
- `console.log` / `console.debug` left in production code
- Commented-out code blocks (flag for deletion or promotion to tracked issue)
- Unused imports (TypeScript `noUnusedLocals` and `noUnusedParameters` surface these)

### 4.2 Duplicate Logic

Detect:
- The same transformation applied in 2+ places without a shared utility
- Copy-pasted JSX structures that should be abstracted into a component
- Repeated `useEffect` patterns across components → candidate for a custom hook
- Duplicated type definitions that should be a single shared interface

### 4.3 Over-Engineering

Flag:
- Abstractions with a single caller (YAGNI)
- Wrapper components that add no behaviour or style
- Generic utility functions parameterised for variations that never exist
- Context providers wrapping a single consumer

### 4.4 Unnecessary Re-renders (React-specific redundancy)

- State updates that set the same value (React bails out, but the call still queues work)
- `useEffect` with an empty dep array that could be replaced by module-level initialisation
- Side effects in component body that should be in `useEffect` or event handlers

---

## Phase 5 — Anti-Pattern Catalogue

Complete checklist of named anti-patterns to identify by name in the report.

### React Anti-Patterns
| Anti-Pattern | Severity | Description |
|---|---|---|
| Prop Drilling | 🟡 MEDIUM | Props passed 3+ levels without use |
| God Component | 🟠 HIGH | >150 LOC JSX or 3+ responsibilities |
| Index as Key | 🟠 HIGH | `key={index}` on reorderable lists |
| Derive Don't Store | 🟡 MEDIUM | Storing computable values in state |
| Stale Closure | 🔴 CRITICAL | Missing useEffect dependency |
| Missing Cleanup | 🔴 CRITICAL | Subscription/timer with no teardown |
| Inline Object Prop | 🟡 MEDIUM | Object literal as prop breaks memoisation |
| Boolean Trap | 🔵 LOW | Ambiguous boolean flag props |
| Premature Memo | 🔵 LOW | useMemo/useCallback with no benefit |
| Async Without Abort | 🟠 HIGH | fetch in useEffect without AbortController |
| Conditional Hook | 🔴 CRITICAL | Hook called inside conditional |
| Zero Falsy Render | 🟠 HIGH | `{count && <X/>}` renders "0" |

### TypeScript Anti-Patterns
| Anti-Pattern | Severity | Description |
|---|---|---|
| Any Escape Hatch | 🟠 HIGH | Explicit `any` bypasses type checking |
| Unsafe Assertion | 🟠 HIGH | `as X` without runtime validation |
| Non-null Lie | 🟠 HIGH | `!` on a value that can be null/undefined |
| Manual Utility Type | 🔵 LOW | Re-implementing `Partial`, `Pick`, etc. |
| Semantic-free Generic | 🔵 LOW | Generic named `T` with no descriptive meaning |
| Const Enum Boundary | 🟡 MEDIUM | `const enum` across module boundaries |
| Implicit Return Type | 🔵 LOW | Exported function with no explicit return type |

### Node.js Anti-Patterns
| Anti-Pattern | Severity | Description |
|---|---|---|
| Sequential Await Loop | 🟠 HIGH | `await` inside `for` loop — serialises parallel ops |
| Floating Promise | 🟠 HIGH | Unhandled async call, no `.catch` or `await` |
| Sync in Async Context | 🟠 HIGH | `fs.readFileSync` in a request handler |
| Swallowed Error | 🔴 CRITICAL | Empty `catch {}` block |
| Hardcoded Secret | 🔴 CRITICAL | Credential in source file |
| Unvalidated Input | 🟠 HIGH | `req.body` used without schema validation |
| Missing Error Forward | 🟠 HIGH | Async Express handler without `next(e)` |
| Direct env Access | 🟡 MEDIUM | `process.env.X` without validation/typing |

---

## Phase 6 — Performance Analysis

### React Performance
- Identify components that always re-render when parent re-renders (missing `React.memo`)
- List all `useEffect` chains — effects that trigger state updates that trigger more effects
- Identify large list renders without windowing (`react-virtual`, `react-window`)
- Find context consumers that re-render on every context update but only use a slice of the context value → suggest splitting context or using selectors

### Node.js Performance
- Sequential awaits that could be `Promise.all` / `Promise.allSettled`
- N+1 query patterns — a query inside a loop or inside a `.map`
- Missing pagination on endpoints returning collections
- Synchronous operations (crypto, compression, parsing) on the main thread for large payloads → suggest worker threads

---

## Phase 7 — Accessibility (React UI)

Quick accessibility pass for every JSX file:

- `<img>` without `alt` → `CRITICAL`
- `onClick` on `<div>` or `<span>` without `role` and `tabIndex` → `HIGH`
- Form `<input>` without associated `<label>` or `aria-label` → `HIGH`
- Missing `aria-live` on dynamically updated regions
- Color conveyed as the only indicator of state (no text or icon alternative)
- Focus management missing after modal open/close or route change

---

## Phase 8 — Code Quality & Maintainability

- **Naming**: Variables named `data`, `result`, `temp`, `foo`, `item` — flag and suggest semantic names
- **Magic numbers**: Literal numbers in logic without named constants
- **Long functions**: Functions >40 lines — identify and suggest extraction points
- **Deep nesting**: More than 3 levels of indentation — flag for early return / extraction
- **Inconsistency**: Mixed `function` and arrow function declarations for the same pattern within a module
- **Import order**: Inconsistent import grouping (external → internal → relative → styles)
- **Barrel file over-export**: `index.ts` re-exporting everything — creates circular dependency risk

---

## Phase 9 — Remediation Plan Output

After completing all phases, produce **two outputs**:

### Output A — Inline Annotated Summary

Present findings grouped by file, then by phase. Use this format per finding:

```
[ITEM-NNN] 🔴 CRITICAL — Phase 2.2 (useEffect) — ComponentName.tsx:42
Pattern: Missing cleanup — subscription opened with no teardown function
Risk: Memory leak and stale event handler after component unmounts
```

Show a summary table at the top:
```
REVIEW SUMMARY
==============
Files reviewed : 6
Total findings : 24
  🔴 CRITICAL  : 3
  🟠 HIGH      : 8
  🟡 MEDIUM    : 7
  🔵 LOW       : 6
Estimated debt : ~4–6 hours
```

### Output B — REMEDIATION_PLAN.md (always create this file)

This is the persistent, machine-readable fix document. Structure it so every item
is self-contained — a future prompt can reference `ITEM-NNN` alone and receive
a correct fix without needing the original code in context.

```markdown
# Remediation Plan
<!-- Auto-generated by ui-code-review skill -->
<!-- Reference any item as: "Fix ITEM-NNN from the remediation plan" -->

Generated: [DATE]
Reviewed files: [LIST]

---

## Summary

| Total | 🔴 CRITICAL | 🟠 HIGH | 🟡 MEDIUM | 🔵 LOW |
|-------|------------|--------|----------|-------|
| 24    | 3          | 8      | 7        | 6     |

---

## ITEM-001
- **Severity**: 🔴 CRITICAL
- **File**: `src/hooks/useUserData.ts`
- **Line**: 18
- **Phase**: 2.2 — useEffect Correctness
- **Anti-Pattern**: Missing Cleanup
- **Description**: `useEffect` subscribes to a WebSocket but returns no cleanup function.
  The subscription remains open after the component unmounts, causing memory leaks and
  stale message handlers that fire against unmounted component state.
- **Current code**:
  ```ts
  useEffect(() => {
    const ws = new WebSocket(url);
    ws.onmessage = (e) => setMessages(prev => [...prev, e.data]);
  }, [url]);
  ```
- **Fix**:
  ```ts
  useEffect(() => {
    const ws = new WebSocket(url);
    ws.onmessage = (e) => setMessages(prev => [...prev, e.data]);
    return () => {
      ws.close();
    };
  }, [url]);
  ```
- **Why**: Without the cleanup, every re-render with a new `url` adds another open
  WebSocket. On unmount nothing is torn down. The teardown fn runs before the next
  effect and on unmount.

---

## ITEM-002
- **Severity**: 🟠 HIGH
- **File**: `src/api/users.ts`
- **Line**: 34
- **Phase**: 3.1 — Async/Await Correctness
- **Anti-Pattern**: Sequential Await Loop
- **Description**: `await` inside a `for...of` loop serialises 50+ database lookups
  that are independent and could run in parallel. At p50 latency of 20ms per query,
  this adds ~1 second of unnecessary serial wait time per request.
- **Current code**:
  ```ts
  for (const userId of userIds) {
    const user = await db.users.findById(userId);
    results.push(user);
  }
  ```
- **Fix**:
  ```ts
  const results = await Promise.all(
    userIds.map((userId) => db.users.findById(userId))
  );
  ```
- **Why**: `Promise.all` fires all queries concurrently. All resolve in the time
  of the slowest single query rather than the sum of all queries.

---

<!-- ... remaining items follow the same schema ... -->

---

## Fix Order (Recommended)

Apply fixes in this sequence to minimise risk of regressions:

1. **All CRITICAL items first** — these are bugs or security holes
2. **HIGH items by file** — group by file to avoid re-opening files
3. **MEDIUM items** — maintainability sweep
4. **LOW items** — final polish pass

## How to Use This Plan in Follow-Up Prompts

To fix a specific item, paste this plan into a new conversation alongside the relevant
file and say:

> "Here is my REMEDIATION_PLAN.md and here is [filename]. Please apply ITEM-NNN."

To fix all items in a file:

> "Here is my REMEDIATION_PLAN.md and here is [filename]. Apply all items for this file."

To fix all CRITICAL items:

> "Here is my REMEDIATION_PLAN.md and here is the full codebase. Apply all CRITICAL items."
```

---

## Reviewer Conduct Rules

1. **Never fix without explaining**. Every finding must state *why* it is a problem,
   not just *what* is wrong. Developers learn from context, not corrections alone.

2. **Never invent findings**. If a pattern is ambiguous, state the ambiguity.
   Do not assume a bug exists if the code is merely unusual.

3. **Always show the fix**. Every non-INFO finding must include corrected code.
   A problem report without a solution is noise.

4. **Respect intentional patterns**. If a pattern looks like an anti-pattern but
   has a plausible intentional reason (e.g. `as` assertion on a well-typed result
   from a library with poor types), note it as potentially intentional and ask.

5. **Prioritise impact**. Surface CRITICAL findings in the first paragraph of the
   summary — do not bury a security issue after 20 lines of naming suggestions.

6. **The remediation plan must always be produced**. Even for a single-file review
   with zero critical findings. A clean plan is still useful confirmation.

---

## Quick-Reference: Best Practice Rules by Layer

### TypeScript
- `strict: true` in `tsconfig.json` — non-negotiable baseline
- No `any` — use `unknown` and narrow, or generic constraints
- Explicit return types on all exported functions
- Prefer `interface` for extendable object shapes, `type` for unions/intersections
- Use utility types (`Partial`, `Pick`, `Omit`, `Readonly`) over manual re-implementation
- Prefer `satisfies` over `as` for type narrowing with inference retained
- Use `const` assertions for literal tuples and objects: `["a", "b"] as const`

### React
- One component per file
- Custom hooks for any stateful logic reused across 2+ components
- `useEffect` only for true synchronisation with external systems
- Derive state; do not store what can be computed
- Keys must be stable, unique, and not array indices for dynamic lists
- Memoize: `useCallback` for props passed to memo children; `useMemo` for expensive computations
- Always clean up: timers, subscriptions, event listeners
- Prefer composition (children, render props, compound components) over prop drilling

### Node.js
- Validate all inputs at the boundary (Zod, Joi, class-validator)
- Parameterise all queries — never concatenate SQL
- Use a config module that validates `process.env` at startup
- All async route handlers wrapped in try/catch with `next(e)` forwarding
- `Promise.all` for independent parallel async work
- No sync I/O (`readFileSync`, `execSync`) in request paths
- Structured logging (pino, winston) not raw `console.log`
- Secrets only from environment variables — never in source
