const esbuild = require("esbuild");
const isWatch = process.argv.includes("--watch");

const buildOptions = {
  entryPoints: ["src/extension.ts"],
  bundle: true,
  outfile: "dist/extension.js",
  external: ["vscode"],     // vscode is provided by the extension host
  format: "cjs",
  platform: "node",
  target: "node20",
  sourcemap: true,
  minify: !isWatch,
  logLevel: "info",
};

if (isWatch) {
  esbuild.context(buildOptions).then((ctx) => {
    ctx.watch();
    console.log("[esbuild] Watching for changes...");
  });
} else {
  esbuild.build(buildOptions).then(() => {
    console.log("[esbuild] Build complete ✅");
  }).catch(() => process.exit(1));
}
