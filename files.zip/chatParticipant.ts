import * as vscode from "vscode";
import {
  buildCopilotSystemContext,
  getComponents,
  getSaltInstallInfo,
  SaltComponent,
} from "./saltResolver";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type ChatHandler = Parameters<typeof vscode.chat.createChatParticipant>[1];

// ---------------------------------------------------------------------------
// Slash commands
// ---------------------------------------------------------------------------

const SLASH_COMMANDS = {
  component: "component",
  tokens: "tokens",
  migrate: "migrate",
  explain: "explain",
} as const;

// ---------------------------------------------------------------------------
// System prompt builder
// ---------------------------------------------------------------------------

async function buildSystemPrompt(): Promise<string> {
  const saltContext = await buildCopilotSystemContext();

  return `
You are an expert assistant for the Salt Design System by J.P. Morgan (@salt-ds).
Your job is to help developers choose the right Salt components, use correct 
design tokens, write accessible code, and follow Salt best practices.

${saltContext}

## Rules you MUST follow:
1. Always suggest components from the installed Salt version listed above — 
   never invent or hallucinate component names.
2. When generating code snippets, always include the correct import path 
   (@salt-ds/core or @salt-ds/lab) and wrap components in <SaltProvider>.
3. When comparing similar components (e.g. Dropdown vs ComboBox), clearly 
   explain the distinction and ask a clarifying question if unsure.
4. Always prefer semantic tokens (--salt-color-*, --salt-spacing-*) over 
   hardcoded values.
5. Always mention if a component is from @salt-ds/lab (unstable/preview).
6. When showing code, always use TypeScript + JSX syntax.
7. Format your responses with clear headings and code blocks.
8. If you don't know the answer from the context provided, say so — never 
   make up token names or component APIs.

## Tone:
- Concise but thorough
- Developer-friendly
- Always lead with the recommendation before the explanation
`.trim();
}

// ---------------------------------------------------------------------------
// Intent detection helpers
// ---------------------------------------------------------------------------

function detectAmbiguousComponents(
  prompt: string,
  components: SaltComponent[]
): string[] {
  // Ambiguous pairs / groups where the user might mean several things
  const ambiguousGroups = [
    ["Dropdown", "ComboBox", "MultiSelect"],
    ["Dialog", "Drawer", "Overlay"],
    ["Input", "Textarea", "NumberInput"],
    ["DatePicker", "DateInput"],
    ["Button"], // CTA vs Primary vs Secondary
    ["Tooltip", "Overlay"],
    ["NavigationItem", "Tabs"],
    ["Card", "Panel"],
  ];

  const lowerPrompt = prompt.toLowerCase();
  for (const group of ambiguousGroups) {
    const anyMatch = group.some(
      (name) =>
        lowerPrompt.includes(name.toLowerCase()) ||
        lowerPrompt.includes(name.toLowerCase().replace(/([A-Z])/g, " $1").trim())
    );
    if (anyMatch) {
      return group;
    }
  }

  // Also check if the prompt describes a concept that maps to multiple components
  const conceptMap: Record<string, string[]> = {
    dropdown: ["Dropdown", "ComboBox", "MultiSelect"],
    select: ["Dropdown", "ComboBox"],
    search: ["ComboBox", "Input"],
    modal: ["Dialog", "Drawer"],
    popup: ["Dialog", "Overlay", "Tooltip"],
    date: ["DatePicker", "DateInput"],
    number: ["NumberInput", "Input"],
    nav: ["NavigationItem", "Tabs"],
    navigation: ["NavigationItem", "Tabs"],
    card: ["Card", "Panel"],
    text: ["Input", "Textarea"],
  };

  for (const [concept, names] of Object.entries(conceptMap)) {
    if (lowerPrompt.includes(concept)) {
      return names;
    }
  }

  return [];
}

function buildClarificationQuestion(candidates: string[]): string {
  return (
    `I can see you might need one of these components: **${candidates.join(", ")}**.\n\n` +
    `To give you the best recommendation, could you tell me:\n` +
    `- Do you need the user to **type and filter** options, or just **select from a list**?\n` +
    `- Is **multi-selection** required?\n` +
    `- Is this inside a **form** with validation?\n\n` +
    `_(Or just describe your use case and I'll pick the right one for you!)_`
  );
}

// ---------------------------------------------------------------------------
// Slash command handlers
// ---------------------------------------------------------------------------

async function handleTokensCommand(
  stream: vscode.ChatResponseStream
): Promise<void> {
  stream.markdown("Opening Salt token picker...\n\n");

  // Trigger the token search quick-pick command registered in extension.ts
  await vscode.commands.executeCommand("salt-copilot.searchTokens");
}

async function handleMigrateCommand(
  request: vscode.ChatRequest,
  stream: vscode.ChatResponseStream,
  model: vscode.LanguageModelChat
): Promise<void> {
  stream.markdown(
    "## 🔄 Salt Lab → Core Migration\n\n" +
      "Scanning for `@salt-ds/lab` imports that have graduated to `@salt-ds/core`...\n\n"
  );

  const info = await getSaltInstallInfo();
  if (!info.isInstalled) {
    stream.markdown("⚠️ Salt is not installed in the current workspace.");
    return;
  }

  const components = await getComponents();
  const coreNames = new Set(
    components.filter((c) => c.source === "@salt-ds/core").map((c) => c.name)
  );
  const labNames = components
    .filter((c) => c.source === "@salt-ds/lab")
    .map((c) => c.name);

  // Find lab components that also exist in core (i.e. graduated)
  const graduated = labNames.filter((name) => coreNames.has(name));

  if (graduated.length === 0) {
    stream.markdown(
      "✅ No components found in `@salt-ds/lab` that have graduated to `@salt-ds/core` " +
        "in your current installation."
    );
    return;
  }

  stream.markdown(
    `Found **${graduated.length}** component(s) available in both packages:\n\n`
  );

  for (const name of graduated) {
    stream.markdown(`- \`${name}\` — move import to \`@salt-ds/core\`\n`);
  }

  stream.markdown(
    "\n\n**To migrate**, update your imports from:\n"
  );
  stream.markdown(
    "```ts\nimport { " +
      graduated.slice(0, 3).join(", ") +
      " } from '@salt-ds/lab';\n```\n\n"
  );
  stream.markdown(
    "to:\n\n```ts\nimport { " +
      graduated.slice(0, 3).join(", ") +
      " } from '@salt-ds/core';\n```\n\n"
  );
  stream.markdown(
    "> ⚠️ Always check the Salt changelog for breaking prop changes between lab and core versions."
  );
}

async function handleExplainCommand(
  request: vscode.ChatRequest,
  stream: vscode.ChatResponseStream,
  model: vscode.LanguageModelChat
): Promise<void> {
  // Get the active editor's selected text
  const editor = vscode.window.activeTextEditor;
  const selection = editor?.selection;
  const selectedText = editor?.document.getText(selection);

  if (!selectedText || selectedText.trim() === "") {
    stream.markdown(
      "Please select some Salt component code in your editor, then run `/explain` again."
    );
    return;
  }

  stream.markdown(`## 🔍 Explaining selected Salt code\n\n`);

  const systemPrompt = await buildSystemPrompt();
  const messages = [
    vscode.LanguageModelChatMessage.User(
      `${systemPrompt}\n\nExplain the following Salt Design System code. ` +
        `Describe what each component does, why the props are set the way they are, ` +
        `and any accessibility or best-practice notes:\n\n\`\`\`tsx\n${selectedText}\n\`\`\``
    ),
  ];

  const response = await model.sendRequest(messages, {});
  for await (const chunk of response.text) {
    stream.markdown(chunk);
  }
}

// ---------------------------------------------------------------------------
// Main chat handler
// ---------------------------------------------------------------------------

async function handleChatRequest(
  request: vscode.ChatRequest,
  _context: vscode.ChatContext,
  stream: vscode.ChatResponseStream,
  token: vscode.CancellationToken
): Promise<void> {
  // --- Slash commands ---
  if (request.command === SLASH_COMMANDS.tokens) {
    await handleTokensCommand(stream);
    return;
  }

  // Select the best available language model
  const models = await vscode.lm.selectChatModels({
    vendor: "copilot",
    family: "gpt-4o",
  });

  if (!models || models.length === 0) {
    stream.markdown(
      "⚠️ No Copilot language model available. Please make sure GitHub Copilot is installed and signed in."
    );
    return;
  }

  const model = models[0];

  if (request.command === SLASH_COMMANDS.migrate) {
    await handleMigrateCommand(request, stream, model);
    return;
  }

  if (request.command === SLASH_COMMANDS.explain) {
    await handleExplainCommand(request, stream, model);
    return;
  }

  // --- General / component recommendation flow ---
  const userPrompt = request.prompt.trim();

  if (!userPrompt) {
    stream.markdown(
      "👋 Hi! I'm your **Salt Design System** assistant. Ask me:\n\n" +
        "- *Which component should I use for X?*\n" +
        "- *Show me how to build a form with Salt*\n" +
        "- *What's the difference between Dropdown and ComboBox?*\n\n" +
        "Or use a slash command:\n" +
        "- `/component` — get a component recommendation\n" +
        "- `/tokens` — search and copy Salt tokens\n" +
        "- `/migrate` — find lab → core upgrade opportunities\n" +
        "- `/explain` — explain selected Salt code\n"
    );
    return;
  }

  // Check for ambiguous component intent before calling the LLM
  const components = await getComponents();
  const ambiguous = detectAmbiguousComponents(userPrompt, components);

  if (ambiguous.length > 1 && !containsDisambiguationHint(userPrompt)) {
    stream.markdown(buildClarificationQuestion(ambiguous));
    return;
  }

  // Build messages for the LLM
  const systemPrompt = await buildSystemPrompt();

  const messages = [
    vscode.LanguageModelChatMessage.User(
      `${systemPrompt}\n\nUser question: ${userPrompt}`
    ),
  ];

  // Stream the response
  try {
    const response = await model.sendRequest(messages, {}, token);
    for await (const chunk of response.text) {
      if (token.isCancellationRequested) {
        break;
      }
      stream.markdown(chunk);
    }
  } catch (err: any) {
    if (err instanceof vscode.LanguageModelError) {
      stream.markdown(
        `\n\n⚠️ Language model error: ${err.message}. ` +
          `Code: \`${err.code}\``
      );
    } else {
      throw err;
    }
  }
}

/**
 * Returns true if the prompt already contains enough context to disambiguate
 * (e.g. mentions "multi", "search", "type", "filter").
 */
function containsDisambiguationHint(prompt: string): boolean {
  const hints = [
    "multi",
    "search",
    "filter",
    "type",
    "select multiple",
    "single select",
    "typeahead",
    "autocomplete",
    "form",
    "modal",
    "side panel",
    "inline",
  ];
  const lower = prompt.toLowerCase();
  return hints.some((h) => lower.includes(h));
}

// ---------------------------------------------------------------------------
// Registration helper
// ---------------------------------------------------------------------------

export function registerChatParticipant(
  context: vscode.ExtensionContext
): void {
  const participant = vscode.chat.createChatParticipant(
    "salt.assistant",
    handleChatRequest as ChatHandler
  );

  participant.iconPath = new vscode.ThemeIcon("symbol-color");

  // Register slash commands
  participant.followupProvider = {
    provideFollowups(
      _result: vscode.ChatResult,
      _context: vscode.ChatContext,
      _token: vscode.CancellationToken
    ): vscode.ChatFollowup[] {
      return [
        {
          prompt: "",
          command: SLASH_COMMANDS.tokens,
          label: "$(symbol-color) Browse Salt tokens",
        },
        {
          prompt: "",
          command: SLASH_COMMANDS.migrate,
          label: "$(arrow-up) Check for lab → core migrations",
        },
        {
          prompt: "Show me an example with SaltProvider",
          label: "$(code) Show SaltProvider setup",
        },
      ];
    },
  };

  context.subscriptions.push(participant);
}
