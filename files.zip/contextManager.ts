import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';

export type ContextItemType = 'file' | 'selection' | 'terminal' | 'manual' | 'folder';

export interface ContextItem {
  id: string;
  type: ContextItemType;
  label: string;
  description: string;
  content: string;
  filePath?: string;
  lineStart?: number;
  lineEnd?: number;
  language?: string;
  tokenCount: number;
  addedAt: Date;
  pinned: boolean;
}

export interface ContextStats {
  totalTokens: number;
  maxTokens: number;
  itemCount: number;
  fileCount: number;
  selectionCount: number;
  usagePercent: number;
}

// Rough token estimator: ~4 chars per token for code, ~5 for prose
function estimateTokens(text: string): number {
  return Math.ceil(text.length / 3.8);
}

function makeId(): string {
  return `ctx_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

export class ContextManager {
  private items: Map<string, ContextItem> = new Map();
  private readonly MAX_TOKENS = 200_000; // Claude's context window
  private _onChange = new vscode.EventEmitter<void>();
  readonly onDidChange = this._onChange.event;

  getItems(): ContextItem[] {
    return [...this.items.values()].sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      return b.addedAt.getTime() - a.addedAt.getTime();
    });
  }

  getStats(): ContextStats {
    const items = this.getItems();
    const totalTokens = items.reduce((s, i) => s + i.tokenCount, 0);
    return {
      totalTokens,
      maxTokens: this.MAX_TOKENS,
      itemCount: items.length,
      fileCount: items.filter(i => i.type === 'file').length,
      selectionCount: items.filter(i => i.type === 'selection').length,
      usagePercent: Math.min(100, (totalTokens / this.MAX_TOKENS) * 100),
    };
  }

  async addFile(uri: vscode.Uri): Promise<ContextItem | null> {
    const filePath = uri.fsPath;

    // Check if already added
    for (const item of this.items.values()) {
      if (item.filePath === filePath && item.type === 'file') {
        vscode.window.showInformationMessage(`File already in context: ${path.basename(filePath)}`);
        return null;
      }
    }

    let content: string;
    try {
      content = fs.readFileSync(filePath, 'utf8');
    } catch {
      vscode.window.showErrorMessage(`Could not read file: ${filePath}`);
      return null;
    }

    const language = this.detectLanguage(filePath);
    const tokenCount = estimateTokens(content);
    const relPath = vscode.workspace.asRelativePath(uri);

    const item: ContextItem = {
      id: makeId(),
      type: 'file',
      label: path.basename(filePath),
      description: relPath,
      content,
      filePath,
      language,
      tokenCount,
      addedAt: new Date(),
      pinned: false,
    };

    this.items.set(item.id, item);
    this._onChange.fire();
    return item;
  }

  async addSelection(editor: vscode.TextEditor): Promise<ContextItem | null> {
    const selection = editor.selection;
    if (selection.isEmpty) {
      vscode.window.showWarningMessage('No text selected.');
      return null;
    }

    const content = editor.document.getText(selection);
    const filePath = editor.document.uri.fsPath;
    const relPath = vscode.workspace.asRelativePath(editor.document.uri);
    const lineStart = selection.start.line + 1;
    const lineEnd = selection.end.line + 1;
    const language = editor.document.languageId;

    const item: ContextItem = {
      id: makeId(),
      type: 'selection',
      label: `${path.basename(filePath)}:${lineStart}-${lineEnd}`,
      description: `${relPath} · lines ${lineStart}–${lineEnd}`,
      content,
      filePath,
      lineStart,
      lineEnd,
      language,
      tokenCount: estimateTokens(content),
      addedAt: new Date(),
      pinned: false,
    };

    this.items.set(item.id, item);
    this._onChange.fire();
    return item;
  }

  addManual(label: string, content: string): ContextItem {
    const item: ContextItem = {
      id: makeId(),
      type: 'manual',
      label,
      description: 'Manual note',
      content,
      tokenCount: estimateTokens(content),
      addedAt: new Date(),
      pinned: false,
    };
    this.items.set(item.id, item);
    this._onChange.fire();
    return item;
  }

  remove(id: string): void {
    this.items.delete(id);
    this._onChange.fire();
  }

  togglePin(id: string): void {
    const item = this.items.get(id);
    if (item) {
      item.pinned = !item.pinned;
      this._onChange.fire();
    }
  }

  clear(): void {
    const pinned = [...this.items.values()].filter(i => i.pinned);
    this.items.clear();
    for (const p of pinned) this.items.set(p.id, p);
    this._onChange.fire();
  }

  clearAll(): void {
    this.items.clear();
    this._onChange.fire();
  }

  getItem(id: string): ContextItem | undefined {
    return this.items.get(id);
  }

  exportAsText(): string {
    const items = this.getItems();
    const stats = this.getStats();
    const lines: string[] = [
      `# Chat Context Export`,
      `Generated: ${new Date().toISOString()}`,
      `Items: ${stats.itemCount} | Estimated tokens: ${stats.totalTokens.toLocaleString()}`,
      '',
    ];

    for (const item of items) {
      lines.push(`## ${item.label}`);
      if (item.description) lines.push(`> ${item.description}`);
      lines.push('');
      lines.push('```' + (item.language || ''));
      lines.push(item.content);
      lines.push('```');
      lines.push('');
    }

    return lines.join('\n');
  }

  private detectLanguage(filePath: string): string {
    const ext = path.extname(filePath).slice(1).toLowerCase();
    const map: Record<string, string> = {
      ts: 'typescript', tsx: 'tsx', js: 'javascript', jsx: 'jsx',
      py: 'python', rs: 'rust', go: 'go', java: 'java', kt: 'kotlin',
      cs: 'csharp', cpp: 'cpp', c: 'c', h: 'c', rb: 'ruby',
      php: 'php', swift: 'swift', sh: 'bash', bash: 'bash',
      md: 'markdown', json: 'json', yaml: 'yaml', yml: 'yaml',
      toml: 'toml', html: 'html', css: 'css', scss: 'scss',
      sql: 'sql', r: 'r', lua: 'lua', zig: 'zig', dart: 'dart',
    };
    return map[ext] || ext || 'plaintext';
  }
}
