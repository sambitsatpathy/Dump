# Screen Descriptions — Spec Visualizer & Workflow Editor (Salt DS) (Merged)

> **Document history:** v1 defined the initial screen designs; v2 added new screens and updated existing ones to reflect versioning mechanics, comments, notifications, category schemas, and swim lanes. This file is the single authoritative screen spec. v2 takes precedence wherever screens diverge.

---

## Changes Incorporated from v2

| Change | Driven by |
|---|---|
| Notification center drawer + bell behaviour defined | Notifications (Phase 4) |
| Canvas search bar + filter chip rail added to Flow View | Canvas search and filters (Phase 2) |
| Swim lanes promoted from polish to core Flow View | Swim lanes moved to Phase 2 |
| Node cards gain "newer version" + comment count badges | Versioning mechanics + comments |
| Property editor shows inline schema validation errors | Category schemas (Phase 2) |
| Version tab redesigned for versions-array model | Versioning mechanics |
| Review panel shows "from previous review" comment flag | Comments data model |
| New screen: Notification Center | Notifications |
| New screen: Workflow Upgrade Dialog | Explicit re-pin action |
| New screen: Scoped Role Editor (Admin) | Scope-aware roles |
| New screen: Orphaned Comments Panel | Comments model |

---

## Design Direction

**Aesthetic: Data / Financial**
`density="high"` · `mode="dark"` · Near-monochrome surfaces, tight gaps, tabular rhythm.

This is a governance and authoring tool used by technical makers and checkers. High density keeps the canvas productive. Dark mode reduces eye strain on long editing sessions. `SaltProvider` wraps the entire app with these settings. Open Sans is the body font; PT Mono is used for version strings, IDs, and JSON diff views.

---

## 1. App Shell

**Pattern: App Shell / Navigation Shell (Pattern #1)**

The shell uses `SplitLayout` for the top bar and `StackLayout direction="row"` for the body zone.

**Top bar** — a full-width `SplitLayout` with `borderBottom` using `var(--salt-separable-primary-borderColor)` and background `var(--salt-container-secondary-background)`. Height is `var(--salt-size-base)`. Left `startItem`: app wordmark as `<H4>` + `<Breadcrumbs>` from `@salt-ds/lab` showing `MyApp / Workflows / submit-order`.

Right `endItem`: a `<Chip>` showing the user's role (e.g. `maker`), a **notification bell** `<Button appearance="transparent">` using `<NotificationIcon />` with a small numeric `<Badge>` for unread count positioned top-right of the icon (hidden when count is zero), and a `<Button appearance="transparent">` for the avatar.

Clicking the bell opens the Notification Center drawer (Screen 10). The bell badge count updates in real time from the backend as events occur.

**Left sidebar** — a `<StackLayout direction="column">` 220px wide using `var(--salt-separable-primary-borderColor)` as a right border. Uses `<NavigationItem>` from `@salt-ds/core` for each section. Active item uses the `active` prop. Section group labels use `<Text styleAs="label">` in `var(--salt-content-secondary-foreground)`. Navigation items: Home, Workflows, Nodes, Review Queue, Notifications, Admin (admin role only).

**Body** — `<StackLayout direction="row" style={{ flex: 1 }}>` with the canvas taking remaining space and a collapsible right `<Drawer position="right">` from `@salt-ds/lab` for the property editor.

---

## 2. Home / App Overview Screen

**Pattern: Dashboard Layout (Pattern #2) + Breadcrumb + Page Header (Pattern #18)**

Top of content area: `<PageHeader>` using `<Breadcrumbs>` + `<H2>` for the app name + `<Text styleAs="notation">` for the last-updated timestamp.

Below that, a KPI row using `<GridLayout columns={4} gap={2}>` with four `<Card>` components — one each for total workflows, total nodes, pending review count, and approved count. Each card has a `<Text styleAs="label">` caption and `<H3>` value. The "pending review" card uses a `<StatusIndicator status="warning" />` inline with the count.

The main canvas area below renders the Workflow View. Each workflow cluster is a `<Card>` rendered inside React Flow as a custom node, background `var(--salt-container-secondary-background)`, with a `<StatusIndicator>` badge in the top-right corner. Edges between clusters are React Flow edges styled with `var(--salt-separable-primary-borderColor)`.

The **Load Spec** button is a `<Button appearance="bordered">` using `<UploadIcon />` in the bottom-left. The **Export** button is a `<Button sentiment="accented">` in the bottom-right.

---

## 3. Flow View (Workflow Canvas)

**Patterns: Vertical Navigation Rail (#17) + Slide-in Drawer (#12) + Tabs-based Content Panel (#13) + Filterable List / Search + Results (#10)**

### Canvas filter rail

A horizontal `<FlowLayout gap={2}>` rail sits directly above the canvas area, below the breadcrumb header, using `var(--salt-container-secondary-background)` with a bottom border.

Contents, left to right:

- A `<Input>` with `<SearchIcon />` as start adornment, `aria-label="Search canvas"`, 280px wide. Searches node labels, tags, descriptions, and IDs. Matching nodes are highlighted on canvas; non-matching nodes dim to `opacity: 0.3`.
- A `<Dropdown>` for status filter: All, Draft, Submitted, In Review, Approved, Changes Requested, Rejected. Multi-select.
- A `<Dropdown>` for category filter: All, UI, Logic, Infra, Data, External. Multi-select.
- A `<Dropdown>` for tag filter — populated from tags present in the loaded spec. Multi-select.
- A `<ToggleButton>` group for view mode: "Standard" | "Swim lanes".
- A `<Button appearance="transparent">` with `<RefreshIcon />` labelled "Clear filters" — enabled only when any filter is active.

Active filters render below the rail as dismissable `<Chip onClose={...}>` pills so the user can see at a glance what's filtering the view.

### Swim lanes

When "Swim lanes" is selected on the view toggle, the canvas divides into horizontal bands, one per category. Lanes are rendered as React Flow background regions with:

- A left-edge label using `<Text styleAs="label">` with the category name in `var(--salt-content-secondary-foreground)`.
- A lane separator line using `var(--salt-separable-secondary-borderColor)`.
- Lane background alternates subtly between `var(--salt-container-primary-background)` and `var(--salt-container-secondary-background)` for readability.

Nodes automatically position within their category's lane. Dagre auto-layout respects lane boundaries. Edges crossing lanes are allowed and styled identically to in-lane edges.

### Left palette sidebar

`<StackLayout direction="column" gap={0}>` using the Vertical Navigation Rail pattern. A `<Input>` with `<SearchIcon />` as a start adornment sits at the top — this searches the node palette (distinct from the canvas search rail above). Below it, category sections use `<Accordion>` from `@salt-ds/lab`, one per category (`UI`, `Logic`, `Infra`, `Data`, `External`). Each item inside is a draggable row: `<StackLayout direction="row" gap={2} align="center">` with a small colored `<StatusIndicator>` (repurposed as a category dot) and a `<Text>` label.

Dragging a node onto the canvas creates a new workflow ref pinned to the **latest APPROVED version** of that node. If no APPROVED version exists, the drag is prevented and a `<Tooltip>` explains why.

### Canvas nodes

Custom React Flow node components built from `<Card>` with:

- Left border colored by category using a CSS variable override scoped to the node.
- `<StackLayout direction="row" justify="space-between">` header row:
  - Left: `<Text styleAs="label">` for the node label + a small PT Mono `<Text styleAs="notation">` showing the pinned version (e.g. `v1.1.0`).
  - Right: a `<Chip>` for the lifecycle status (using `<StatusIndicator>` + text).
- Below the header: `<FlowLayout gap={1}>` of tag `<Chip appearance="transparent">` components.
- **Bottom-right badge row:** `<FlowLayout gap={1}>` containing:
  - **Newer-version indicator** — a small `<Chip appearance="bordered" sentiment="positive">` labelled "↑ v1.2.0 available" when the node has a newer APPROVED version than the one this workflow pins to. Clicking opens the Workflow Upgrade Dialog (Screen 11).
  - **Comment count badge** — a `<Chip>` with a `<MessageIcon />` and the unresolved comment count (e.g. "3"). Hidden when zero. Clicking scrolls the right drawer to the Comments tab for that version.
- **REJECTED** nodes additionally show a `<Tooltip>` on a `<MessageIcon />` button — the tooltip content is the reviewer's most recent comment.

**Status chip color mapping** via `StatusIndicator` status prop:

| Status | Salt `status` prop | Token |
|---|---|---|
| DRAFT | `info` | `--salt-status-info-background` |
| SUBMITTED | `info` | custom accent |
| IN REVIEW | `warning` | `--salt-status-warning-background` |
| APPROVED | `success` | `--salt-status-success-background` |
| CHANGES REQUESTED | `warning` | `--salt-status-warning-background` |
| REJECTED | `error` | `--salt-status-error-background` |

### Floating toolbar

A `<Card>` with `var(--salt-overlayable-shadow)` elevation floating above the canvas. `<StackLayout direction="row" gap={1}>` of `<Button appearance="transparent">` buttons for Select, Pan, Add Edge, Add Node, Auto-layout, Undo, Redo. Active tool button uses `appearance="solid"`.

### Right property panel

A `<Drawer position="right">` from `@salt-ds/lab`. Inside, `<Tabs>` + `<Tab>` components for **Details**, **Properties**, **Lifecycle**, **Comments**, and **Version** tabs.

**Details tab** — Single Column Form Layout with `<FormField>` + `<FormFieldLabel>` + `<Input>` / `<Textarea>` for id (read-only, PT Mono), label, description, tags, category.

**Properties tab** — a key-value editor using `<Grid>` from `@salt-ds/data-grid` with inline editing. For categories with a registered schema:

- Known keys appear first, rendered as typed controls (`<Dropdown>` for enums, `<Input type="number">` for numbers, `<Checkbox>` for booleans).
- Invalid values render with `<FormFieldHelperText validationStatus="error">` showing the schema violation message.
- A `<StatusIndicator status="error" />` appears in the tab header when any field fails validation.
- Unknown keys still render below the known keys (freeform preserved).
- A `<Text styleAs="notation">` footer reads "Schema: /specs/schemas/ui.schema.json" with a link icon to open the schema file.

For unschematized categories, the grid is pure freeform key-value pairs.

Saving a DRAFT with any validation error is blocked. A `<Dialog>` appears explaining the errors and offering "Fix now" (returns to the Properties tab with the first error focused) or "Discard changes".

**Lifecycle tab** — read-only summary of the current version's lifecycle record. Shows status, submittedBy, submittedAt, reviewedBy, reviewedAt, and action buttons appropriate to the current state (Submit for Review, Withdraw Submission, etc.).

**Comments tab** — lists all unresolved comments on the currently displayed version. Each is a `<Card>` with author avatar, timestamp, body, and inline reply. Comments from a previous review cycle carry a `<Chip appearance="bordered" sentiment="caution">from previous review</Chip>` label. An "Add comment" `<Textarea>` + `<Button>` sits at the bottom. A `<Dropdown>` at the top lets the user switch between "Unresolved", "All", and "Orphaned" views.

**Version tab** — reflects the versions-array model:

- A `<StackLayout direction="column" gap={2}>` list of all versions on this spec file.
- Each version is a `<Card>` with:
  - Header `<SplitLayout>`: left shows `<Label>` version in PT Mono + `<StatusIndicator>` + lifecycle status; right shows an overflow `<Menu>` with "View at this version", "Compare to…", "Duplicate as new DRAFT" (visible for APPROVED versions only when no DRAFT exists).
  - Body shows submittedBy, reviewedBy, reviewedAt as `<Text styleAs="notation">`.
  - A short `<Text>` description snippet.
- A "Compare versions" `<Button appearance="bordered">` at the top opens a dialog where the user picks two versions and sees the diff (same UI as the Review Panel diff).

### Minimap

Bottom-right, rendered natively by React Flow with a border using `var(--salt-separable-secondary-borderColor)` and background `var(--salt-container-tertiary-background)`.

---

## 4. Node Detail View

**Pattern: Slide-in Drawer / Side Panel (#12) + Tabs-based Content Panel (#13)**

A `<Drawer position="right">` at a wider breakpoint (640px) overlaying the canvas. The drawer header uses `<SplitLayout>` — left: `<H3>` node label + `<Chip>` status badge + PT Mono version string; right: `<Button appearance="transparent">` close icon.

The **Version tab** expands the changelog into a full diff view. Diffs are computed between each version and its immediate predecessor in the `versions` array. Each version transition is shown as a before/after `<Card>` pair inside a `<GridLayout columns={2} gap={2}>`. Diff content uses `<Text styleAs="notation">` rendered in PT Mono (`font-family: var(--salt-text-code-fontFamily)`). Added lines use `var(--salt-status-success-foreground)`, removed lines use `var(--salt-status-error-foreground)`, unchanged lines use `var(--salt-content-secondary-foreground)`.

---

## 5. Maker-Checker — Submission Queue

**Pattern: Data Grid / Table (#3) + Filterable List / Search + Results (#10)**

**Page header** uses Breadcrumb + Page Header pattern (#18): `<Breadcrumbs>` + `<H2>Review Queue</H2>` + `<Text styleAs="notation">` showing pending count.

Filter bar: `<FlowLayout gap={2}>` containing a `<Input startAdornment={<SearchIcon />}>`, a `<Dropdown>` for status filter, a `<Dropdown>` for type filter (node / workflow), a `<Dropdown>` for submitter, and a `<Dropdown>` for category scope (when the checker has a scoped role, the list is restricted to their scope by default but the dropdown lets them widen if permissions allow). All wrapped in `<FormField>` components with `aria-label` only (no visible labels in this inline filter bar context).

Main table uses `<Grid>` from `@salt-ds/data-grid` with `density="high"`. Columns: Name, Type, Version (PT Mono font via cell renderer), Submitted By, Submitted At, Status. The Status column renders a `<StatusIndicator>` + `<Text>` chip inline. Clicking a row opens the Review Panel as a `<Drawer>`.

---

## 6. Review Panel

**Pattern: Master-Detail Layout (#4) + Dialog / Confirmation Modal (#11)**

Activated from the queue. A full-height `<Drawer position="right">` at 60% viewport width. The drawer header: `<SplitLayout>` with spec name + version in `<H3>`, and three action buttons right-aligned: `<Button sentiment="accented">Approve</Button>`, `<Button sentiment="caution" appearance="bordered">Request Changes</Button>`, `<Button sentiment="negative" appearance="bordered">Reject</Button>`.

**Blocking dependency panel** — if the spec under review is a workflow, a `<Card>` at the top of the body lists all node refs with their pinned versions and current lifecycle status. Any non-APPROVED reference is highlighted with `<StatusIndicator status="error" />` and the Approve button is disabled with a `<Tooltip>` explaining why.

The drawer body: `<GridLayout columns={2} gap={0}>` splitting into the previous APPROVED version (left) and incoming version (right). Column headers use `<Text styleAs="label">` in `var(--salt-content-secondary-foreground)` — "v1.1.0 (current APPROVED)" and "v1.2.0 (incoming)". Each side renders the spec fields as read-only `<FormField>` blocks. Diffed lines use the same color scheme as Node Detail (green / red / muted).

**Comment thread** below the diff: a `<StackLayout direction="column" gap={2}>` of comment bubbles, each a `<Card>` with `<Text styleAs="label">` for author + timestamp and `<Text>` for the comment body. Comments carried over from a previous review cycle render with a `<Chip appearance="bordered" sentiment="caution">from previous review</Chip>` inline with the author line; the maker can mark each as "Resolved" with a small `<Button appearance="transparent">`. A `<Textarea>` with `<FormFieldLabel>Add comment</FormFieldLabel>` and a `<Button appearance="solid">Submit</Button>` sit at the bottom; each comment can optionally anchor to a specific field via a `<Dropdown>` labelled "Attach to:".

**Approve / Reject / Request Changes** each trigger a `<Dialog>` (Pattern #11) confirming the action. Non-approvals require a `<Textarea>` comment inside the dialog before the confirm `<Button>` becomes enabled (`disabled` prop controlled by empty-state check).

---

## 7. Version History Viewer

**Pattern: Tabs-based Content Panel (#13) + Master-Detail Layout (#4)**

Accessible from the Version tab of the property panel or node detail drawer. A vertical timeline built from `<StackLayout direction="column" gap={0}>`. Each version entry is a `<Card>` with a left-border accent. Layout inside: `<SplitLayout>` — left: `<Label>` version in PT Mono + `<Text styleAs="notation">` author and date; right: `<StatusIndicator>` + lifecycle status at that version.

Selecting two entries (via `<Checkbox>` on each row) enables a `<Button appearance="bordered">Compare versions</Button>` that opens the same diff UI as the Review Panel inside a `<Dialog>`.

---

## 8. Export Modal

**Pattern: Dialog / Confirmation Modal (#11) + Tabs-based Content Panel (#13)**

Triggered by the Export button. A `<Dialog>` with `aria-labelledby` pointing to `<H2>Export Spec</H2>`.

Two primary `<Tab>` labels: **Full**, **Approved Only**. A third **Delta** tab is present but rendered with a `<Chip appearance="bordered" sentiment="caution">Experimental</Chip>` next to its label — reflecting its stretch-goal status.

**Full / Approved Only tab**: a `<FormField>` with `<FormFieldLabel>Scope</FormFieldLabel>` containing a `<Dropdown>` (Entire app / Specific workflow / Specific node). A `<RadioButtonGroup>` for format: JSON or YAML (YAML marked "beta"). Below that, a read-only `<Textarea>` styled with PT Mono font showing the file tree preview. `<DialogActions>` contains `<Button sentiment="accented">Download ZIP</Button>` + `<Button appearance="bordered">Cancel</Button>`.

**Delta tab**: two `<Dropdown>` components inside a `<GridLayout columns={2} gap={3}>` for "From version" and "To version". Same scope picker. A `<Card>` below previews the delta structure as formatted JSON using PT Mono, with added/removed indicators matching the diff color tokens. `<Button sentiment="accented">Download Delta</Button>`. A `<Banner>` at the top of the tab reads: "Delta export is experimental. Most AI coding agents currently work from full specs; please validate that your target agent benefits from deltas before relying on this export."

---

## 9. Import / Load Screen

**Pattern: File Upload Drop Zone (#16) + Empty State (#8)**

A centred `<Card>` using `var(--salt-overlayable-shadow)` elevation, `maxWidth: 560px`. Inside: `<StackLayout direction="column" gap={4} align="center">`.

Heading: `<H2>Load a Spec</H2>` + `<Text>` subtitle.

Drop zone: `<FileDropZone>` from `@salt-ds/lab` with `<FileDropZoneIcon />` + `<Text>Drop your spec folder or ZIP here</Text>` + `<FileDropZoneTrigger>` with `accept=".zip,.json"` label "or browse files".

After loading, the card expands to show a validation report. Resolved references use `<StatusIndicator status="success" />` + `<Text>`. Warnings use `status="warning"`. Errors use `status="error"`. The list is rendered as a `<StackLayout direction="column" gap={1}>` of inline `<StatusIndicator>` + `<Text>` rows.

**Schema violations** appear with `status="error"` and include the file path, category, property path, and violation message in PT Mono. **Orphaned comments** appear with `status="warning"` and include a link to the Orphaned Comments Panel.

A `<Button sentiment="accented" disabled={hasErrors}>Open in Canvas</Button>` sits below the report — enabled only when there are no blocking errors.

---

## 10. Notification Center *(new in v2)*

**Pattern: Slide-in Drawer / Side Panel (#12) + Filterable List / Search + Results (#10)**

Triggered by the bell icon in the top bar. A `<Drawer position="right">` at 420px width.

**Header** — `<SplitLayout>`: left is `<H3>Notifications</H3>` + an unread count in parentheses; right is a `<Button appearance="transparent">` for "Mark all read" and a close icon.

**Filter row** — a `<FlowLayout gap={2}>` with a `<ToggleButton>` group: All / Unread / Mentions, and a `<Dropdown>` for event type filter (Submission, Approval, Rejection, Changes Requested, Comment, Upgrade Available).

**List body** — a `<StackLayout direction="column" gap={0}>` of notification rows. Each row is a `<Card>` with:

- Left: a category dot using `<StatusIndicator>` matching the event type.
- Middle: `<Text styleAs="label">` with the event title (e.g. "alice submitted order-form v1.2.0 for review") and `<Text styleAs="notation">` relative timestamp.
- Right: an overflow `<Menu>` with "Mark read", "Open spec", "Mute this spec".
- Unread rows carry a subtle `var(--salt-status-info-background)` left-edge accent; read rows fade to `var(--salt-content-secondary-foreground)`.

Clicking a row marks it read, closes the drawer, and navigates to the relevant spec on the canvas or into the Review Panel as appropriate.

**Empty state** uses Pattern #8 with `<NotificationIcon />` and "You're all caught up."

---

## 11. Workflow Upgrade Dialog *(new in v2)*

**Pattern: Dialog / Confirmation Modal (#11)**

Triggered by the "↑ v1.2.0 available" chip on a node inside an open workflow, or by a "Check for node upgrades" action in the workflow's overflow menu.

A `<Dialog>` with `<H2>Upgrade node version</H2>`.

**Body** — uses `<GridLayout columns={2} gap={3}>`:

- Left `<Card>`: the currently pinned version. Header `<SplitLayout>`: `<Label>` with version in PT Mono + `<StatusIndicator>` + "APPROVED". Body shows a condensed field summary.
- Right `<Card>`: the proposed version. `<Dropdown>` at the top lets the user pick any APPROVED version newer than the current one. Body shows the same condensed field summary for comparison.

Below the cards, a `<Banner sentiment="caution">` reads: "Upgrading will create a new DRAFT version of this workflow. The current workflow version remains unchanged until the new DRAFT is approved."

If the upgrade involves a **major bump**, a second `<Banner sentiment="negative">` appears: "This is a major version bump. Review breaking changes carefully." with a link to the full diff.

`<DialogActions>` — `<Button sentiment="accented">Create DRAFT with upgrade</Button>` + `<Button appearance="bordered">Cancel</Button>`.

---

## 12. Scoped Role Editor — Admin Settings *(new in v2)*

**Pattern: Data Grid / Table (#3) + Dialog / Confirmation Modal (#11)**

Accessible only to users with the `admin` role, via the Admin nav item.

**Page header** — `<PageHeader>` with `<Breadcrumbs>` + `<H2>Roles & Permissions</H2>`.

**Main table** — `<Grid>` from `@salt-ds/data-grid` with `density="high"`. Columns: User, Role, Scope (rendered as a `<Chip>` showing scope type — "Global", "Category: infra", "Workflow: submit-order"), Assigned By, Assigned At, Actions. The Actions cell renders a `<Menu>` with "Edit", "Remove".

Above the table: a `<Button sentiment="accented">Add assignment</Button>`.

**Add / Edit Assignment dialog** — a `<Dialog>` with:

- `<FormField>` + `<Dropdown>` for User (searchable).
- `<FormField>` + `<Dropdown>` for Role (maker / checker / viewer / admin).
- `<FormField>` + `<RadioButtonGroup>` for Scope type: Global / Category / Workflow.
- Conditional `<Dropdown>` for the specific category or workflow if not Global.
- `<Banner sentiment="info">` at the bottom: "Global admin assignments override all scopes and can force-approve any spec. Grant sparingly."

`<DialogActions>`: `<Button sentiment="accented">Save</Button>` + `<Button appearance="bordered">Cancel</Button>`.

Removing an assignment triggers a confirmation `<Dialog>` using Pattern #11.

---

## 13. Orphaned Comments Panel *(new in v2)*

**Pattern: Filterable List / Search + Results (#10) + Empty State (#8)**

Accessible from the Comments tab dropdown ("Orphaned" option), from the import validation report when orphans are detected, and as a standalone nav item per spec file.

**Header** — `<H3>Orphaned Comments</H3>` + `<Text styleAs="notation">` explaining what orphaned means ("Comments whose original target — a node, edge, or property — no longer exists in any version of this spec.").

**Filter row** — a `<FlowLayout gap={2}>` with a `<Input>` search box and a `<Dropdown>` for target type (node / edge / property / whole-spec).

**Body** — a `<StackLayout direction="column" gap={2}>` of orphaned comment `<Card>`s. Each card:

- Header `<SplitLayout>`: left is `<Text styleAs="label">` with the comment author + timestamp; right is an overflow `<Menu>` with "Archive", "Re-attach to…", "View original target path".
- Body shows the comment text and any replies (read-only; orphaned comments cannot be replied to).
- A `<Text styleAs="notation">` footer shows the original target path in PT Mono (e.g. `properties.validation.required` on version 1.1.0).

**Empty state** uses Pattern #8 with `<MessageIcon />` and "No orphaned comments."

---

## Key Constraints (All Screens)

- **No hardcoded hex colors** — status colors exclusively via `var(--salt-status-*)` tokens
- **No hardcoded px spacing** — all gaps and padding via `var(--salt-spacing-*)` tokens (except fixed drawer/sidebar widths)
- **No raw HTML form elements** — `<Input>`, `<Textarea>`, `<Dropdown>`, `<Checkbox>`, `<RadioButton>` from `@salt-ds/core` only
- **All layout** via `StackLayout` / `GridLayout` / `FlowLayout` / `SplitLayout` — no raw div flex
- **Version strings and IDs** always rendered in PT Mono via `font-family: var(--salt-text-code-fontFamily)`
- **Focus rings** never suppressed — Salt handles via `var(--salt-focused-outlineColor)`
- **Every interactive element** has an `aria-label` or visible `<FormFieldLabel>`
- **Schema validation errors** always use `<FormFieldHelperText validationStatus="error">` — never a custom error component
- **Scope chips** (on role assignments, filtered queues, etc.) use `<Chip appearance="bordered">` with category dot + PT Mono scope value — never a plain text string

---

## Salt DS Pattern Index

| Pattern | Screen(s) |
|---|---|
| #1 App Shell / Navigation Shell | All screens |
| #2 Dashboard Layout | Home / App Overview |
| #3 Data Grid / Table | Submission Queue, Scoped Role Editor |
| #4 Master-Detail Layout | Review Panel, Version History |
| #5 Form Layout — Single Column | Property Editor, Role Editor Dialog |
| #8 Empty State | Import Screen, Notification Center, Orphaned Panel |
| #10 Filterable List / Search + Results | Submission Queue, Flow View filter rail, Notifications, Orphaned Panel |
| #11 Dialog / Confirmation Modal | Export, Approve/Reject, Workflow Upgrade, Role Editor |
| #12 Slide-in Drawer / Side Panel | Property Editor, Review Panel, Node Detail, Notification Center |
| #13 Tabs-based Content Panel | Property Editor, Node Detail, Export Modal |
| #16 File Upload Drop Zone | Import / Load Screen |
| #17 Vertical Navigation Rail | Flow View left palette sidebar |
| #18 Breadcrumb + Page Header | All content screens |
| #20 Overflow / More Menu | Node context menu, Version history row actions, Notification rows, Role assignments |
