# Copilot Pixel 🤖✨

A pixel art companion that brings GitHub Copilot to life in VS Code. Watch your AI buddy react in real time — thinking, typing, celebrating, and even sleeping!

Inspired by [Pixel Agents](https://github.com/pablodelucca/pixel-agents) for Claude Code.

---

## Features

| State | Trigger | Animation |
|---|---|---|
| 🤔 **Thinking** | Copilot processing / gap between edits | Head shake + thinking dots |
| ⌨️ **Typing** | Code completions / active editing | Arms typing rapidly |
| 👀 **Reading** | Switching files / moving cursor | Leaning forward |
| 🎉 **Celebrating** | Every 10 completions | Jumping with raised arms + stars |
| 😴 **Sleeping** | 60s of inactivity | Slumped + ZZZ bubbles |
| 💤 **Idle** | Waiting | Gentle bob |

---

## Getting Started

### Install from Marketplace
Search **"Copilot Pixel"** in the VS Code Extensions sidebar.

### Install from VSIX
1. Download the `.vsix` file from Releases
2. `code --install-extension copilot-pixel-0.1.0.vsix`

### Build from Source
```bash
git clone https://github.com/your-username/copilot-pixel
cd copilot-pixel
npm install
npm run compile
vsce package
```

---

## Commands

| Command | Description |
|---|---|
| `Copilot Pixel: Show` | Open the pixel companion panel |
| `Copilot Pixel: Hide` | Close the panel |
| `Copilot Pixel: Change Character` | Pick a new character |

---

## Characters

- 🤖 **Bot** — Classic GitHub Copilot robot (default)
- 🚀 **Astronaut** — Space explorer
- 🧙 **Wizard** — Code wizard  
- 🐱 **Cat** — Coding cat

---

## How It Works

Copilot Pixel observes VS Code editor events to infer Copilot's activity:

- **Large text insertions** → likely a Copilot completion being accepted → `typing` state
- **Editing gaps** → Copilot might be computing → `thinking` state  
- **File/editor switches** → user navigating/reading → `reading` state
- **VS Code Language Model API** events (VS Code 1.90+) for direct Copilot signals
- **60 seconds of inactivity** → `sleeping` state

---

## Requirements

- VS Code 1.90+
- GitHub Copilot extension (optional but recommended)

---

## Settings

| Setting | Default | Description |
|---|---|---|
| `copilotPixel.character` | `bot` | Active character |
| `copilotPixel.position` | `bottom-right` | Panel position |
| `copilotPixel.showInStatusBar` | `true` | Status bar indicator |

---

## Contributing

PRs welcome! Especially for:
- New character sprites
- Better Copilot event detection
- Chat panel integration

---

## License

MIT
