import * as vscode from 'vscode';

export function getWebviewContent(
  webview: vscode.Webview,
  extensionUri: vscode.Uri,
  character: string,
  copilotActive: boolean
): string {
  // Character definitions with pixel art sprites (CSS-based pixel art)
  return /* html */`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline';">
<title>Copilot Pixel</title>
<style>
  /* ============================================================
     COPILOT PIXEL — Full Pixel Art Companion
     ============================================================ */

  @import url('https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap');

  :root {
    --bg: #0d1117;
    --bg2: #161b22;
    --bg3: #21262d;
    --border: #30363d;
    --text: #e6edf3;
    --text-muted: #8b949e;
    --accent: #58a6ff;
    --accent2: #79c0ff;
    --green: #3fb950;
    --yellow: #d29922;
    --orange: #f78166;
    --purple: #bc8cff;
    --pixel: 3px;
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Press Start 2P', monospace;
    font-size: 8px;
    display: flex;
    flex-direction: column;
    align-items: center;
    min-height: 100vh;
    overflow-x: hidden;
    image-rendering: pixelated;
  }

  /* ─── Header ─── */
  .header {
    width: 100%;
    background: var(--bg2);
    border-bottom: 2px solid var(--border);
    padding: 10px 16px;
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .header-logo {
    width: 16px; height: 16px;
    background: var(--accent);
    image-rendering: pixelated;
    position: relative;
    box-shadow: 
      3px 0 0 var(--accent),
      -3px 0 0 var(--accent),
      0 3px 0 var(--accent),
      0 -3px 0 var(--accent);
  }

  .header-title { color: var(--accent2); font-size: 9px; }

  .copilot-badge {
    margin-left: auto;
    padding: 3px 6px;
    font-size: 7px;
    border: 1px solid;
    border-radius: 2px;
  }
  .copilot-badge.active { color: var(--green); border-color: var(--green); }
  .copilot-badge.inactive { color: var(--text-muted); border-color: var(--border); }

  /* ─── Scene / Room ─── */
  .scene {
    width: 100%;
    max-width: 320px;
    margin: 20px auto 0;
    position: relative;
  }

  .room {
    width: 100%;
    height: 240px;
    background: var(--bg2);
    border: 2px solid var(--border);
    position: relative;
    overflow: hidden;
  }

  /* Floor */
  .floor {
    position: absolute;
    bottom: 0; left: 0; right: 0;
    height: 48px;
    background: repeating-linear-gradient(
      90deg,
      #1c2128 0px, #1c2128 24px,
      #21262d 24px, #21262d 48px
    );
    border-top: 2px solid #30363d;
  }

  /* Wall decorations */
  .wall-deco {
    position: absolute;
    top: 12px; right: 16px;
    width: 48px; height: 36px;
    background: var(--bg3);
    border: 2px solid var(--border);
  }
  .wall-deco::before {
    content: '';
    position: absolute;
    top: 4px; left: 4px; right: 4px; bottom: 4px;
    background: 
      linear-gradient(var(--accent) 1px, transparent 1px),
      linear-gradient(90deg, var(--accent) 1px, transparent 1px);
    background-size: 6px 6px;
    opacity: 0.15;
  }

  /* Desk */
  .desk {
    position: absolute;
    bottom: 48px;
    left: 50%;
    transform: translateX(-50%);
    width: 120px;
    height: 12px;
    background: #4a3728;
    border-top: 3px solid #6b4c35;
    border-left: 2px solid #3a2a1e;
    border-right: 2px solid #3a2a1e;
  }

  /* Desk legs */
  .desk::before,
  .desk::after {
    content: '';
    position: absolute;
    bottom: -20px;
    width: 6px;
    height: 20px;
    background: #4a3728;
  }
  .desk::before { left: 10px; }
  .desk::after  { right: 10px; }

  /* Monitor */
  .monitor {
    position: absolute;
    bottom: 72px;
    left: 50%;
    transform: translateX(-50%) translateX(-12px);
    width: 54px;
    height: 42px;
    background: var(--bg3);
    border: 3px solid #444c56;
  }

  .monitor-screen {
    width: 100%;
    height: 100%;
    background: var(--bg);
    display: flex;
    flex-direction: column;
    padding: 3px;
    gap: 2px;
    overflow: hidden;
  }

  .code-line {
    height: 3px;
    border-radius: 1px;
    background: var(--accent);
    opacity: 0.7;
    animation: codePulse 2s ease-in-out infinite;
  }
  .code-line:nth-child(2) { width: 70%; animation-delay: .3s; background: var(--green); }
  .code-line:nth-child(3) { width: 85%; animation-delay: .6s; }
  .code-line:nth-child(4) { width: 45%; animation-delay: .9s; background: var(--purple); }
  .code-line:nth-child(5) { width: 75%; animation-delay: 1.2s; }
  .code-line:nth-child(6) { width: 30%; animation-delay: 1.5s; background: var(--yellow); }
  .code-line:nth-child(7) { width: 60%; animation-delay: 1.8s; }
  .code-line:nth-child(8) { width: 50%; animation-delay: .1s; background: var(--orange); }

  @keyframes codePulse {
    0%, 100% { opacity: 0.4; }
    50%       { opacity: 1; }
  }

  /* Monitor stand */
  .monitor::after {
    content: '';
    position: absolute;
    bottom: -9px;
    left: 50%;
    transform: translateX(-50%);
    width: 18px;
    height: 6px;
    background: #444c56;
    border-bottom: 3px solid #586069;
  }

  /* ─── Character Sprite (CSS pixel art) ─── */
  .character {
    position: absolute;
    bottom: 60px;
    left: 50%;
    transform: translateX(-50%) translateX(30px);
    width: 30px;
    height: 48px;
    transition: transform 0.3s ease;
  }

  /* Generic robot character */
  .sprite {
    width: 30px;
    height: 48px;
    position: relative;
    image-rendering: pixelated;
  }

  /* HEAD */
  .sprite-head {
    position: absolute;
    top: 0; left: 3px;
    width: 24px; height: 18px;
    background: var(--accent);
    border: 2px solid #1f6feb;
  }
  /* Eye visor */
  .sprite-head::before {
    content: '';
    position: absolute;
    top: 4px; left: 3px;
    width: 18px; height: 6px;
    background: var(--bg);
  }
  /* Antenna */
  .sprite-head::after {
    content: '';
    position: absolute;
    top: -6px; left: 10px;
    width: 4px; height: 6px;
    background: var(--accent2);
  }

  /* BODY */
  .sprite-body {
    position: absolute;
    top: 18px; left: 3px;
    width: 24px; height: 18px;
    background: #1f6feb;
    border: 2px solid #388bfd;
  }
  /* Copilot logo on chest */
  .sprite-body::before {
    content: '';
    position: absolute;
    top: 4px; left: 6px;
    width: 12px; height: 8px;
    background: var(--accent2);
    clip-path: polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%);
    opacity: 0.8;
  }

  /* ARMS */
  .sprite-arm-l {
    position: absolute;
    top: 19px; left: 0;
    width: 5px; height: 12px;
    background: var(--accent);
    border: 1px solid #1f6feb;
    transform-origin: top center;
  }

  .sprite-arm-r {
    position: absolute;
    top: 19px; right: 0;
    width: 5px; height: 12px;
    background: var(--accent);
    border: 1px solid #1f6feb;
    transform-origin: top center;
  }

  /* LEGS */
  .sprite-leg-l {
    position: absolute;
    bottom: 0; left: 6px;
    width: 8px; height: 12px;
    background: #1f6feb;
    border: 1px solid #388bfd;
  }

  .sprite-leg-r {
    position: absolute;
    bottom: 0; right: 6px;
    width: 8px; height: 12px;
    background: #1f6feb;
    border: 1px solid #388bfd;
  }

  /* ─── State Animations ─── */

  /* IDLE: gentle bob */
  .state-idle .sprite {
    animation: idleBob 2s ease-in-out infinite;
  }
  @keyframes idleBob {
    0%, 100% { transform: translateY(0); }
    50%       { transform: translateY(-3px); }
  }

  /* THINKING: head shake + thinking bubble */
  .state-thinking .sprite-head {
    animation: thinkShake 0.4s ease-in-out infinite alternate;
  }
  .state-thinking .sprite-head::before {
    animation: eyeFlicker 0.6s step-end infinite;
  }
  @keyframes thinkShake {
    from { transform: rotate(-5deg); }
    to   { transform: rotate(5deg); }
  }
  @keyframes eyeFlicker {
    0%, 100% { opacity: 1; }
    50%       { opacity: 0.3; }
  }

  /* TYPING: arms move rapidly */
  .state-typing .sprite-arm-l {
    animation: typeArmL 0.25s ease-in-out infinite alternate;
  }
  .state-typing .sprite-arm-r {
    animation: typeArmR 0.25s ease-in-out infinite alternate;
  }
  .state-typing .sprite {
    animation: idleBob 1s ease-in-out infinite;
  }
  @keyframes typeArmL {
    from { transform: rotate(-20deg) translateY(-3px); }
    to   { transform: rotate(10deg) translateY(3px); }
  }
  @keyframes typeArmR {
    from { transform: rotate(20deg) translateY(3px); }
    to   { transform: rotate(-10deg) translateY(-3px); }
  }

  /* READING: leans forward */
  .state-reading .sprite {
    animation: readLean 3s ease-in-out infinite;
  }
  .state-reading .sprite-arm-l {
    transform: rotate(30deg);
    transition: transform 0.5s;
  }
  .state-reading .sprite-arm-r {
    transform: rotate(-30deg);
    transition: transform 0.5s;
  }
  @keyframes readLean {
    0%, 100% { transform: rotate(-3deg); }
    50%       { transform: rotate(3deg); }
  }

  /* CELEBRATING: jump! */
  .state-celebrating .sprite {
    animation: celebrate 0.5s ease-in-out infinite;
  }
  .state-celebrating .sprite-arm-l {
    animation: celebArm 0.5s ease-in-out infinite alternate;
    transform-origin: top center;
  }
  .state-celebrating .sprite-arm-r {
    animation: celebArmR 0.5s ease-in-out infinite alternate;
    transform-origin: top center;
  }
  @keyframes celebrate {
    0%, 100% { transform: translateY(0); }
    50%       { transform: translateY(-12px); }
  }
  @keyframes celebArm {
    from { transform: rotate(-120deg); }
    to   { transform: rotate(-60deg); }
  }
  @keyframes celebArmR {
    from { transform: rotate(60deg); }
    to   { transform: rotate(120deg); }
  }

  /* SLEEPING: slumped */
  .state-sleeping .sprite {
    animation: sleepSlump 4s ease-in-out infinite;
    transform-origin: bottom center;
  }
  .state-sleeping .sprite-head::before {
    background: #333;
  }
  @keyframes sleepSlump {
    0%, 100% { transform: rotate(-8deg); }
    50%       { transform: rotate(-12deg); }
  }

  /* ─── Speech Bubble ─── */
  .speech-bubble {
    position: absolute;
    bottom: 110px;
    left: 50%;
    transform: translateX(-10px);
    background: var(--bg3);
    border: 2px solid var(--border);
    padding: 6px 8px;
    font-size: 7px;
    color: var(--text);
    white-space: nowrap;
    max-width: 140px;
    white-space: normal;
    line-height: 1.8;
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: 10;
  }
  .speech-bubble.visible { opacity: 1; }

  /* Bubble tail */
  .speech-bubble::after {
    content: '';
    position: absolute;
    bottom: -8px;
    right: 16px;
    width: 6px; height: 6px;
    background: var(--bg3);
    border-right: 2px solid var(--border);
    border-bottom: 2px solid var(--border);
    transform: rotate(45deg);
  }

  /* Stars for celebrating */
  .star {
    position: absolute;
    width: 6px; height: 6px;
    background: var(--yellow);
    opacity: 0;
    pointer-events: none;
  }
  .state-celebrating .star {
    animation: starFloat 1s ease-out infinite;
  }
  .star:nth-child(1) { left: 20%; animation-delay: 0s; }
  .star:nth-child(2) { left: 50%; animation-delay: .2s; }
  .star:nth-child(3) { left: 75%; animation-delay: .4s; background: var(--purple); }
  .star:nth-child(4) { left: 35%; animation-delay: .6s; background: var(--orange); }
  @keyframes starFloat {
    0%   { transform: translateY(0) scale(0); opacity: 1; }
    100% { transform: translateY(-60px) scale(1); opacity: 0; }
  }

  /* ZZZ for sleeping */
  .zzz {
    position: absolute;
    bottom: 110px;
    left: 60%;
    font-size: 10px;
    color: var(--accent);
    opacity: 0;
    pointer-events: none;
  }
  .state-sleeping .zzz {
    animation: zzzFloat 2s ease-out infinite;
  }
  .state-sleeping .zzz:nth-child(2) { animation-delay: 0.7s; font-size: 13px; left: 65%; }
  .state-sleeping .zzz:nth-child(3) { animation-delay: 1.4s; font-size: 16px; left: 70%; }
  @keyframes zzzFloat {
    0%   { transform: translateY(0); opacity: 1; }
    100% { transform: translateY(-40px); opacity: 0; }
  }

  /* ─── Thinking dots ─── */
  .think-dots {
    position: absolute;
    bottom: 110px;
    left: 50%;
    transform: translateX(-10px);
    display: flex;
    gap: 4px;
    opacity: 0;
    transition: opacity 0.3s;
  }
  .think-dots.visible { opacity: 1; }
  .think-dot {
    width: 6px; height: 6px;
    background: var(--accent);
    animation: dotBounce 1s ease-in-out infinite;
  }
  .think-dot:nth-child(2) { animation-delay: .15s; }
  .think-dot:nth-child(3) { animation-delay: .3s; }
  @keyframes dotBounce {
    0%, 100% { transform: translateY(0); }
    50%       { transform: translateY(-6px); }
  }

  /* ─── Info Panel ─── */
  .info-panel {
    width: 100%;
    max-width: 320px;
    background: var(--bg2);
    border: 2px solid var(--border);
    margin: 8px auto 0;
    padding: 10px 14px;
  }

  .state-label {
    font-size: 8px;
    color: var(--text-muted);
    margin-bottom: 4px;
  }

  .state-value {
    font-size: 10px;
    color: var(--accent);
    text-transform: uppercase;
  }

  .state-message {
    margin-top: 8px;
    font-size: 7px;
    color: var(--text-muted);
    line-height: 2;
  }

  /* ─── Buttons ─── */
  .buttons {
    width: 100%;
    max-width: 320px;
    display: flex;
    gap: 8px;
    margin: 8px auto;
    padding: 0 0 12px;
  }

  .btn {
    flex: 1;
    background: var(--bg2);
    border: 2px solid var(--border);
    color: var(--text-muted);
    font-family: 'Press Start 2P', monospace;
    font-size: 7px;
    padding: 8px 4px;
    cursor: pointer;
    text-align: center;
    transition: all 0.1s;
    image-rendering: pixelated;
  }
  .btn:hover {
    background: var(--bg3);
    color: var(--text);
    border-color: var(--accent);
  }
  .btn:active { transform: translateY(1px); }

  /* ─── Scrollbar ─── */
  ::-webkit-scrollbar { width: 6px; }
  ::-webkit-scrollbar-track { background: var(--bg); }
  ::-webkit-scrollbar-thumb { background: var(--border); }
</style>
</head>
<body>

<div class="header">
  <div class="header-logo"></div>
  <span class="header-title">COPILOT PIXEL</span>
  <span class="copilot-badge ${copilotActive ? 'active' : 'inactive'}" id="copilotBadge">
    ${copilotActive ? '● ACTIVE' : '○ OFFLINE'}
  </span>
</div>

<div class="scene">
  <div class="room" id="room">
    <div class="wall-deco"></div>

    <!-- Monitor -->
    <div class="monitor">
      <div class="monitor-screen">
        <div class="code-line"></div>
        <div class="code-line"></div>
        <div class="code-line"></div>
        <div class="code-line"></div>
        <div class="code-line"></div>
        <div class="code-line"></div>
        <div class="code-line"></div>
        <div class="code-line"></div>
      </div>
    </div>

    <!-- Desk -->
    <div class="desk"></div>

    <!-- Floor -->
    <div class="floor"></div>

    <!-- Speech bubble -->
    <div class="speech-bubble" id="speechBubble"></div>

    <!-- Thinking dots -->
    <div class="think-dots" id="thinkDots">
      <div class="think-dot"></div>
      <div class="think-dot"></div>
      <div class="think-dot"></div>
    </div>

    <!-- Stars (celebrating) -->
    <div class="star"></div>
    <div class="star"></div>
    <div class="star"></div>
    <div class="star"></div>

    <!-- ZZZ (sleeping) -->
    <span class="zzz">z</span>
    <span class="zzz">z</span>
    <span class="zzz">z</span>

    <!-- Character -->
    <div class="character state-idle" id="character">
      <div class="sprite" id="sprite">
        <div class="sprite-head"></div>
        <div class="sprite-body"></div>
        <div class="sprite-arm-l"></div>
        <div class="sprite-arm-r"></div>
        <div class="sprite-leg-l"></div>
        <div class="sprite-leg-r"></div>
      </div>
    </div>
  </div>
</div>

<div class="info-panel">
  <div class="state-label">CURRENT STATE</div>
  <div class="state-value" id="stateValue">IDLE</div>
  <div class="state-message" id="stateMessage">Waiting for Copilot activity...</div>
</div>

<div class="buttons">
  <button class="btn" onclick="changeCharacter()">CHANGE CHAR</button>
  <button class="btn" onclick="toggleSleep()">WAKE / SLEEP</button>
</div>

<script>
  const vscode = acquireVsCodeApi();
  const character = document.getElementById('character');
  const stateValue = document.getElementById('stateValue');
  const stateMessage = document.getElementById('stateMessage');
  const speechBubble = document.getElementById('speechBubble');
  const thinkDots = document.getElementById('thinkDots');
  let currentState = 'idle';
  let bubbleTimer = null;
  let isManuallySleeping = false;

  const stateInfo = {
    idle: {
      label: 'IDLE',
      messages: [
        'Ready to help!',
        'Just chilling...',
        'Waiting for code...',
        'Standing by.'
      ]
    },
    thinking: {
      label: 'THINKING',
      messages: [
        'Processing...',
        'Hmm, let me think...',
        'Analyzing context...',
        'Computing...'
      ]
    },
    typing: {
      label: 'GENERATING',
      messages: [
        'Writing code!',
        'Copilot is typing...',
        'Generating completion...',
        'On it!'
      ]
    },
    reading: {
      label: 'READING',
      messages: [
        'Reading your code...',
        'Analyzing the file...',
        'Understanding context...',
        'Got it!'
      ]
    },
    celebrating: {
      label: 'CELEBRATING!',
      messages: [
        '🎉 Great progress!',
        'Woohoo! Milestone!',
        'You\'re on fire!',
        'Keep going! 🚀'
      ]
    },
    sleeping: {
      label: 'SLEEPING',
      messages: [
        'Zzz...',
        'Taking a nap...',
        'Will wake on activity',
        'Dreaming of code...'
      ]
    }
  };

  function setState(state) {
    if (state === currentState) return;

    // Remove old state class
    character.className = 'character state-' + state;
    currentState = state;

    const info = stateInfo[state] || stateInfo.idle;
    stateValue.textContent = info.label;

    const msg = info.messages[Math.floor(Math.random() * info.messages.length)];
    stateMessage.textContent = msg;

    // Handle speech bubble
    if (state === 'typing' || state === 'celebrating') {
      showSpeechBubble(msg);
    } else {
      hideSpeechBubble();
    }

    // Handle think dots
    if (state === 'thinking') {
      thinkDots.classList.add('visible');
    } else {
      thinkDots.classList.remove('visible');
    }

    // Update state value color
    const colors = {
      idle: '#58a6ff',
      thinking: '#d29922',
      typing: '#3fb950',
      reading: '#bc8cff',
      celebrating: '#f78166',
      sleeping: '#8b949e'
    };
    stateValue.style.color = colors[state] || '#58a6ff';
  }

  function showSpeechBubble(text) {
    if (bubbleTimer) clearTimeout(bubbleTimer);
    speechBubble.textContent = text;
    speechBubble.classList.add('visible');
    bubbleTimer = setTimeout(hideSpeechBubble, 3000);
  }

  function hideSpeechBubble() {
    speechBubble.classList.remove('visible');
  }

  function changeCharacter() {
    vscode.postMessage({ type: 'requestCharacterChange' });
  }

  function toggleSleep() {
    isManuallySleeping = !isManuallySleeping;
    if (isManuallySleeping) {
      setState('sleeping');
    } else {
      setState('idle');
    }
  }

  // Listen for messages from extension
  window.addEventListener('message', (event) => {
    const msg = event.data;
    switch (msg.type) {
      case 'stateChange':
        if (!isManuallySleeping) {
          setState(msg.state);
        }
        break;
      case 'changeCharacter':
        // Future: swap sprite assets based on character
        showSpeechBubble('New look!');
        break;
    }
  });

  // Signal ready
  vscode.postMessage({ type: 'ready' });

  // Initial state
  setState('idle');
</script>
</body>
</html>`;
}
