import * as vscode from 'vscode';
import { PixelPanelProvider } from './pixelPanelProvider';
import { CopilotStateTracker } from './copilotStateTracker';

let statusBarItem: vscode.StatusBarItem;
let panelProvider: PixelPanelProvider;
let stateTracker: CopilotStateTracker;

export function activate(context: vscode.ExtensionContext) {
  console.log('Copilot Pixel is now active! 🤖✨');

  // State tracker monitors Copilot + editor activity
  stateTracker = new CopilotStateTracker(context);

  // Panel provider manages the webview
  panelProvider = new PixelPanelProvider(context, stateTracker);

  // Status bar item
  statusBarItem = vscode.window.createStatusBarItem(
    vscode.StatusBarAlignment.Right,
    100
  );
  statusBarItem.text = '$(robot) Copilot Pixel';
  statusBarItem.command = 'copilot-pixel.show';
  statusBarItem.tooltip = 'Show Copilot Pixel companion';

  const config = vscode.workspace.getConfiguration('copilotPixel');
  if (config.get('showInStatusBar')) {
    statusBarItem.show();
  }

  // Register commands
  context.subscriptions.push(
    vscode.commands.registerCommand('copilot-pixel.show', () => {
      panelProvider.showPanel();
    }),

    vscode.commands.registerCommand('copilot-pixel.hide', () => {
      panelProvider.hidePanel();
    }),

    vscode.commands.registerCommand('copilot-pixel.changeCharacter', async () => {
      const characters = [
        { label: '🤖 Bot', value: 'bot', description: 'Classic GitHub Copilot robot' },
        { label: '🚀 Astronaut', value: 'astronaut', description: 'Space explorer' },
        { label: '🧙 Wizard', value: 'wizard', description: 'Code wizard' },
        { label: '🐱 Cat', value: 'cat', description: 'Coding cat' },
      ];

      const picked = await vscode.window.showQuickPick(characters, {
        placeHolder: 'Choose your Copilot Pixel character',
      });

      if (picked) {
        await vscode.workspace
          .getConfiguration('copilotPixel')
          .update('character', picked.value, vscode.ConfigurationTarget.Global);
        panelProvider.updateCharacter(picked.value);
        vscode.window.showInformationMessage(
          `Copilot Pixel character changed to ${picked.label}! 🎉`
        );
      }
    }),

    statusBarItem
  );

  // Auto-show panel on first activation
  panelProvider.showPanel();

  // Update status bar based on Copilot state
  stateTracker.onStateChange((state) => {
    const icons: Record<string, string> = {
      idle: '$(robot)',
      thinking: '$(sync~spin)',
      typing: '$(edit)',
      reading: '$(book)',
      celebrating: '$(star-full)',
      sleeping: '$(circle-outline)',
    };
    statusBarItem.text = `${icons[state] ?? '$(robot)'} Copilot Pixel`;
  });
}

export function deactivate() {
  stateTracker?.dispose();
  panelProvider?.dispose();
}
