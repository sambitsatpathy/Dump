import * as vscode from 'vscode';

export type CopilotState =
  | 'idle'
  | 'thinking'
  | 'typing'
  | 'reading'
  | 'celebrating'
  | 'sleeping';

type StateChangeHandler = (state: CopilotState) => void;

export class CopilotStateTracker {
  private _state: CopilotState = 'idle';
  private _handlers: StateChangeHandler[] = [];
  private _disposables: vscode.Disposable[] = [];

  // Timers for state transitions
  private _idleTimer: NodeJS.Timeout | null = null;
  private _sleepTimer: NodeJS.Timeout | null = null;
  private _celebrateTimer: NodeJS.Timeout | null = null;

  // Track recent activity
  private _lastEditTime: number = 0;
  private _editCount: number = 0;
  private _copilotActive: boolean = false;

  constructor(private context: vscode.ExtensionContext) {
    this._init();
  }

  private _init() {
    // Detect text document changes (edits / completions being accepted)
    this._disposables.push(
      vscode.workspace.onDidChangeTextDocument((e) => {
        if (e.document === vscode.window.activeTextEditor?.document) {
          this._onDocumentEdit(e);
        }
      })
    );

    // Detect active editor changes (user is reading/navigating)
    this._disposables.push(
      vscode.window.onDidChangeActiveTextEditor((editor) => {
        if (editor) {
          this._onEditorChange(editor);
        }
      })
    );

    // Detect selection changes (cursor moving = reading)
    this._disposables.push(
      vscode.window.onDidChangeTextEditorSelection((e) => {
        if (e.kind === vscode.TextEditorSelectionChangeKind.Mouse ||
            e.kind === vscode.TextEditorSelectionChangeKind.Keyboard) {
          this._onSelectionChange();
        }
      })
    );

    // Watch for Copilot extension state
    this._disposables.push(
      vscode.extensions.onDidChange(() => {
        this._checkCopilotExtension();
      })
    );

    // Try to hook into VS Code Language Model API (Copilot)
    this._hookIntoLMAPI();

    // Check Copilot on startup
    this._checkCopilotExtension();

    // Start sleep timer
    this._resetSleepTimer();
  }

  private _hookIntoLMAPI() {
    try {
      // VS Code 1.90+ Language Model API
      if ('lm' in vscode && (vscode as any).lm?.onDidChangeChatModels) {
        this._disposables.push(
          (vscode as any).lm.onDidChangeChatModels(() => {
            // Copilot chat models changed = Copilot is doing something
            this._setState('thinking');
            setTimeout(() => {
              if (this._state === 'thinking') {
                this._setState('typing');
              }
            }, 1500);
          })
        );
      }
    } catch {
      // LM API not available, rely on other heuristics
    }
  }

  private _checkCopilotExtension() {
    const copilot = vscode.extensions.getExtension('GitHub.copilot');
    const copilotChat = vscode.extensions.getExtension('GitHub.copilot-chat');
    this._copilotActive = !!(copilot?.isActive || copilotChat?.isActive);
  }

  private _onDocumentEdit(e: vscode.TextDocumentChangeEvent) {
    const now = Date.now();
    const changes = e.contentChanges;

    if (changes.length === 0) { return; }

    // Large multi-line insertions are likely Copilot completions
    const isLargeInsertion = changes.some(
      (c) => c.text.length > 30 || c.text.includes('\n')
    );

    // Rapid small edits = user typing; large blocks = Copilot
    if (isLargeInsertion) {
      // Likely a Copilot completion being accepted
      this._setState('typing');
      this._editCount++;

      // Celebrate after several completions
      if (this._editCount % 10 === 0) {
        setTimeout(() => this._triggerCelebration(), 500);
      }
    } else {
      // User is actively editing
      const timeSinceLastEdit = now - this._lastEditTime;
      if (timeSinceLastEdit > 2000) {
        // Gap in editing - Copilot might be thinking
        this._setState('thinking');
        setTimeout(() => {
          if (this._state === 'thinking') {
            this._setState('typing');
          }
        }, 800);
      } else {
        this._setState('typing');
      }
    }

    this._lastEditTime = now;
    this._resetIdleTimer();
    this._resetSleepTimer();
  }

  private _onEditorChange(editor: vscode.TextEditor) {
    this._setState('reading');
    this._resetIdleTimer(3000);
    this._resetSleepTimer();
  }

  private _onSelectionChange() {
    if (this._state === 'sleeping') {
      this._setState('idle');
    }
    this._resetSleepTimer();
  }

  private _triggerCelebration() {
    this._setState('celebrating');
    this._celebrateTimer = setTimeout(() => {
      this._setState('idle');
    }, 2500);
  }

  private _resetIdleTimer(delay = 5000) {
    if (this._idleTimer) { clearTimeout(this._idleTimer); }
    this._idleTimer = setTimeout(() => {
      if (this._state !== 'sleeping' && this._state !== 'celebrating') {
        this._setState('idle');
      }
    }, delay);
  }

  private _resetSleepTimer() {
    if (this._sleepTimer) { clearTimeout(this._sleepTimer); }
    this._sleepTimer = setTimeout(() => {
      if (this._state === 'idle') {
        this._setState('sleeping');
      }
    }, 60000); // Sleep after 1 min of inactivity
  }

  private _setState(state: CopilotState) {
    if (this._state === state) { return; }
    this._state = state;
    this._handlers.forEach((h) => h(state));
  }

  get state(): CopilotState {
    return this._state;
  }

  get copilotActive(): boolean {
    return this._copilotActive;
  }

  onStateChange(handler: StateChangeHandler): void {
    this._handlers.push(handler);
  }

  dispose() {
    this._disposables.forEach((d) => d.dispose());
    if (this._idleTimer) { clearTimeout(this._idleTimer); }
    if (this._sleepTimer) { clearTimeout(this._sleepTimer); }
    if (this._celebrateTimer) { clearTimeout(this._celebrateTimer); }
  }
}
