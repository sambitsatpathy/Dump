import * as vscode from 'vscode';
import { CopilotStateTracker, CopilotState } from './copilotStateTracker';
import { getWebviewContent } from './webviewContent';

export class PixelPanelProvider {
  private _panel: vscode.WebviewPanel | null = null;
  private _disposables: vscode.Disposable[] = [];
  private _character: string;

  constructor(
    private context: vscode.ExtensionContext,
    private stateTracker: CopilotStateTracker
  ) {
    const config = vscode.workspace.getConfiguration('copilotPixel');
    this._character = config.get('character') ?? 'bot';

    // Forward state changes to webview
    stateTracker.onStateChange((state) => {
      this._sendStateToWebview(state);
    });

    // Watch config changes
    this._disposables.push(
      vscode.workspace.onDidChangeConfiguration((e) => {
        if (e.affectsConfiguration('copilotPixel.character')) {
          const cfg = vscode.workspace.getConfiguration('copilotPixel');
          this._character = cfg.get('character') ?? 'bot';
          this.updateCharacter(this._character);
        }
      })
    );
  }

  showPanel() {
    if (this._panel) {
      this._panel.reveal(vscode.ViewColumn.Beside, true);
      return;
    }

    this._panel = vscode.window.createWebviewPanel(
      'copilotPixel',
      'Copilot Pixel',
      { viewColumn: vscode.ViewColumn.Beside, preserveFocus: true },
      {
        enableScripts: true,
        retainContextWhenHidden: true,
        localResourceRoots: [
          vscode.Uri.joinPath(this.context.extensionUri, 'media'),
        ],
      }
    );

    this._panel.iconPath = vscode.Uri.joinPath(
      this.context.extensionUri,
      'images',
      'icon.png'
    );

    this._panel.webview.html = getWebviewContent(
      this._panel.webview,
      this.context.extensionUri,
      this._character,
      this.stateTracker.copilotActive
    );

    // Handle messages from webview
    this._panel.webview.onDidReceiveMessage(
      (message) => this._handleWebviewMessage(message),
      undefined,
      this._disposables
    );

    this._panel.onDidDispose(
      () => { this._panel = null; },
      undefined,
      this._disposables
    );

    // Send current state immediately
    setTimeout(() => {
      this._sendStateToWebview(this.stateTracker.state);
    }, 500);
  }

  hidePanel() {
    this._panel?.dispose();
    this._panel = null;
  }

  updateCharacter(character: string) {
    this._character = character;
    this._panel?.webview.postMessage({ type: 'changeCharacter', character });
  }

  private _sendStateToWebview(state: CopilotState) {
    this._panel?.webview.postMessage({ type: 'stateChange', state });
  }

  private _handleWebviewMessage(message: { type: string; [key: string]: unknown }) {
    switch (message.type) {
      case 'ready':
        this._sendStateToWebview(this.stateTracker.state);
        break;
      case 'requestCharacterChange':
        vscode.commands.executeCommand('copilot-pixel.changeCharacter');
        break;
    }
  }

  dispose() {
    this._panel?.dispose();
    this._disposables.forEach((d) => d.dispose());
  }
}
