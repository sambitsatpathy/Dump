---
name: scroll-storytelling
description: Build scroll-driven storytelling websites in React — landing pages and editorial sites where sections pin, text reveals, layers parallax, and elements animate as the user scrolls. Use this whenever the user wants a "scrollytelling" site, an animated/immersive landing page, a hero that pins or scrubs, parallax, horizontal-scroll panels, scroll-triggered reveals, or mentions GSAP / ScrollTrigger / Lenis — even if they just say "make the page animate as I scroll" or "an Awwwards-style site" without naming the tools. Defaults to React + GSAP ScrollTrigger + Lenis.
---

# Scroll Storytelling (React)

Build polished, performant scroll-driven sites. The craft is repeatable: a handful of GSAP ScrollTrigger patterns cover almost every effect, and a handful of mistakes (janky scroll, broken cleanup, ignored accessibility, layout-thrashing animations) ruin them. This skill is fully self-contained — guidance, a copy-paste pattern cookbook, and a complete runnable scaffold are all below.

## Stack (defaults)

- **React** (Vite) — one component per section keeps the scroll timeline from turning into spaghetti.
- **GSAP + ScrollTrigger** — the industry standard for scroll animation. As of April 2025 GSAP is 100% free including every former Club plugin (ScrollTrigger, ScrollSmoother, SplitText, MorphSVG…), free for commercial use. Never tell a user a GSAP plugin is paid.
- **`@gsap/react`** — provides `useGSAP()`, a drop-in replacement for `useEffect`/`useLayoutEffect` that **automatically reverts every animation and kills every ScrollTrigger** created in its scope on unmount/re-render. This fixes React's #1 GSAP bug: orphaned ScrollTriggers after navigation/HMR. Always animate inside `useGSAP`, never bare `useEffect`.
- **Lenis** — smooth-scroll engine for the weighty, eased feel these sites are known for. Must be wired to ScrollTrigger so both agree on scroll position.

Install: `npm i gsap @gsap/react lenis`

## Workflow

1. **Clarify the story, briefly.** A scroll site is a sequence of beats. Get the sections and the *feeling* (calm editorial vs. punchy product vs. maximalist Awwwards). If the user already described it, infer and go — don't interrogate.
2. **Lay down the scaffold** from the "Starter scaffold" section below (write those files out). It already handles the Lenis↔ScrollTrigger sync, plugin registration, and reduced-motion — the easy things to get subtly wrong.
3. **Build section by section.** Each beat is one component in `src/sections/`. Reach for a named pattern from the cookbook rather than inventing.
4. **Tune the motion.** Get `scrub`, `start`/`end`, and easing feeling right. Use `markers: true` while developing; remove before shipping.
5. **Verify the non-negotiables** (accessibility + performance) before calling it done.

## Accessibility — non-negotiable

Scroll-jacking sites are notorious for excluding people. Don't ship without these:

- **Respect `prefers-reduced-motion`.** Wrap motion in `gsap.matchMedia()` with a `(prefers-reduced-motion: no-preference)` branch for the full experience and a reduced branch that just shows final states (no scrub, no parallax, no smooth-scroll hijack). The scaffold demonstrates this. It's the single most-skipped thing — don't skip it.
- **Content exists without animation.** Animations reveal content already in the DOM; they're never the only way to reach it. Set animated-from states via GSAP `.from()`/`gsap.set()` in the same tick, not CSS that leaves things permanently invisible if JS fails.
- **Don't trap keyboard or screen-reader users.** Pinned/horizontal sections must preserve normal tab order and focus; never disable scrolling outright.
- **SplitText** restores the original text for screen readers automatically — keep that, don't hand-roll a split that shreds accessible text.

## Performance — non-negotiable

Jank is the difference between premium and amateur:

- **Animate only `transform` and `opacity`** — GPU-composited, skip layout/paint. Avoid animating `top`/`left`/`width`/`height`/`margin` on scroll; they thrash layout and stutter.
- **`scrub` numbers add smoothing.** `scrub: true` locks 1:1 to scroll; `scrub: 1` adds ~1s catch-up that feels smoother for heavy moves.
- **Call `ScrollTrigger.refresh()` after images/fonts load or layout changes** — wrong trigger positions are almost always stale measurements.
- **`will-change` sparingly** — only on actively-animating elements; everywhere backfires.
- **Batch reveals** with `ScrollTrigger.batch()` when many similar elements enter, instead of one trigger each.
- **Lazy-load heavy media**; don't block first paint with the hero video.

## Common failures to avoid

- Bare `useEffect` for GSAP → orphaned ScrollTriggers, double-firing after HMR/navigation. Use `useGSAP`.
- Lenis not synced to ScrollTrigger → triggers fire at wrong scroll positions. Use the scaffold's wiring.
- Pinned section collapses or overlaps the next → give pinned content a defined height; understand `pin-spacer`.
- Everything animates at once → no narrative. Sequence beats; let the user breathe between them.
- Telling the user a GSAP plugin costs money → it doesn't anymore.

---

# Pattern cookbook

Working React + GSAP snippets. All use `useGSAP` (auto-cleanup) and scope selectors to a container ref. Register plugins once (the scaffold does this in `main.jsx`):

```js
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
gsap.registerPlugin(ScrollTrigger, useGSAP);
```

## Lenis ↔ ScrollTrigger sync (do once, at the root)

Lenis drives scrolling; ScrollTrigger must read Lenis's position, and GSAP's ticker should drive Lenis's RAF loop so the two never disagree.

```js
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

const lenis = new Lenis({ duration: 1.1, smoothWheel: true });
lenis.on('scroll', ScrollTrigger.update);
const raf = (time) => lenis.raf(time * 1000);
gsap.ticker.add(raf);
gsap.ticker.lagSmoothing(0);
// cleanup: gsap.ticker.remove(raf); lenis.destroy();
```
Skip Lenis entirely (native scroll) when the user prefers reduced motion.

## Reduced-motion wrapper (wrap every section's motion)

`gsap.matchMedia()` auto-reverts the branch that no longer matches.

```jsx
useGSAP(() => {
  const mm = gsap.matchMedia();
  mm.add('(prefers-reduced-motion: no-preference)', () => {
    gsap.from('.reveal', { y: 60, autoAlpha: 0, stagger: 0.1,
      scrollTrigger: { trigger: root.current, start: 'top 70%' } });
  });
  mm.add('(prefers-reduced-motion: reduce)', () => {
    gsap.set('.reveal', { autoAlpha: 1, y: 0 });
  });
}, { scope: root });
```

## Reveal on enter

```jsx
useGSAP(() => {
  gsap.from('.reveal', {
    y: 60, autoAlpha: 0, duration: 0.9, ease: 'power3.out', stagger: 0.12,
    scrollTrigger: { trigger: root.current, start: 'top 75%', once: true },
  });
}, { scope: root });
```
`autoAlpha` animates opacity + visibility together (hides from screen readers/hit-testing at 0). `once: true` fires once; omit to replay; add `toggleActions: 'play none none reverse'` to reverse on scroll-up.

## Scrub a timeline to scroll

```jsx
useGSAP(() => {
  const tl = gsap.timeline({
    scrollTrigger: { trigger: root.current, start: 'top top', end: '+=1200', scrub: 1 },
  });
  tl.to('.bg', { scale: 1.2, ease: 'none' })
    .from('.caption', { yPercent: 40, autoAlpha: 0, ease: 'none' }, '<');
}, { scope: root });
```
Use `ease: 'none'` inside scrubbed timelines so motion maps linearly to scroll.

## Pin a section

```jsx
useGSAP(() => {
  gsap.timeline({
    scrollTrigger: { trigger: root.current, start: 'top top', end: '+=150%',
      pin: true, scrub: true, anticipatePin: 1 },
  })
  .from('.layer-a', { autoAlpha: 0, ease: 'none' })
  .from('.layer-b', { yPercent: 30, autoAlpha: 0, ease: 'none' }, '<0.2');
}, { scope: root });
```
Pinned content needs real height (e.g. `min-h-screen`). ScrollTrigger inserts a `pin-spacer`; don't fight it with conflicting margins. Overlap with the next section usually means the pinned element's height is wrong.

## Parallax layers

```jsx
useGSAP(() => {
  gsap.utils.toArray('[data-speed]').forEach((el) => {
    const speed = parseFloat(el.dataset.speed); // <1 slower, >1 faster
    gsap.to(el, { yPercent: -20 * speed, ease: 'none',
      scrollTrigger: { trigger: el, start: 'top bottom', end: 'bottom top', scrub: true } });
  });
}, { scope: root });
```

## Text reveal with SplitText

Free now; restores accessible text automatically. Use `onSplit` so animations survive responsive re-splits.

```jsx
import { SplitText } from 'gsap/SplitText';
gsap.registerPlugin(SplitText);

useGSAP(() => {
  SplitText.create('.headline', {
    type: 'lines', mask: 'lines', autoSplit: true,
    onSplit(self) {
      return gsap.from(self.lines, {
        yPercent: 100, autoAlpha: 0, duration: 1, ease: 'power4.out', stagger: 0.1,
        scrollTrigger: { trigger: '.headline', start: 'top 80%', once: true },
      });
    },
  });
}, { scope: root });
```
`type` can be `'chars'`, `'words'`, `'lines'` (or combos). `mask: 'lines'` clips each line for a clean rise-from-behind-a-mask reveal.

## Horizontal scroll panels

```jsx
useGSAP(() => {
  const track = root.current.querySelector('.track');
  const panels = gsap.utils.toArray('.panel', track);
  gsap.to(track, { xPercent: -100 * (panels.length - 1), ease: 'none',
    scrollTrigger: { trigger: root.current, pin: true, scrub: 1,
      end: () => '+=' + track.offsetWidth, invalidateOnRefresh: true } });
}, { scope: root });
```
`invalidateOnRefresh: true` recomputes widths on resize. Track needs `width: max-content` and panels `flex: 0 0 100vw`.

## Pinned scene with stepped content (Apple-style)

```jsx
useGSAP(() => {
  const tl = gsap.timeline({
    scrollTrigger: { trigger: root.current, start: 'top top', end: '+=300%', pin: '.visual', scrub: true },
  });
  tl.to('.visual img', { scale: 1.1 })
    .from('.step-2', { autoAlpha: 0, y: 40 }, 0.33)
    .from('.step-3', { autoAlpha: 0, y: 40 }, 0.66);
}, { scope: root });
```
Pin only the visual (`pin: '.visual'`) while the text column scrolls normally.

## Batched reveals (grids)

```jsx
useGSAP(() => {
  ScrollTrigger.batch('.card', { start: 'top 85%',
    onEnter: (els) => gsap.from(els, { y: 50, autoAlpha: 0, stagger: 0.08, overwrite: true }) });
}, { scope: root });
```

## Debugging checklist
- Wrong trigger positions → `ScrollTrigger.refresh()` after media loads; check for layout shift.
- Nothing animates → confirm plugin registered and selector is inside the scoped ref.
- Double animations after edit/HMR → you're not inside `useGSAP` (or not scoped).
- Janky scrub → animate transform/opacity only; add a `scrub` number for smoothing.
- Add `markers: true` to any ScrollTrigger to see start/end; remove before shipping.

---

# Starter scaffold

A complete, runnable Vite + React project with the plumbing correct: Lenis synced to ScrollTrigger, plugins registered once, `useGSAP` cleanup, and reduced-motion respected at the root. Write these files out, then `npm install && npm run dev`. Add sections by copying one in `src/sections/` and dropping it into `App.jsx`.

### `package.json`
```json
{
  "name": "scroll-storytelling-starter",
  "private": true,
  "version": "0.1.0",
  "type": "module",
  "scripts": { "dev": "vite", "build": "vite build", "preview": "vite preview" },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "gsap": "^3.13.0",
    "@gsap/react": "^2.1.2",
    "lenis": "^1.1.18"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.3.4",
    "vite": "^5.4.10"
  }
}
```

### `vite.config.js`
```js
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({ plugins: [react()] });
```

### `index.html`
```html
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Scroll Storytelling</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
```

### `src/main.jsx`
```jsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import App from './App.jsx';
import './index.css';

gsap.registerPlugin(ScrollTrigger, useGSAP);

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode><App /></React.StrictMode>
);
```

### `src/lib/useLenis.js`
```js
import { useEffect } from 'react';
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

// Smooth scroll synced to ScrollTrigger; native scroll when reduced motion is preferred.
export function useLenis() {
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const lenis = new Lenis({ duration: 1.1, smoothWheel: true });
    lenis.on('scroll', ScrollTrigger.update);
    const raf = (time) => lenis.raf(time * 1000);
    gsap.ticker.add(raf);
    gsap.ticker.lagSmoothing(0);
    return () => { gsap.ticker.remove(raf); lenis.destroy(); };
  }, []);
}
```

### `src/App.jsx`
```jsx
import { useLenis } from './lib/useLenis.js';
import HeroPin from './sections/HeroPin.jsx';
import TextReveal from './sections/TextReveal.jsx';
import ParallaxLayers from './sections/ParallaxLayers.jsx';
import HorizontalPanels from './sections/HorizontalPanels.jsx';

export default function App() {
  useLenis();
  return (
    <main>
      <HeroPin />
      <TextReveal />
      <ParallaxLayers />
      <HorizontalPanels />
      <footer className="end">fin.</footer>
    </main>
  );
}
```

### `src/sections/HeroPin.jsx`
```jsx
import { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';

export default function HeroPin() {
  const root = useRef(null);
  useGSAP(() => {
    const mm = gsap.matchMedia();
    mm.add('(prefers-reduced-motion: no-preference)', () => {
      gsap.timeline({
        scrollTrigger: { trigger: root.current, start: 'top top', end: '+=150%',
          pin: true, scrub: true, anticipatePin: 1 },
      })
        .from('.hero-title', { yPercent: 30, autoAlpha: 0, ease: 'none' })
        .to('.hero-bg', { scale: 1.25, ease: 'none' }, '<');
    });
    mm.add('(prefers-reduced-motion: reduce)', () => {
      gsap.set('.hero-title', { autoAlpha: 1, yPercent: 0 });
    });
  }, { scope: root });

  return (
    <section ref={root} className="hero">
      <div className="hero-bg" />
      <h1 className="hero-title">Scroll<br />to begin</h1>
    </section>
  );
}
```

### `src/sections/TextReveal.jsx`
```jsx
import { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';

// Swap in GSAP SplitText for per-line masking — see the cookbook. This reveals block elements.
export default function TextReveal() {
  const root = useRef(null);
  useGSAP(() => {
    const mm = gsap.matchMedia();
    mm.add('(prefers-reduced-motion: no-preference)', () => {
      gsap.from('.line', {
        yPercent: 100, autoAlpha: 0, duration: 1, ease: 'power4.out', stagger: 0.12,
        scrollTrigger: { trigger: root.current, start: 'top 75%', once: true },
      });
    });
    mm.add('(prefers-reduced-motion: reduce)', () => {
      gsap.set('.line', { autoAlpha: 1, yPercent: 0 });
    });
  }, { scope: root });

  return (
    <section ref={root} className="reveal-section">
      <div className="reveal-stack">
        <span className="line">Sections pin.</span>
        <span className="line">Text rises.</span>
        <span className="line">Layers drift.</span>
      </div>
    </section>
  );
}
```

### `src/sections/ParallaxLayers.jsx`
```jsx
import { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';

export default function ParallaxLayers() {
  const root = useRef(null);
  useGSAP(() => {
    const mm = gsap.matchMedia();
    mm.add('(prefers-reduced-motion: no-preference)', () => {
      gsap.utils.toArray('[data-speed]').forEach((el) => {
        const speed = parseFloat(el.dataset.speed);
        gsap.to(el, { yPercent: -20 * speed, ease: 'none',
          scrollTrigger: { trigger: root.current, start: 'top bottom', end: 'bottom top', scrub: true } });
      });
    });
  }, { scope: root });

  return (
    <section ref={root} className="parallax">
      <div className="p-layer p-back" data-speed="0.4" />
      <div className="p-layer p-mid" data-speed="0.9" />
      <h2 className="p-layer p-front" data-speed="1.4">depth</h2>
    </section>
  );
}
```

### `src/sections/HorizontalPanels.jsx`
```jsx
import { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';

export default function HorizontalPanels() {
  const root = useRef(null);
  useGSAP(() => {
    const mm = gsap.matchMedia();
    mm.add('(prefers-reduced-motion: no-preference)', () => {
      const track = root.current.querySelector('.track');
      const panels = gsap.utils.toArray('.panel', track);
      gsap.to(track, { xPercent: -100 * (panels.length - 1), ease: 'none',
        scrollTrigger: { trigger: root.current, pin: true, scrub: 1,
          end: () => '+=' + track.offsetWidth, invalidateOnRefresh: true } });
    });
  }, { scope: root });

  return (
    <section ref={root} className="horizontal">
      <div className="track">
        <div className="panel">01</div>
        <div className="panel">02</div>
        <div className="panel">03</div>
        <div className="panel">04</div>
      </div>
    </section>
  );
}
```

### `src/index.css`
```css
:root { --bg:#0b0b0f; --fg:#f4f1ea; --accent:#e85d2a; }
* { margin:0; padding:0; box-sizing:border-box; }
html, body { background:var(--bg); color:var(--fg);
  font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, sans-serif; }
section { position:relative; }

.hero { height:100vh; display:grid; place-items:center; overflow:hidden; }
.hero-bg { position:absolute; inset:0;
  background:radial-gradient(120% 120% at 50% 0%, #1c1c28 0%, #0b0b0f 60%); will-change:transform; }
.hero-title { position:relative; font-size:clamp(3rem,12vw,11rem); line-height:.9;
  font-weight:800; text-align:center; letter-spacing:-0.03em; }

.reveal-section { min-height:90vh; display:grid; place-items:center; padding:10vh 6vw; }
.reveal-stack { display:flex; flex-direction:column; gap:.2em; overflow:hidden; }
.reveal-stack .line { display:block; font-size:clamp(2rem,7vw,6rem); font-weight:700; letter-spacing:-0.02em; }
.reveal-stack .line:nth-child(2){ color:var(--accent); }

.parallax { height:100vh; display:grid; place-items:center; overflow:hidden; }
.p-layer { position:absolute; will-change:transform; }
.p-back { inset:-20% -10%; background:
  radial-gradient(40% 40% at 30% 30%, #23314d 0, transparent 60%),
  radial-gradient(50% 50% at 75% 70%, #3a1f3d 0, transparent 60%); }
.p-mid { width:42vw; height:42vw; border-radius:50%;
  background:linear-gradient(140deg,var(--accent),#b23); filter:blur(2px); opacity:.9; }
.p-front { position:relative; font-size:clamp(3rem,14vw,13rem); font-weight:800;
  letter-spacing:-0.04em; mix-blend-mode:difference; }

.horizontal { height:100vh; overflow:hidden; }
.horizontal .track { display:flex; width:max-content; height:100vh; }
.horizontal .panel { width:100vw; height:100vh; flex:0 0 100vw; display:grid; place-items:center;
  font-size:clamp(4rem,20vw,18rem); font-weight:800; color:var(--bg); }
.horizontal .panel:nth-child(1){ background:#e85d2a; }
.horizontal .panel:nth-child(2){ background:#f4f1ea; }
.horizontal .panel:nth-child(3){ background:#5b8def; }
.horizontal .panel:nth-child(4){ background:#9bd14f; }

.end { height:60vh; display:grid; place-items:center; font-size:2rem; opacity:.5; }
@media (prefers-reduced-motion: reduce) { html { scroll-behavior:auto; } }
```
