---
name: copilot-saltds-screen-parser
description: >
  Parse images and PDFs of screen designs, mockups, wireframes, or UI screenshots and
  recreate them as production-grade React components using the Salt Design System
  (@salt-ds/core and @salt-ds/lab). Use this skill whenever the user shares a design
  image, screenshot, PDF mockup, Figma export, or UI sketch and wants it converted into
  Salt DS React code. Also trigger when the user asks to "build this screen", "implement
  this design", "convert this mockup to code", "recreate this UI with Salt", "turn this
  screenshot into components", or mentions "Salt DS", "Salt Design System", "J.P. Morgan
  design system" alongside a design file. Always use this skill when a visual design
  artifact is the primary input and Salt DS React output is the target — even if the user
  doesn't explicitly mention "Salt" but is working in a J.P. Morgan / JPMC codebase.
---

# Copilot Salt DS Screen Parser

Parse a screen design (image, PDF, wireframe, Figma export) and reproduce it as
production-grade **React + Salt Design System** (`@salt-ds/core` + `@salt-ds/lab`) code
ready for GitHub Copilot to refine, extend, or integrate into a real codebase.

---

## ⚠️ Core Interaction Rules

These rules govern every phase of this skill without exception:

1. **Stop and ask when uncertain.** Never silently resolve ambiguity. If something in the design is unclear, collect all uncertainties into a numbered question block and wait for the user to answer before continuing.

2. **Inline responses.** The user answers in chat. Pick up exactly where you left off, incorporating their answers, then continue to the next phase.

3. **One hard gate before building.** After analysis is complete, produce a **Planning Document** (`.md` file), present it to the user, and explicitly ask for approval. Generate no code until you receive it.

4. **Confirm after each phase if results are surprising.** If a phase produces a non-obvious or potentially controversial mapping, surface it briefly and ask "Does this look right?" before moving on.

5. **Never assume. Never invent.** Mark any unreadable text, any unidentifiable component, and any interaction you cannot infer — and ask.

---

## Workflow Overview

```
STEP 0 — Script Parsing  ◀ ALWAYS FIRST — no LLM vision used here
         Run parse_image.py or parse_pdf.py on the input file.
         These programs use OpenCV, PyMuPDF, and Tesseract OCR to extract
         text, shapes, regions, and repeated patterns — no LLM involvement.
         ↓
STEP 1 — Analysis & Clarification
         Interpret the parser JSON. Classify the design.
         Surface parser-flagged ambiguities as numbered questions.
         ↓
         [ASK] Wait for user response before proceeding.
         ↓
STEP 2 — Component Inventory
         Map every detected element to a Salt DS component.
         ↓
         [ASK] Pause mid-inventory for any element with no clear mapping.
         Wait for user response before continuing.
         ↓
STEP 3 — Layout Skeleton
         Build the annotated layout tree from parser region data.
         ↓
         [CONFIRM] Brief summary + "Does this look right?" gate.
         Wait for go-ahead.
         ↓
STEP 4 — Planning Document  ◀ HARD GATE
         Write the full plan as a .md file.
         Present it. Ask for explicit approval.
         ↓
         [REVISE] If user requests changes, update plan and re-present.
         Repeat until approved.
         ↓
STEP 5 — Build  (only after explicit approval)
         • Copilot Context Block
         • TSX Scaffold
         • 3 Copilot Prompts
```

---

## STEP 0 — Script Parsing (Always First)

**All structural extraction is done by the parser scripts — not by LLM vision.**
Run the appropriate script first. Read its JSON output. Base all subsequent steps on that
structured data.

### 0.1 Find the Input File

```bash
ls /mnt/user-data/uploads/
```

### 0.2 Install Dependencies

```bash
pip install pymupdf Pillow pytesseract opencv-python-headless numpy --break-system-packages -q
# Ensure tesseract is present:
tesseract --version 2>/dev/null || apt-get install -y tesseract-ocr
```

### 0.3 Run the Correct Parser

Copy the scripts from the skill directory to a writable location first:

```bash
cp /path/to/skill/scripts/parse_image.py /tmp/parse_image.py
cp /path/to/skill/scripts/parse_pdf.py   /tmp/parse_pdf.py
```

**Image files** (PNG, JPG, WEBP, BMP — screenshots, Figma exports, wireframes):

```bash
python3 /tmp/parse_image.py \
  /mnt/user-data/uploads/<filename> \
  --out /tmp/parsed.json \
  --debug-dir /tmp/parse_debug
```

**PDF files** (design PDFs, multi-page specs, exported Figma PDFs):

```bash
python3 /tmp/parse_pdf.py \
  /mnt/user-data/uploads/<filename> \
  --out /tmp/parsed.json \
  --pages 1,2,3    # optional: specific pages only
  --dpi 150         # optional: OCR fallback resolution (default 150)
```

### 0.4 Validate the Output

```bash
python3 - <<'EOF'
import json, sys
r = json.load(open('/tmp/parsed.json'))
data = r['pages'][0] if 'pages' in r else r
mode = data.get('mode') or r.get('colour', {}).get('mode', '?')
print(f"Mode:            {mode}")
print(f"Regions:         {list(data['regions'].keys())}")
print(f"Text blocks:     {data['summary']['text_block_count']}")
print(f"UI elements:     {data['summary']['element_count']}")
print(f"Patterns:        {data['summary']['repeated_pattern_count']}")
print(f"Ambiguities:     {r['summary']['ambiguity_count']}")
if data['summary']['text_block_count'] == 0:
    print("⚠️  WARNING: No text extracted — OCR may have failed", file=sys.stderr)
if not data['regions']:
    print("⚠️  WARNING: No regions detected — file may be blank", file=sys.stderr)
EOF
```

If parsing fails or produces zero text blocks on a text-heavy design, report the error
to the user and ask them to verify the file before continuing.

### 0.5 Parser Output Schema

Both scripts emit this structure (PDF wraps pages in a `pages[]` array):

```json
{
  "source": "design.png",
  "dimensions": { "w": 1440, "h": 900 },
  "colour": { "mode": "light", "palette": [...] },
  "regions": {
    "header":  { "x": 0, "y": 0,   "w": 1440, "h": 64  },
    "sidebar": { "x": 0, "y": 64,  "w": 240,  "h": 836 },
    "main":    { "x": 240, "y": 64,"w": 1200, "h": 836 },
    "footer":  { "x": 0, "y": 860, "w": 1440, "h": 40  }
  },
  "text_blocks": [
    { "text": "Dashboard", "x": 260, "y": 20, "w": 120, "h": 24,
      "font_size": 18, "is_heading": true, "region": "header", "source": "native" }
  ],
  "ui_elements": [
    { "type": "button_candidate", "x": 1060, "y": 20, "w": 100, "h": 36,
      "confidence": "medium", "region": "header",
      "notes": ["Filled rectangle with button proportions"] }
  ],
  "repeated_patterns": [
    { "type": "card_candidate", "count": 3, "arrangement": "horizontal",
      "note": "3 similar cards — likely a repeated component" }
  ],
  "ambiguities": [
    { "id": 1, "region": "main",
      "observation": "3 repeated card_candidates detected horizontally.",
      "question": "What data do these repeated units represent?" }
  ],
  "summary": { "text_block_count": 24, "element_count": 18, ... }
}
```

---

## STEP 1 — Analysis & Clarification

Interpret the parser JSON. **Do not re-extract what the parser already found.**

### 1.1 Classification from Parser Data

| Design property | Where to find it in JSON |
|-----------------|--------------------------|
| **Mode** | `colour.mode` (image) or `mode` (PDF page) — always trust the parser |
| **Density** | Mean element `h` values: <30pt → high, 30–50pt → medium, >50pt → low |
| **Page type** | `regions` keys + heading text blocks + element type distribution |
| **Primary action** | Highest-confidence `button_candidate` in `main` region |
| **Repeated units** | `repeated_patterns[]` — already detected by the script |
| **Multi-screen** | `pages[]` length > 1 (PDF) or two distinct heading clusters (image) |

Select a Salt DS aesthetic direction (see `references/saltds-tokens.md` §Aesthetic Directions).

### 1.2 When to Ask

Before proceeding to Step 2, ask about **all** of the following that apply:

- Each entry in `ambiguities[]` — surface the parser's `question` field verbatim
- Any `text_blocks` with `conf < 55` (image) or `source = "ocr"` (PDF) — OCR errors likely
- Any `ui_elements` with `confidence = "low"` in a prominent region
- `repeated_patterns` — the parser found them but doesn't know what data they hold
- Multiple PDF pages — are these separate screens, states, or a flow?

### 1.3 Clarification Format

One numbered block — never buried in prose:

---

> **🔍 Parser ran successfully. Before I map this design, I need a few clarifications:**
>
> **1. [from parser ambiguity / low-confidence OCR]:** [observation] — [question].
>
> **2. [repeated pattern]:** The parser detected [N] [type]s arranged [direction]ly.
> What data does each unit represent? What fields are visible in each?
>
> **3. [unlabelled element]:** [N] button-shaped element(s) have no readable label.
> What are their labels or icons?
>
> _Please answer inline and I'll continue once I have your responses._

---

**Wait.** Do not proceed to Step 2 until the user has responded.

---

## STEP 2 — Component Inventory

Scan the design **top-to-bottom, left-to-right**. For every visible element, produce one entry:

```
[ELEMENT]    Natural language description of what you see
[REGION]     Where it lives (header / sidebar / main / footer / modal / overlay)
[TYPE]       UI primitive type (button, input, table, nav, card, badge, icon…)
[SALT]       Best-fit Salt DS component name
[PROPS]      Visible prop values (label text, disabled state, variant, selected…)
[AMBIGUITY]  (optional) Anything still unclear after Step 1 answers
```

### Mid-Inventory Clarification

If during the inventory you encounter an element where:
- No Salt DS component clearly fits
- Two or more Salt DS components are plausible and would lead to meaningfully different implementations
- The element appears custom with no pattern match

…stop, note it, and ask before continuing:

---

> **🔍 Inventory pause — quick question:**
>
> **Element:** [describe what you see and where it is]
>
> **Options:**
> - **A:** Map to `[ComponentA]` — [implication for the implementation]
> - **B:** Map to `[ComponentB]` — [implication for the implementation]
> - **C:** Treat as custom — use a `Card` with inner layout and leave a `// TODO:` comment
>
> Which would you prefer?

---

### Component Map — Core (`@salt-ds/core`)

| Visual Element | Salt DS Component | Key Props |
|----------------|-------------------|-----------|
| Page wrapper / app shell | `SaltProvider` | `density`, `mode`, `theme` |
| Vertical stack | `StackLayout direction="column"` | `gap` |
| Horizontal stack | `StackLayout direction="row"` | `gap`, `align`, `justify` |
| n-column grid | `GridLayout` | `columns`, `rows`, `gap` |
| Flow / wrapping row | `FlowLayout` | `gap`, `justify` |
| Left+right split row | `SplitLayout` | `startItem`, `endItem` |
| Static card / panel | `Card` | `variant` |
| Clickable / selectable card | `InteractableCard` | `selected`, `onClick` |
| Primary CTA button | `Button sentiment="accented" appearance="solid"` | `onClick`, `disabled` |
| Secondary button | `Button appearance="bordered"` | `sentiment` |
| Ghost / text button | `Button appearance="transparent"` | |
| Text input | `Input` | `value`, `onChange`, `placeholder`, `disabled` |
| Multi-line textarea | `Textarea` | `rows`, `onChange` |
| Dropdown / select | `Dropdown` + `Option` | `selected`, `onSelectionChange`, `placeholder` |
| Combo box | `ComboBox` | `onChange`, `onSelectionChange` |
| Checkbox | `Checkbox` | `checked`, `onChange`, `indeterminate` |
| Radio button | `RadioButton` | `checked`, `onChange` |
| Toggle switch | `Switch` | `checked`, `onChange` |
| Form field wrapper | `FormField` | `validationStatus` |
| Field label | `FormFieldLabel` | |
| Field helper / hint text | `FormFieldHelperText` | |
| Tabs / tab bar | `Tabs` + `Tab` + `TabPanel` | `activeTabIndex` |
| Pill / chip | `Pill` | `label`, `onClose`, `onClick` |
| Avatar | `Avatar` | `name`, `src`, `size` |
| Badge / notification dot | `Badge` | `value`, `max` |
| Progress bar | `LinearProgress` | `value`, `aria-label` |
| Spinner / loading | `CircularProgress` | `aria-label` |
| Tooltip | `Tooltip` | `content`, `placement` |
| Alert / banner | `Banner` + `BannerContent` | `status` |
| Dialog / modal | `Dialog` + `DialogHeader` + `DialogContent` + `DialogActions` | `open` |
| Overlay / panel | `Overlay` | `open`, `placement` |
| Display text (hero) | `Display1` / `Display2` | |
| Page heading | `H1` / `H2` / `H3` / `H4` | |
| Body text | `Text` | `styleAs` |
| Label / caption | `Label` | `disabled` |
| Icon | `@salt-ds/icons` (e.g. `SearchIcon`) | `size` |
| Status dot | `StatusIndicator` | `status` (`error`/`warning`/`success`/`info`) |
| Divider / separator | `Divider` | `orientation` |
| Navigation item / link | `NavigationItem` | `active`, `href`, `level` |
| Country / flag symbol | `CountrySymbol` | `code` |
| Menu / context menu | `Menu` + `MenuItem` + `MenuTrigger` | |

### Component Map — Labs (`@salt-ds/lab`)

| Visual Element | Salt DS Lab Component | Notes |
|----------------|-----------------------|-------|
| Date / date-range picker | `DatePicker` | |
| File drag-and-drop zone | `FileDropZone` + `FileDropZoneTrigger` | |
| Wizard / stepper progress | `SteppedTracker` + `TrackerStep` | |
| Colour picker | `ColorChooser` | |
| Tree / nested navigation | `Tree` + `TreeItem` | |
| Cascading / mega menu | `CascadingMenu` | |
| Drawer / slide-in panel | `Drawer` | |
| Breadcrumb trail | `Breadcrumbs` + `Breadcrumb` | |
| Tag / token input | `TokenizedInput` | |
| Scrollable / virtual list | `List` | |

> **When in doubt**: check `references/saltds-patterns.md` for the closest named pattern.
> Salt DS docs: https://www.saltdesignsystem.com/salt/components/overview

---

## STEP 3 — Layout Skeleton

Translate the visual hierarchy into a Salt DS layout tree:

```
SaltProvider [density=? mode=?]
└── StackLayout direction="column"             ← full-page wrapper
    ├── [Header]
    │   └── SplitLayout
    │       ├── startItem: Logo + NavigationItem × n
    │       └── endItem: Avatar, Button
    ├── GridLayout columns={12}                ← main content
    │   ├── GridItem colSpan={3}               ← sidebar
    │   │   └── StackLayout direction="column"
    │   │       └── NavigationItem × n
    │   └── GridItem colSpan={9}               ← content
    │       └── StackLayout direction="column"
    │           ├── H2 "Page Title"
    │           └── GridLayout columns={3}
    │               └── Card × n
    └── [Footer]
```

Annotate every node with:
- Component name + key props
- Text content (verbatim if readable; `[TEXT: unreadable]` if not)
- Observed states: selected, disabled, error, loading, empty

### After the skeleton, send a brief confirmation:

---

> **✅ Layout skeleton complete.** Here's a summary of what I've mapped:
> - [1–2 sentences on the overall structure]
> - [Call out any non-obvious choices, e.g. "I've used a fluid 12-column grid rather than a fixed-width sidebar because the design appears responsive"]
> - [List any elements still marked `[TEXT: unreadable]` that will become TODOs]
>
> Does this match your expectations? Let me know if you'd like to adjust anything before I write the plan.

---

Wait for the user's response. If they request changes, update the skeleton and re-confirm.

---

## STEP 4 — Planning Document (Hard Gate)

Once Steps 1–3 are complete and all clarifications are resolved, write the full plan as a
Markdown file. Save it, then present the approval gate. **Generate no code until approved.**

### File name: `[screen-name]-salt-plan.md`

```markdown
# Salt DS Implementation Plan — [Screen Name]

> **Status:** DRAFT — awaiting approval
> **Source:** [brief description of the design input]

---

## 1. Design Summary

| Property | Value |
|----------|-------|
| Page type | [dashboard / form / list / detail / dialog / wizard / other] |
| Salt DS density | `[high / medium / low / touch]` |
| Salt DS mode | `[light / dark]` |
| Aesthetic direction | [direction name] |
| Primary user action | [description] |
| Packages required | `@salt-ds/core`, `@salt-ds/theme`[, `@salt-ds/lab`][, `@salt-ds/data-grid`] |

---

## 2. Clarifications & Decisions

| # | Question | Resolution |
|---|----------|------------|
| 1 | [question asked] | [answer received or decision made] |
| … | … | … |

_(Write "None — design was unambiguous" if no questions were needed.)_

---

## 3. Component Inventory

| # | Element | Region | Salt DS Component | Props / Notes |
|---|---------|--------|-------------------|---------------|
| 1 | [element description] | [region] | `ComponentName` | [key props] |
| … | … | … | … | … |

---

## 4. Layout Skeleton

\`\`\`
[Full annotated tree from Step 3]
\`\`\`

---

## 5. File Structure

\`\`\`
src/
├── components/
│   └── [ScreenName]/
│       ├── [ScreenName].tsx        ← main scaffold
│       ├── [ScreenName].css        ← token overrides (if any)
│       └── [SubComponent].tsx      ← extracted repeated units (if any)
└── types/
    └── [ScreenName].types.ts       ← TypeScript interfaces
\`\`\`

---

## 6. Interactivity Plan

| Element | Trigger | Behaviour | State |
|---------|---------|-----------|-------|
| [component] | [click/change/focus] | [what happens] | `useState([type])` |
| … | … | … | … |

---

## 7. Open TODOs

Items that cannot be resolved from the design alone and will be left for Copilot:

| # | Location | What's missing | Suggested approach |
|---|----------|---------------|--------------------|
| 1 | [component / region] | [what's unknown] | [how to handle it] |
| … | … | … | … |

---

## 8. Pattern References

Named Salt DS patterns used (from `references/saltds-patterns.md`):

| Pattern | Used for |
|---------|----------|
| [Pattern Name] | [region or component] |
| … | … |

---

## 9. Copilot Prompt Sequence

**Prompt A — Scaffold completion**
[Full text, specific to this design]

**Prompt B — Interactivity**
[Full text, listing specific interactions from §6]

**Prompt C — Accessibility pass**
[Full text]

---

## 10. Build Checklist

- [ ] `SaltProvider` with explicit `density` and `mode`
- [ ] `@salt-ds/theme/index.css` imported first
- [ ] Open Sans + PT Mono fonts loaded
- [ ] No hardcoded hex colors — Salt tokens only
- [ ] No hardcoded px spacing — Salt spacing tokens only
- [ ] No raw `<button>`, `<input>`, `<select>` — Salt equivalents only
- [ ] All layout via `StackLayout` / `GridLayout` / `FlowLayout` / `SplitLayout`
- [ ] No Tailwind classes
- [ ] All interactive states mapped to Salt props
- [ ] `[UNREADABLE]` markers for unclear text/elements
- [ ] All 3 Copilot prompts present and design-specific
```

### Approval Gate Message

After saving the file, send **only** this — no code:

---

> **📋 Implementation plan ready: `[screen-name]-salt-plan.md`**
>
> Here's what's inside:
> - **[N] components** inventoried across [regions]
> - **Density:** `[X]` · **Mode:** `[X]` · **Direction:** [X]
> - **[N] interactive elements** planned with state
> - **[N] open TODOs** for Copilot to complete
> - **[N] Salt DS patterns** referenced
>
> **Please review the plan above and tell me:**
> - ✅ **"Approved"** / **"Looks good, build it"** — I'll generate the Copilot context block, TSX scaffold, and all 3 prompts
> - ✏️ **What to change** — describe any corrections and I'll update the plan and re-present it
> - ❓ **Any questions** — ask and I'll clarify before building
>
> _No code will be generated until you approve._

---

If the user requests revisions: update the plan document, save it, and repeat the approval gate. Keep iterating until the user explicitly approves.

---

## STEP 5 — Build (Only After Explicit Approval)

Generate all three outputs in sequence.

### 5.1 Copilot Context Block

```
# === COPILOT CONTEXT: SALT DS SCREEN RECREATION ===
# Source: [image type and brief description]
# Page type: [type]
# Salt DS density: [density]
# Salt DS mode: [mode]
# Aesthetic direction: [direction]
# Plan document: [screen-name]-salt-plan.md
# =====================================================

## Component Inventory
[Full inventory from Step 2]

## Layout Skeleton
[Full annotated tree from Step 3]

## Open TODOs for Copilot
[From plan §7]

## Pattern References
[From plan §8]

# === END CONTEXT ===
```

### 5.2 TSX Scaffold

```tsx
// AUTO-GENERATED SCAFFOLD — Review and complete with GitHub Copilot
// Plan: [screen-name]-salt-plan.md

import {
  SaltProvider,
  StackLayout,
  GridLayout,
  GridItem,
  // ... every @salt-ds/core component used — explicit, no barrel imports
} from "@salt-ds/core";
import {
  // ... every @salt-ds/lab component (remove block if none needed)
} from "@salt-ds/lab";
import "@salt-ds/theme/index.css";
// TODO: import specific icons — e.g. import { SearchIcon } from "@salt-ds/icons"

// ── Types ──────────────────────────────────────────────────────────────────
interface [ScreenName]Props {
  // TODO: define from §5 of the plan
}

// ── Mock data ──────────────────────────────────────────────────────────────
// TODO: replace with real data source / API
const MOCK_DATA = [
  // ... literal values extracted from design
];

// ── [ScreenName] ───────────────────────────────────────────────────────────
export function [ScreenName]() {
  // State — from §6 of the plan
  // TODO: const [activeTab, setActiveTab] = useState(0);

  return (
    <SaltProvider density="[density]" mode="[mode]">
      <StackLayout
        direction="column"
        style={{
          minHeight: "100vh",
          background: "var(--salt-container-primary-background)",
        }}
      >

        {/* ── Header / Navigation ────────────────────────────────────── */}
        {/* TODO: implement SplitLayout header from layout skeleton */}

        {/* ── Main Content ───────────────────────────────────────────── */}
        <GridLayout
          columns={12}
          gap={3}
          style={{ padding: "var(--salt-spacing-500)", flex: 1 }}
        >
          {/* TODO: GridItems from layout skeleton */}
        </GridLayout>

        {/* ── Footer ─────────────────────────────────────────────────── */}
        {/* TODO: implement or remove */}

      </StackLayout>
    </SaltProvider>
  );
}
```

### 5.3 Copilot Prompt Sequence

Write all three prompts fully — every prompt must be specific to this design, not generic templates.

**Prompt A — Scaffold completion**
```
Here is a TSX scaffold for [ScreenName] built with Salt Design System (@salt-ds/core).
Refer to the context block above for the full component inventory and layout skeleton.
Complete the scaffold by filling in every TODO comment with working Salt DS code.
Constraints:
- Use only @salt-ds/core, @salt-ds/lab, @salt-ds/icons — no Tailwind, no custom classes
- All spacing: var(--salt-spacing-*) tokens only
- All colors: var(--salt-*) tokens only
- No raw <button>, <input>, <select>, <textarea> — use Salt equivalents
- All layout: StackLayout / GridLayout / FlowLayout / SplitLayout — no raw div flex
```

**Prompt B — Interactivity**
```
[ScreenName] scaffold is structurally complete. Add controlled React state for:
[— list each row from §6 of the plan, verbatim —]
Rules:
- React useState / useReducer only — no external state library
- Every Salt DS interactive component must be controlled (value + onChange)
- Form validation should use FormField validationStatus prop
```

**Prompt C — Accessibility pass**
```
Run a full accessibility audit on [ScreenName] and fix all issues found:
- Every interactive element: aria-label or visible FormFieldLabel
- Keyboard navigation: Tabs, Dropdown, Dialog, NavigationItem must be fully operable by keyboard
- StatusIndicator: must pair with visible text — never rely on color alone for status
- Focus ring: do NOT suppress outline — Salt handles this via var(--salt-focused-outlineColor)
- Form fields: every Input / Textarea / Dropdown must be inside FormField with FormFieldLabel
Report what you changed. Do not alter visual layout, component choices, or Salt tokens.
```

---

## Reference Files

Load only when needed — not upfront:

- `references/saltds-tokens.md` — token reference, aesthetic directions, density/mode guide _(Steps 1–2)_
- `references/saltds-patterns.md` — 20 named patterns with working code blueprints _(Steps 2–3 when a complex pattern appears)_

---

## Quality Rules

- **Stop and ask** rather than silently resolve — always, at any step
- **Never invent components** — no Salt DS match? Use `Card` + layout + `// TODO:` note
- **Mark unreadable text** as `[TEXT: unreadable]` — never fabricate copy
- **Preserve visual hierarchy** — prominence in the design must map to heading level and button variant
- **Never use Tailwind** — regardless of the design's origin
- **State is always explicit** — every visible interactive state maps to a named Salt DS prop
- **Hard gate stands** — no code before plan approval, no exceptions
