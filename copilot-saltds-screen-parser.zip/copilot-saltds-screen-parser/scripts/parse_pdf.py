#!/usr/bin/env python3
"""
parse_pdf.py — Extract structured UI information from a PDF design file.

Usage:
    python3 parse_pdf.py <pdf_path> [--out <output.json>] [--pages 1,2,3] [--dpi 150] [--debug-dir <dir>]

Strategy:
  1. Use PyMuPDF (fitz) to extract native text, fonts, colours, rectangles, and images
     from each page without rasterizing — preserves exact geometry and typography.
  2. If a page has no native text (scanned / flattened PDF), fall back to rasterizing
     that page and running OCR via pytesseract (same path as parse_image.py).
  3. Merge native + OCR data, classify UI element candidates, detect repeated patterns,
     and produce the same JSON schema as parse_image.py so both outputs are interchangeable.

Outputs JSON with:
  - pages[]: per-page analysis (dimensions, mode, regions, text, elements, patterns)
  - ambiguities[]: cross-page questions needing human input
  - summary{}

Dependencies:
    pip install pymupdf Pillow pytesseract numpy --break-system-packages
    System: tesseract-ocr  (apt install tesseract-ocr)
"""

import argparse
import json
import os
import sys
import tempfile
from pathlib import Path

import fitz  # PyMuPDF
import numpy as np
import pytesseract
from PIL import Image

# ── Constants ──────────────────────────────────────────────────────────────

DEFAULT_DPI = 150
DARK_BG_THRESHOLD = 128
MIN_RECT_AREA_PT = 400       # Minimum rectangle area (points²) to be a UI element
TEXT_HEADING_SIZE_PT = 14    # Font size above which text is treated as a heading
MIN_OCR_CONF = 40


# ── Text & font extraction (native) ────────────────────────────────────────

def extract_native_text(page: fitz.Page) -> list:
    """
    Extract text blocks using PyMuPDF's native parser.
    Returns list of: { text, x, y, w, h, font_size, font_name, is_heading, is_bold, colour_hex }
    """
    blocks = []
    for block in page.get_text("dict")["blocks"]:
        if block["type"] != 0:  # 0 = text block
            continue
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                text = span["text"].strip()
                if not text:
                    continue
                x0, y0, x1, y1 = span["bbox"]
                font_size = round(span["size"], 1)
                colour = span.get("color", 0)
                r = (colour >> 16) & 0xFF
                g = (colour >> 8) & 0xFF
                b = colour & 0xFF
                blocks.append({
                    "text": text,
                    "x": round(x0), "y": round(y0),
                    "w": round(x1 - x0), "h": round(y1 - y0),
                    "font_size": font_size,
                    "font_name": span.get("font", ""),
                    "is_heading": font_size >= TEXT_HEADING_SIZE_PT,
                    "is_bold": "Bold" in span.get("font", "") or "bold" in span.get("font", ""),
                    "colour_hex": f"#{r:02x}{g:02x}{b:02x}",
                    "source": "native",
                })
    return blocks


# ── Rectangle / shape extraction (native) ──────────────────────────────────

def extract_native_shapes(page: fitz.Page) -> list:
    """
    Extract drawn rectangles and paths as UI element candidates.
    Returns list of: { x, y, w, h, fill_hex, stroke_hex, type, confidence, notes }
    """
    elements = []
    page_w = page.rect.width
    page_h = page.rect.height

    def colour_to_hex(c):
        if c is None:
            return None
        if isinstance(c, (int, float)):
            v = int(c * 255)
            return f"#{v:02x}{v:02x}{v:02x}"
        if len(c) == 3:
            return "#{:02x}{:02x}{:02x}".format(*[int(x * 255) for x in c])
        if len(c) == 4:  # CMYK — rough convert
            c2, m, y, k = c
            r = int(255 * (1 - c2) * (1 - k))
            g = int(255 * (1 - m) * (1 - k))
            b = int(255 * (1 - y) * (1 - k))
            return f"#{r:02x}{g:02x}{b:02x}"
        return None

    drawings = page.get_drawings()
    for d in drawings:
        rect = d.get("rect")
        if not rect:
            continue
        x0, y0, x1, y1 = rect
        bw = x1 - x0
        bh = y1 - y0
        area = bw * bh
        if area < MIN_RECT_AREA_PT:
            continue
        if bw < 10 or bh < 10:
            continue

        aspect = bw / bh if bh else 0
        area_frac = area / (page_w * page_h) if page_w * page_h else 0
        fill_hex = colour_to_hex(d.get("fill"))
        stroke_hex = colour_to_hex(d.get("color"))

        el_type = "shape_candidate"
        confidence = "low"
        notes = []

        # Button-like
        if 1.5 <= aspect <= 10 and 16 <= bh <= 60 and area_frac < 0.05:
            el_type = "button_candidate"
            confidence = "medium"
            notes.append("Filled rectangle with button proportions")
        # Input-like
        elif aspect >= 2.5 and 18 <= bh <= 55 and area_frac < 0.15:
            el_type = "input_candidate"
            confidence = "medium"
            notes.append("Wide shallow rectangle — likely a text input")
        # Card-like
        elif 0.4 <= aspect <= 4 and area_frac >= 0.01 and bw > 60:
            el_type = "card_candidate"
            confidence = "low"
            notes.append("Large rectangle — likely a card or panel")
        # Tab strip
        elif aspect > 4 and bh < 40 and y0 < page_h * 0.25:
            el_type = "tab_candidate"
            confidence = "low"
            notes.append("Wide shallow strip near top — may be a tab bar")

        elements.append({
            "type": el_type,
            "x": round(x0), "y": round(y0),
            "w": round(bw), "h": round(bh),
            "aspect_ratio": round(aspect, 2),
            "area_fraction": round(area_frac, 4),
            "fill_hex": fill_hex,
            "stroke_hex": stroke_hex,
            "confidence": confidence,
            "notes": notes,
            "source": "native",
        })

    return elements


# ── OCR fallback ────────────────────────────────────────────────────────────

def ocr_page(page: fitz.Page, dpi: int) -> list:
    """Rasterize a page and run Tesseract OCR. Returns text blocks."""
    mat = fitz.Matrix(dpi / 72, dpi / 72)
    pix = page.get_pixmap(matrix=mat)
    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
    data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)
    blocks = []
    scale = dpi / 72
    for i in range(len(data["text"])):
        text = data["text"][i].strip()
        conf = int(data["conf"][i])
        if not text or conf < MIN_OCR_CONF:
            continue
        bh_px = data["height"][i]
        font_size_est = round(bh_px / scale * 0.75, 1)
        blocks.append({
            "text": text,
            "x": round(data["left"][i] / scale),
            "y": round(data["top"][i] / scale),
            "w": round(data["width"][i] / scale),
            "h": round(bh_px / scale),
            "font_size": font_size_est,
            "font_name": "[ocr]",
            "is_heading": font_size_est >= TEXT_HEADING_SIZE_PT,
            "is_bold": False,
            "colour_hex": None,
            "conf": conf,
            "source": "ocr",
        })
    return blocks


# ── Region detection ────────────────────────────────────────────────────────

def infer_regions(text_blocks: list, elements: list, page_w: float, page_h: float) -> dict:
    """
    Infer layout regions from text and element positions.
    Heuristic: group by vertical band.
    """
    top_cutoff = page_h * 0.12
    bottom_cutoff = page_h * 0.88
    left_cutoff = page_w * 0.22

    has_top = any(b["y"] < top_cutoff for b in text_blocks + elements)
    has_bottom = any(b["y"] > bottom_cutoff for b in text_blocks + elements)
    has_left = any(b["x"] < left_cutoff and b["y"] > top_cutoff for b in text_blocks + elements)

    regions = {}
    if has_top:
        regions["header"] = {"x": 0, "y": 0, "w": round(page_w), "h": round(top_cutoff)}
    if has_bottom:
        regions["footer"] = {"x": 0, "y": round(bottom_cutoff), "w": round(page_w), "h": round(page_h - bottom_cutoff)}
    if has_left:
        regions["sidebar"] = {"x": 0, "y": round(top_cutoff), "w": round(left_cutoff), "h": round(bottom_cutoff - top_cutoff)}
    main_x = round(left_cutoff) if has_left else 0
    regions["main"] = {
        "x": main_x,
        "y": round(top_cutoff) if has_top else 0,
        "w": round(page_w - main_x),
        "h": round((bottom_cutoff if has_bottom else page_h) - (top_cutoff if has_top else 0)),
    }
    return regions


def assign_regions(items: list, regions: dict) -> None:
    for item in items:
        x, y = item["x"], item["y"]
        item["region"] = "unknown"
        for name, r in regions.items():
            if r["x"] <= x <= r["x"] + r["w"] and r["y"] <= y <= r["y"] + r["h"]:
                item["region"] = name
                break


# ── Colour mode ─────────────────────────────────────────────────────────────

def estimate_page_mode(page: fitz.Page, dpi: int = 72) -> str:
    """Rasterize at low res to check background luminance."""
    mat = fitz.Matrix(dpi / 72, dpi / 72)
    pix = page.get_pixmap(matrix=mat)
    arr = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
    if pix.n == 4:
        arr = arr[:, :, :3]
    mean_lum = float(np.mean(arr))
    return "dark" if mean_lum < DARK_BG_THRESHOLD else "light"


# ── Repeated patterns ───────────────────────────────────────────────────────

def detect_repeated_units(elements: list) -> list:
    if len(elements) < 3:
        return []
    patterns = []
    by_type: dict = {}
    for el in elements:
        by_type.setdefault(el["type"], []).append(el)
    for etype, group in by_type.items():
        if len(group) < 2:
            continue
        widths = [e["w"] for e in group]
        heights = [e["h"] for e in group]
        if np.std(widths) / (np.mean(widths) + 1) < 0.2 and np.std(heights) / (np.mean(heights) + 1) < 0.2:
            xs = sorted(e["x"] for e in group)
            ys = sorted(e["y"] for e in group)
            x_gaps = [xs[i+1] - xs[i] for i in range(len(xs)-1)]
            y_gaps = [ys[i+1] - ys[i] for i in range(len(ys)-1)]
            horiz = x_gaps and np.std(x_gaps) / (np.mean(x_gaps) + 1) < 0.3
            vert = y_gaps and np.std(y_gaps) / (np.mean(y_gaps) + 1) < 0.3
            if horiz or vert:
                patterns.append({
                    "type": etype,
                    "count": len(group),
                    "avg_w": round(float(np.mean(widths))),
                    "avg_h": round(float(np.mean(heights))),
                    "arrangement": "horizontal" if horiz else "vertical",
                    "note": f"{len(group)} similar {etype}s — likely a repeated component",
                })
    return patterns


# ── Ambiguities ─────────────────────────────────────────────────────────────

def collect_ambiguities(pages: list) -> list:
    ambiguities = []
    aid = 1

    # Multi-page: clarify which pages represent distinct screens vs states
    if len(pages) > 1:
        ambiguities.append({
            "id": aid,
            "scope": "document",
            "observation": f"The PDF has {len(pages)} pages.",
            "question": "Do these pages represent distinct screens, different states of the same screen, or a multi-step flow?",
        })
        aid += 1

    for pg in pages:
        pn = pg["page_number"]

        # Low OCR coverage
        native_text = [b for b in pg["text_blocks"] if b.get("source") == "native"]
        ocr_text = [b for b in pg["text_blocks"] if b.get("source") == "ocr"]
        if not native_text and ocr_text:
            ambiguities.append({
                "id": aid,
                "scope": f"page {pn}",
                "observation": "Page has no native text — OCR was used. Some text may be inaccurate.",
                "question": f"Can you confirm or correct the key text labels on page {pn}?",
            })
            aid += 1

        # No header region
        if "header" not in pg["regions"]:
            ambiguities.append({
                "id": aid,
                "scope": f"page {pn}",
                "observation": "No header / navigation bar was detected.",
                "question": f"Page {pn}: is there a navigation bar? What does it contain?",
            })
            aid += 1

        # Repeated patterns — need data model
        for pat in pg["repeated_patterns"]:
            ambiguities.append({
                "id": aid,
                "scope": f"page {pn}",
                "observation": f"{pat['count']} repeated {pat['type']}s detected ({pat['arrangement']}ly).",
                "question": f"Page {pn}: what data do these repeated units represent? What fields are in each one?",
            })
            aid += 1

        # Unlabelled button candidates
        buttons = [e for e in pg["ui_elements"] if e["type"] == "button_candidate"]
        labelled_positions = {(b["x"], b["y"]) for b in pg["text_blocks"]}
        unlabelled = [b for b in buttons if not any(
            abs(b["x"] - tx) < b["w"] and abs(b["y"] - ty) < b["h"] * 2
            for tx, ty in labelled_positions
        )]
        if len(unlabelled) > 1:
            ambiguities.append({
                "id": aid,
                "scope": f"page {pn}",
                "observation": f"{len(unlabelled)} button-shaped element(s) have no readable label.",
                "question": f"Page {pn}: what are the labels or icons for these buttons?",
            })
            aid += 1

    return ambiguities


# ── Page parser ─────────────────────────────────────────────────────────────

def parse_page(page: fitz.Page, page_number: int, dpi: int) -> dict:
    pw, ph = page.rect.width, page.rect.height

    text_blocks = extract_native_text(page)
    elements = extract_native_shapes(page)

    # Fallback to OCR if no native text was found
    if not text_blocks:
        text_blocks = ocr_page(page, dpi)

    mode = estimate_page_mode(page)
    regions = infer_regions(text_blocks, elements, pw, ph)
    assign_regions(text_blocks, regions)
    assign_regions(elements, regions)
    patterns = detect_repeated_units(elements)

    return {
        "page_number": page_number,
        "dimensions": {"w": round(pw), "h": round(ph)},
        "mode": mode,
        "regions": regions,
        "text_blocks": text_blocks,
        "ui_elements": elements,
        "repeated_patterns": patterns,
        "summary": {
            "text_block_count": len(text_blocks),
            "element_count": len(elements),
            "repeated_pattern_count": len(patterns),
            "mode": mode,
            "detected_regions": list(regions.keys()),
        },
    }


# ── Main ────────────────────────────────────────────────────────────────────

def parse_pdf(pdf_path: str, page_numbers: list = None, dpi: int = DEFAULT_DPI) -> dict:
    doc = fitz.open(pdf_path)
    total_pages = len(doc)
    if page_numbers:
        indices = [p - 1 for p in page_numbers if 1 <= p <= total_pages]
    else:
        indices = list(range(total_pages))

    pages = []
    for idx in indices:
        pg = doc[idx]
        pages.append(parse_page(pg, idx + 1, dpi))
        print(f"[info] Parsed page {idx + 1}/{total_pages}", file=sys.stderr)

    doc.close()
    ambiguities = collect_ambiguities(pages)

    return {
        "source": os.path.basename(pdf_path),
        "total_pages": total_pages,
        "parsed_pages": [p["page_number"] for p in pages],
        "pages": pages,
        "ambiguities": ambiguities,
        "summary": {
            "page_count": len(pages),
            "ambiguity_count": len(ambiguities),
            "modes": list({p["mode"] for p in pages}),
        },
    }


def main():
    parser = argparse.ArgumentParser(description="Parse a PDF design file into structured JSON.")
    parser.add_argument("pdf", help="Path to the PDF file")
    parser.add_argument("--out", default=None, help="Output JSON file (default: stdout)")
    parser.add_argument("--pages", default=None, help="Comma-separated page numbers to parse (default: all)")
    parser.add_argument("--dpi", type=int, default=DEFAULT_DPI, help=f"Raster DPI for OCR fallback (default {DEFAULT_DPI})")
    args = parser.parse_args()

    page_numbers = None
    if args.pages:
        page_numbers = [int(p.strip()) for p in args.pages.split(",")]

    result = parse_pdf(args.pdf, page_numbers=page_numbers, dpi=args.dpi)
    output = json.dumps(result, indent=2, ensure_ascii=False)

    if args.out:
        Path(args.out).write_text(output, encoding="utf-8")
        print(f"Parsed {args.pdf} → {args.out}", file=sys.stderr)
        print(f"Summary: {result['summary']}", file=sys.stderr)
    else:
        print(output)


if __name__ == "__main__":
    main()
