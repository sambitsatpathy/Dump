#!/usr/bin/env python3
"""
parse_image.py — Structural analysis of a UI screenshot or design image.

Usage:
    python3 parse_image.py <image_path> [--out <output.json>] [--debug-dir <dir>]

Outputs a JSON document describing:
  - Image dimensions and estimated DPI
  - Colour mode (light / dark) and dominant palette
  - Detected UI regions (header, sidebar, main, footer, modal overlays)
  - Detected text blocks with bounding boxes, font-size estimate, and OCR content
  - Detected interactive elements (buttons, inputs, cards, tables, tabs, icons)
  - Repeated unit patterns (e.g. card grids, list rows)
  - Structural ambiguities that need human clarification

Dependencies:
    pip install opencv-python-headless Pillow pytesseract numpy --break-system-packages
    System: tesseract-ocr  (apt install tesseract-ocr)
"""

import argparse
import json
import os
import sys
from pathlib import Path

import cv2
import numpy as np
import pytesseract
from PIL import Image

# ── Constants ──────────────────────────────────────────────────────────────

DARK_THRESHOLD = 128          # Mean luminance below this → dark mode
BUTTON_ASPECT_MIN = 1.5       # Minimum width/height ratio for button candidates
BUTTON_ASPECT_MAX = 10.0
BUTTON_HEIGHT_MIN = 16
BUTTON_HEIGHT_MAX = 80
INPUT_ASPECT_MIN = 2.5
INPUT_HEIGHT_MIN = 20
INPUT_HEIGHT_MAX = 70
CARD_AREA_MIN_FRACTION = 0.01 # Card must be at least 1% of total image area
REPEAT_SIMILARITY_THRESHOLD = 0.85
MIN_TEXT_CONF = 40             # Tesseract confidence threshold


# ── Helpers ────────────────────────────────────────────────────────────────

def load_image(path: str):
    """Load image as BGR (cv2) and RGB (PIL)."""
    bgr = cv2.imread(path)
    if bgr is None:
        raise FileNotFoundError(f"Cannot read image: {path}")
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    pil = Image.fromarray(rgb)
    return bgr, rgb, pil


def estimate_mode(rgb: np.ndarray) -> dict:
    """Detect light vs dark mode from mean luminance."""
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    mean_lum = float(np.mean(gray))
    mode = "dark" if mean_lum < DARK_THRESHOLD else "light"

    # Dominant palette — k-means on a small sample
    small = cv2.resize(rgb, (64, 64)).reshape(-1, 3).astype(np.float32)
    _, labels, centers = cv2.kmeans(
        small, 6,
        None,
        (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0),
        3,
        cv2.KMEANS_RANDOM_CENTERS,
    )
    counts = np.bincount(labels.flatten())
    palette = []
    for idx in np.argsort(-counts)[:6]:
        r, g, b = [int(c) for c in centers[idx]]
        palette.append({"hex": f"#{r:02x}{g:02x}{b:02x}", "weight": float(counts[idx]) / len(labels)})

    return {
        "mode": mode,
        "mean_luminance": round(mean_lum, 1),
        "palette": palette,
    }


def detect_regions(rgb: np.ndarray, h: int, w: int) -> dict:
    """
    Heuristic region segmentation using horizontal/vertical edge density.
    Returns bounding boxes for header, footer, sidebar, main, and any modal overlays.
    """
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, 50, 150)

    # Horizontal band density
    h_density = edges.sum(axis=1).astype(float)
    h_density /= (w * 255) if w else 1

    # Vertical band density
    v_density = edges.sum(axis=0).astype(float)
    v_density /= (h * 255) if h else 1

    def find_band(density, size, threshold=0.05, from_end=False):
        """Find first high-density band from start or end."""
        span = min(int(size * 0.25), 200)
        region = density[-span:] if from_end else density[:span]
        high = np.where(region > threshold)[0]
        if len(high) == 0:
            return None
        idx = int(high[-1] if from_end else high[-1])
        return (size - idx - 1) if from_end else idx

    header_y = find_band(h_density, h)
    footer_y = find_band(h_density, h, from_end=True)
    sidebar_x = find_band(v_density, w)

    regions = {}

    if header_y and header_y > 20:
        regions["header"] = {"x": 0, "y": 0, "w": w, "h": header_y}

    footer_start = footer_y if footer_y else None
    if footer_start and (h - footer_start) > 20 and (h - footer_start) < int(h * 0.2):
        regions["footer"] = {"x": 0, "y": footer_start, "w": w, "h": h - footer_start}

    sidebar_w = sidebar_x if sidebar_x else None
    if sidebar_w and sidebar_w > 40 and sidebar_w < int(w * 0.35):
        regions["sidebar"] = {
            "x": 0,
            "y": header_y or 0,
            "w": sidebar_w,
            "h": (footer_start or h) - (header_y or 0),
        }

    main_x = (sidebar_w or 0)
    main_y = (header_y or 0)
    main_w = w - main_x
    main_h = (footer_start or h) - main_y
    regions["main"] = {"x": main_x, "y": main_y, "w": main_w, "h": main_h}

    # Detect modal overlays: large centred rectangles with distinct background
    # Simple heuristic: look for a rectangle occupying 20–70% of area, centred
    modal = _detect_modal(rgb, h, w)
    if modal:
        regions["modal"] = modal

    return regions


def _detect_modal(rgb, h, w):
    """Very basic modal detection via large centred contour."""
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    img_area = h * w
    cx, cy = w / 2, h / 2
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if not (0.15 * img_area < area < 0.75 * img_area):
            continue
        x, y, bw, bh = cv2.boundingRect(cnt)
        # Check it's roughly centred
        if abs((x + bw / 2) - cx) < w * 0.25 and abs((y + bh / 2) - cy) < h * 0.25:
            return {"x": int(x), "y": int(y), "w": int(bw), "h": int(bh)}
    return None


def ocr_text_blocks(pil_img: Image.Image, conf_threshold: int = MIN_TEXT_CONF) -> list:
    """
    Run Tesseract on the full image and return structured text blocks.
    Each block: { text, x, y, w, h, conf, font_size_est, is_heading }
    """
    data = pytesseract.image_to_data(pil_img, output_type=pytesseract.Output.DICT)
    blocks = []
    n = len(data["text"])
    for i in range(n):
        text = data["text"][i].strip()
        conf = int(data["conf"][i])
        if not text or conf < conf_threshold:
            continue
        bh = data["height"][i]
        # Rough font size estimate from bounding box height
        font_size_est = max(8, round(bh * 0.75))
        is_heading = font_size_est >= 20
        blocks.append({
            "text": text,
            "x": data["left"][i],
            "y": data["top"][i],
            "w": data["width"][i],
            "h": bh,
            "conf": conf,
            "font_size_est": font_size_est,
            "is_heading": is_heading,
        })
    return blocks


def detect_ui_elements(bgr: np.ndarray, h: int, w: int) -> list:
    """
    Detect candidate interactive UI elements using contour analysis.
    Returns a list of element candidates with type hints.
    """
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (3, 3), 0)
    edges = cv2.Canny(blurred, 30, 100)

    # Dilate to connect nearby edges (handles thin borders)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    dilated = cv2.dilate(edges, kernel, iterations=1)

    contours, hierarchy = cv2.findContours(dilated, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    img_area = h * w
    elements = []

    for i, cnt in enumerate(contours):
        x, y, bw, bh = cv2.boundingRect(cnt)
        area = bw * bh
        if area < 200 or area > img_area * 0.9:
            continue
        if bw < 10 or bh < 10:
            continue

        aspect = bw / bh if bh else 0
        area_fraction = area / img_area
        solidity = cv2.contourArea(cnt) / area if area else 0

        element_type = None
        confidence = "low"
        notes = []

        # Button detection
        if (BUTTON_ASPECT_MIN <= aspect <= BUTTON_ASPECT_MAX
                and BUTTON_HEIGHT_MIN <= bh <= BUTTON_HEIGHT_MAX
                and solidity > 0.7
                and area_fraction < 0.05):
            element_type = "button_candidate"
            confidence = "medium"
            notes.append("Compact filled rectangle — likely a button or pill")

        # Input field detection (wider, less tall, with visible border)
        elif (INPUT_ASPECT_MIN <= aspect
                and INPUT_HEIGHT_MIN <= bh <= INPUT_HEIGHT_MAX
                and solidity > 0.85
                and area_fraction < 0.15):
            element_type = "input_candidate"
            confidence = "medium"
            notes.append("Wide shallow rectangle — likely a text input or select")

        # Card / panel detection
        elif (0.5 <= aspect <= 4.0
                and area_fraction >= CARD_AREA_MIN_FRACTION
                and solidity > 0.9
                and bw > 80 and bh > 60):
            element_type = "card_candidate"
            confidence = "low"
            notes.append("Large filled rectangle — may be a card, panel, or table row")

        # Tab bar item (very wide, short, near top of image)
        elif (aspect > 3 and bh < 50 and y < h * 0.3 and area_fraction < 0.08):
            element_type = "tab_candidate"
            confidence = "low"
            notes.append("Shallow wide strip near top — may be a tab or nav bar")

        if element_type:
            elements.append({
                "type": element_type,
                "x": int(x), "y": int(y), "w": int(bw), "h": int(bh),
                "aspect_ratio": round(aspect, 2),
                "area_fraction": round(area_fraction, 4),
                "solidity": round(solidity, 2),
                "confidence": confidence,
                "notes": notes,
            })

    # De-duplicate heavily overlapping candidates
    elements = _dedup_elements(elements)
    return elements


def _dedup_elements(elements: list, iou_threshold: float = 0.7) -> list:
    """Remove elements with high IoU overlap, keeping higher-confidence ones."""
    if not elements:
        return []
    conf_order = {"high": 0, "medium": 1, "low": 2}
    elements = sorted(elements, key=lambda e: conf_order.get(e["confidence"], 3))
    kept = []
    for e in elements:
        dominated = False
        for k in kept:
            if _iou(e, k) > iou_threshold:
                dominated = True
                break
        if not dominated:
            kept.append(e)
    return kept


def _iou(a: dict, b: dict) -> float:
    ax1, ay1 = a["x"], a["y"]
    ax2, ay2 = ax1 + a["w"], ay1 + a["h"]
    bx1, by1 = b["x"], b["y"]
    bx2, by2 = bx1 + b["w"], by1 + b["h"]
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
    union = a["w"] * a["h"] + b["w"] * b["h"] - inter
    return inter / union if union else 0


def detect_repeated_units(elements: list, text_blocks: list) -> list:
    """
    Find groups of similarly-sized elements at regular intervals —
    indicators of card grids, list rows, table rows, or nav items.
    """
    if len(elements) < 3:
        return []

    patterns = []
    # Group by type
    by_type: dict = {}
    for el in elements:
        by_type.setdefault(el["type"], []).append(el)

    for etype, group in by_type.items():
        if len(group) < 2:
            continue
        # Check for size similarity
        widths = [e["w"] for e in group]
        heights = [e["h"] for e in group]
        if np.std(widths) / (np.mean(widths) + 1) < 0.2 and np.std(heights) / (np.mean(heights) + 1) < 0.2:
            # Check regular spacing
            xs = sorted(e["x"] for e in group)
            ys = sorted(e["y"] for e in group)
            x_gaps = [xs[i+1] - xs[i] for i in range(len(xs)-1)]
            y_gaps = [ys[i+1] - ys[i] for i in range(len(ys)-1)]
            horiz_regular = len(x_gaps) > 0 and np.std(x_gaps) / (np.mean(x_gaps) + 1) < 0.3
            vert_regular = len(y_gaps) > 0 and np.std(y_gaps) / (np.mean(y_gaps) + 1) < 0.3
            if horiz_regular or vert_regular:
                patterns.append({
                    "type": etype,
                    "count": len(group),
                    "avg_w": round(float(np.mean(widths))),
                    "avg_h": round(float(np.mean(heights))),
                    "arrangement": "horizontal" if horiz_regular else "vertical",
                    "note": f"{len(group)} similarly-sized {etype}s at regular intervals — likely a repeated component",
                })

    return patterns


def identify_ambiguities(
    regions: dict,
    text_blocks: list,
    elements: list,
    patterns: list,
    h: int,
    w: int,
) -> list:
    """
    Produce a list of structured ambiguities that require human clarification.
    Each ambiguity: { id, region, observation, question }
    """
    ambiguities = []
    aid = 1

    # Unreadable text (low-confidence OCR blocks)
    low_conf = [b for b in text_blocks if b["conf"] < 55 and b["w"] > 30]
    if low_conf:
        ambiguities.append({
            "id": aid,
            "region": "various",
            "observation": f"{len(low_conf)} text block(s) could not be read reliably by OCR.",
            "question": "Can you provide the text for any unreadable labels, headings, or button copies?",
            "locations": [{"x": b["x"], "y": b["y"], "w": b["w"], "h": b["h"]} for b in low_conf[:5]],
        })
        aid += 1

    # No sidebar detected but image is wide
    if "sidebar" not in regions and w > 900:
        ambiguities.append({
            "id": aid,
            "region": "left edge",
            "observation": "No sidebar was detected, but the image is wide enough to suggest one may be present.",
            "question": "Is there a left navigation panel or sidebar? If so, what does it contain?",
        })
        aid += 1

    # Modal detected
    if "modal" in regions:
        ambiguities.append({
            "id": aid,
            "region": "modal overlay",
            "observation": "A centred overlay was detected — this appears to be a dialog or modal.",
            "question": "What triggers this modal? What are the action buttons (confirm/cancel labels)?",
        })
        aid += 1

    # Many button candidates with no readable labels
    buttons = [e for e in elements if e["type"] == "button_candidate"]
    unlabelled = [b for b in buttons if not any(
        b["x"] <= t["x"] <= b["x"] + b["w"] and b["y"] <= t["y"] <= b["y"] + b["h"]
        for t in text_blocks
    )]
    if len(unlabelled) > 2:
        ambiguities.append({
            "id": aid,
            "region": "various",
            "observation": f"{len(unlabelled)} button-shaped element(s) have no readable text label.",
            "question": "What are the labels or icons for these buttons? Are any of them icon-only (e.g. close, search, settings)?",
            "locations": [{"x": b["x"], "y": b["y"]} for b in unlabelled[:5]],
        })
        aid += 1

    # Repeated units suggest dynamic data
    if patterns:
        for p in patterns:
            ambiguities.append({
                "id": aid,
                "region": "main",
                "observation": f"Detected {p['count']} repeated {p['type']}s arranged {p['arrangement']}ly.",
                "question": f"What data do these repeated units represent? What fields does each unit show?",
            })
            aid += 1

    # No header detected
    if "header" not in regions:
        ambiguities.append({
            "id": aid,
            "region": "top",
            "observation": "No distinct header/nav bar was detected at the top of the design.",
            "question": "Is there a navigation bar or page header? If so, what does it contain?",
        })
        aid += 1

    return ambiguities


def assign_region_labels(elements: list, text_blocks: list, regions: dict) -> None:
    """Tag each element and text block with its detected region."""
    for item in elements + text_blocks:
        x, y = item["x"], item["y"]
        item["region"] = "unknown"
        for region_name, r in regions.items():
            if r["x"] <= x <= r["x"] + r["w"] and r["y"] <= y <= r["y"] + r["h"]:
                item["region"] = region_name
                break


# ── Main ───────────────────────────────────────────────────────────────────

def parse_image(image_path: str, debug_dir: str = None) -> dict:
    bgr, rgb, pil = load_image(image_path)
    h, w = rgb.shape[:2]

    mode_info = estimate_mode(rgb)
    regions = detect_regions(rgb, h, w)
    text_blocks = ocr_text_blocks(pil)
    elements = detect_ui_elements(bgr, h, w)
    patterns = detect_repeated_units(elements, text_blocks)
    assign_region_labels(elements, text_blocks, regions)
    ambiguities = identify_ambiguities(regions, text_blocks, elements, patterns, h, w)

    result = {
        "source": os.path.basename(image_path),
        "dimensions": {"w": w, "h": h},
        "colour": mode_info,
        "regions": regions,
        "text_blocks": text_blocks,
        "ui_elements": elements,
        "repeated_patterns": patterns,
        "ambiguities": ambiguities,
        "summary": {
            "detected_regions": list(regions.keys()),
            "text_block_count": len(text_blocks),
            "element_count": len(elements),
            "repeated_pattern_count": len(patterns),
            "ambiguity_count": len(ambiguities),
            "mode": mode_info["mode"],
        },
    }

    if debug_dir:
        _save_debug_image(bgr, regions, elements, text_blocks, debug_dir)

    return result


def _save_debug_image(bgr, regions, elements, text_blocks, debug_dir):
    """Draw detected regions and elements onto a copy of the image for debugging."""
    os.makedirs(debug_dir, exist_ok=True)
    vis = bgr.copy()
    colours = {
        "header": (255, 100, 0),
        "footer": (0, 100, 255),
        "sidebar": (0, 200, 100),
        "main": (200, 200, 0),
        "modal": (200, 0, 200),
    }
    for name, r in regions.items():
        colour = colours.get(name, (128, 128, 128))
        cv2.rectangle(vis, (r["x"], r["y"]), (r["x"] + r["w"], r["y"] + r["h"]), colour, 2)
        cv2.putText(vis, name, (r["x"] + 4, r["y"] + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.6, colour, 2)
    for el in elements:
        cv2.rectangle(vis, (el["x"], el["y"]), (el["x"] + el["w"], el["y"] + el["h"]), (0, 0, 255), 1)
    for tb in text_blocks[:50]:
        cv2.rectangle(vis, (tb["x"], tb["y"]), (tb["x"] + tb["w"], tb["y"] + tb["h"]), (0, 255, 0), 1)
    out_path = os.path.join(debug_dir, "debug_overlay.png")
    cv2.imwrite(out_path, vis)
    print(f"[debug] Overlay saved to {out_path}", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(description="Parse a UI design image into structured JSON.")
    parser.add_argument("image", help="Path to the image file (PNG, JPG, WEBP, BMP)")
    parser.add_argument("--out", default=None, help="Output JSON file path (default: stdout)")
    parser.add_argument("--debug-dir", default=None, help="Directory to save debug overlay image")
    args = parser.parse_args()

    result = parse_image(args.image, debug_dir=args.debug_dir)
    output = json.dumps(result, indent=2, ensure_ascii=False)

    if args.out:
        Path(args.out).write_text(output, encoding="utf-8")
        print(f"Parsed {args.image} → {args.out}", file=sys.stderr)
        print(f"Summary: {result['summary']}", file=sys.stderr)
    else:
        print(output)


if __name__ == "__main__":
    main()
