# Salt DS Named Patterns Reference

Patterns sourced from the Salt Design System website:
https://www.saltdesignsystem.com/salt/patterns/

Use this file to match complex design regions to their canonical Salt DS pattern.
For each pattern, a minimal code blueprint is provided.

---

## Table of Contents

1. [App Shell / Navigation Shell](#1-app-shell--navigation-shell)
2. [Dashboard Layout](#2-dashboard-layout)
3. [Data Grid / Table](#3-data-grid--table)
4. [Master-Detail Layout](#4-master-detail-layout)
5. [Form Layout — Single Column](#5-form-layout--single-column)
6. [Form Layout — Two Column](#6-form-layout--two-column)
7. [Stepped / Wizard Flow](#7-stepped--wizard-flow)
8. [Empty State](#8-empty-state)
9. [Metric / KPI Card Row](#9-metric--kpi-card-row)
10. [Filterable List / Search + Results](#10-filterable-list--search--results)
11. [Dialog / Confirmation Modal](#11-dialog--confirmation-modal)
12. [Slide-in Drawer / Side Panel](#12-slide-in-drawer--side-panel)
13. [Tabs-based Content Panel](#13-tabs-based-content-panel)
14. [Notification / Toast Banner](#14-notification--toast-banner)
15. [Date Range Picker Form Field](#15-date-range-picker-form-field)
16. [File Upload Drop Zone](#16-file-upload-drop-zone)
17. [Vertical Navigation Rail](#17-vertical-navigation-rail)
18. [Breadcrumb + Page Header](#18-breadcrumb--page-header)
19. [Selection Cards / Plan Picker](#19-selection-cards--plan-picker)
20. [Overflow / More Menu](#20-overflow--more-menu)

---

## 1. App Shell / Navigation Shell

**Trigger**: design shows a persistent top nav bar + optional left sidebar + main content area.

```tsx
import { SaltProvider, StackLayout, SplitLayout, NavigationItem, GridLayout, GridItem } from "@salt-ds/core";

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <SaltProvider density="medium" mode="light">
      <StackLayout direction="column" style={{ minHeight: "100vh" }}>
        {/* Top Nav */}
        <SplitLayout
          startItem={
            <StackLayout direction="row" gap={2} align="center">
              {/* Logo */}
              <span style={{ fontWeight: 700 }}>MyApp</span>
              <NavigationItem href="/dashboard">Dashboard</NavigationItem>
              <NavigationItem href="/reports">Reports</NavigationItem>
            </StackLayout>
          }
          endItem={
            <StackLayout direction="row" gap={2} align="center">
              {/* User menu / avatar */}
            </StackLayout>
          }
          style={{
            padding: "0 var(--salt-spacing-500)",
            height: "var(--salt-size-base)",
            borderBottom: "var(--salt-size-border) solid var(--salt-separable-primary-borderColor)",
            background: "var(--salt-container-secondary-background)",
          }}
        />
        {/* Content */}
        <StackLayout direction="row" style={{ flex: 1 }}>
          {/* Optional sidebar */}
          <StackLayout
            direction="column"
            style={{
              width: 220,
              borderRight: "var(--salt-size-border) solid var(--salt-separable-primary-borderColor)",
              padding: "var(--salt-spacing-400)",
            }}
          >
            <NavigationItem active href="/dashboard">Dashboard</NavigationItem>
            {/* TODO: more nav items */}
          </StackLayout>
          {/* Main */}
          <StackLayout direction="column" style={{ flex: 1, padding: "var(--salt-spacing-500)" }}>
            {children}
          </StackLayout>
        </StackLayout>
      </StackLayout>
    </SaltProvider>
  );
}
```

---

## 2. Dashboard Layout

**Trigger**: grid of metric cards + charts + summary tables.

```tsx
import { GridLayout, GridItem, Card, StackLayout, H2, H4, Text, StatusIndicator } from "@salt-ds/core";

const METRICS = [
  { label: "Total Users", value: "12,400", trend: "+8%", status: "success" },
  { label: "Revenue", value: "$84,200", trend: "+3%", status: "success" },
  { label: "Churn", value: "2.1%", trend: "-0.4%", status: "error" },
  { label: "Open Tickets", value: "17", trend: "0%", status: "warning" },
];

export function DashboardLayout() {
  return (
    <StackLayout direction="column" gap={4}>
      <H2>Overview</H2>
      {/* KPI row */}
      <GridLayout columns={4} gap={3}>
        {METRICS.map(({ label, value, trend, status }) => (
          <Card key={label}>
            <StackLayout direction="column" gap={1}>
              <Text styleAs="label">{label}</Text>
              <H4>{value}</H4>
              <StackLayout direction="row" gap={1} align="center">
                <StatusIndicator status={status as any} />
                <Text styleAs="notation">{trend}</Text>
              </StackLayout>
            </StackLayout>
          </Card>
        ))}
      </GridLayout>
      {/* Chart + table section */}
      <GridLayout columns={12} gap={3}>
        <GridItem colSpan={8}>
          <Card style={{ minHeight: 300 }}>
            {/* TODO: chart component */}
          </Card>
        </GridItem>
        <GridItem colSpan={4}>
          <Card style={{ minHeight: 300 }}>
            {/* TODO: summary list */}
          </Card>
        </GridItem>
      </GridLayout>
    </StackLayout>
  );
}
```

---

## 3. Data Grid / Table

**Trigger**: design shows rows + columns with headers, sortable columns, row selection.

```tsx
// @salt-ds/data-grid is a separate package
// npm install @salt-ds/data-grid
import { Grid, GridColumn } from "@salt-ds/data-grid";
import { SaltProvider } from "@salt-ds/core";

const ROWS = [
  { id: 1, name: "Alice", role: "Engineer", status: "Active" },
  // TODO: replace with real data
];

export function DataTable() {
  return (
    <SaltProvider density="high" mode="light">
      <Grid
        rowData={ROWS}
        rowKeyGetter={(row) => row.id}
        style={{ height: 400 }}
      >
        <GridColumn id="name" name="Name" getValue={(r) => r.name} />
        <GridColumn id="role" name="Role" getValue={(r) => r.role} />
        <GridColumn id="status" name="Status" getValue={(r) => r.status} />
      </Grid>
    </SaltProvider>
  );
}
```

> Install separately: `npm install @salt-ds/data-grid`

---

## 4. Master-Detail Layout

**Trigger**: left list panel + right detail panel, clicking a list item updates detail.

```tsx
import { GridLayout, GridItem, Card, StackLayout, Text, H3, Divider } from "@salt-ds/core";
import { useState } from "react";

const ITEMS = [
  { id: 1, title: "Item One", detail: "Detail content for item one." },
  { id: 2, title: "Item Two", detail: "Detail content for item two." },
];

export function MasterDetail() {
  const [selected, setSelected] = useState(ITEMS[0]);

  return (
    <GridLayout columns={12} gap={3} style={{ height: "100%" }}>
      <GridItem colSpan={4}>
        <Card style={{ height: "100%", overflow: "auto" }}>
          <StackLayout direction="column" gap={1}>
            {ITEMS.map((item) => (
              <StackLayout
                key={item.id}
                direction="column"
                style={{
                  padding: "var(--salt-spacing-300)",
                  cursor: "pointer",
                  background: selected.id === item.id
                    ? "var(--salt-container-secondary-background)"
                    : "transparent",
                  borderRadius: 4,
                }}
                onClick={() => setSelected(item)}
              >
                <Text>{item.title}</Text>
              </StackLayout>
            ))}
          </StackLayout>
        </Card>
      </GridItem>
      <GridItem colSpan={8}>
        <Card style={{ height: "100%" }}>
          <StackLayout direction="column" gap={3}>
            <H3>{selected.title}</H3>
            <Divider />
            <Text>{selected.detail}</Text>
          </StackLayout>
        </Card>
      </GridItem>
    </GridLayout>
  );
}
```

---

## 5. Form Layout — Single Column

**Trigger**: stacked form fields, one column, with submit button at bottom.

```tsx
import {
  StackLayout, FormField, FormFieldLabel, FormFieldHelperText,
  Input, Textarea, Button, H2, Banner, BannerContent,
} from "@salt-ds/core";
import { useState } from "react";

export function SingleColumnForm() {
  const [submitted, setSubmitted] = useState(false);

  return (
    <StackLayout direction="column" gap={4} style={{ maxWidth: 560, margin: "0 auto" }}>
      <H2>Form Title</H2>
      {submitted && (
        <Banner status="success"><BannerContent>Submitted successfully.</BannerContent></Banner>
      )}
      <FormField>
        <FormFieldLabel>Full name</FormFieldLabel>
        <Input placeholder="Jane Smith" />
      </FormField>
      <FormField>
        <FormFieldLabel>Email</FormFieldLabel>
        <Input type="email" placeholder="jane@example.com" />
        <FormFieldHelperText>We'll never share your email.</FormFieldHelperText>
      </FormField>
      <FormField>
        <FormFieldLabel>Message</FormFieldLabel>
        <Textarea rows={4} />
      </FormField>
      <Button sentiment="accented" appearance="solid" onClick={() => setSubmitted(true)}>
        Submit
      </Button>
    </StackLayout>
  );
}
```

---

## 6. Form Layout — Two Column

**Trigger**: side-by-side field pairs (First Name + Last Name, etc.).

```tsx
import { GridLayout, GridItem, FormField, FormFieldLabel, Input, Button } from "@salt-ds/core";

export function TwoColumnForm() {
  return (
    <GridLayout columns={2} gap={3} style={{ maxWidth: 800 }}>
      <GridItem>
        <FormField><FormFieldLabel>First name</FormFieldLabel><Input /></FormField>
      </GridItem>
      <GridItem>
        <FormField><FormFieldLabel>Last name</FormFieldLabel><Input /></FormField>
      </GridItem>
      <GridItem colSpan={2}>
        <FormField><FormFieldLabel>Email</FormFieldLabel><Input type="email" /></FormField>
      </GridItem>
      <GridItem colSpan={2}>
        <Button sentiment="accented" appearance="solid">Save</Button>
      </GridItem>
    </GridLayout>
  );
}
```

---

## 7. Stepped / Wizard Flow

**Trigger**: numbered steps at top, one step visible at a time, Next/Back navigation.

```tsx
// npm install @salt-ds/lab
import { SteppedTracker, TrackerStep } from "@salt-ds/lab";
import { StackLayout, Button, SplitLayout } from "@salt-ds/core";
import { useState } from "react";

const STEPS = ["Personal Info", "Address", "Review", "Confirm"];

export function WizardFlow() {
  const [activeStep, setActiveStep] = useState(0);

  return (
    <StackLayout direction="column" gap={4}>
      <SteppedTracker activeStep={activeStep} orientation="horizontal">
        {STEPS.map((label, i) => (
          <TrackerStep key={i}>
            <span>{label}</span>
          </TrackerStep>
        ))}
      </SteppedTracker>

      {/* Step content */}
      <StackLayout direction="column" gap={3} style={{ minHeight: 200 }}>
        {/* TODO: render step content for STEPS[activeStep] */}
        <p>Step {activeStep + 1}: {STEPS[activeStep]}</p>
      </StackLayout>

      <SplitLayout
        startItem={
          <Button
            appearance="bordered"
            disabled={activeStep === 0}
            onClick={() => setActiveStep((s) => s - 1)}
          >
            Back
          </Button>
        }
        endItem={
          activeStep < STEPS.length - 1
            ? <Button sentiment="accented" appearance="solid" onClick={() => setActiveStep((s) => s + 1)}>Next</Button>
            : <Button sentiment="accented" appearance="solid">Submit</Button>
        }
      />
    </StackLayout>
  );
}
```

---

## 8. Empty State

**Trigger**: a placeholder panel shown when a list/table has no data.

```tsx
import { StackLayout, Text, Button } from "@salt-ds/core";
import { SearchIcon } from "@salt-ds/icons";

export function EmptyState({ onAction }: { onAction: () => void }) {
  return (
    <StackLayout
      direction="column"
      align="center"
      gap={3}
      style={{ padding: "var(--salt-spacing-700)", textAlign: "center" }}
    >
      <SearchIcon size={2} style={{ color: "var(--salt-content-secondary-foreground)" }} />
      <Text>No results found</Text>
      <Text styleAs="notation" style={{ color: "var(--salt-content-secondary-foreground)" }}>
        Try adjusting your filters or search terms.
      </Text>
      <Button appearance="bordered" onClick={onAction}>Clear filters</Button>
    </StackLayout>
  );
}
```

---

## 9. Metric / KPI Card Row

**Trigger**: row of identical metric cards with a label, large number, and status/trend.

See [Dashboard Layout](#2-dashboard-layout) for the full pattern.

---

## 10. Filterable List / Search + Results

**Trigger**: search bar at top, filtered list or cards below.

```tsx
import { StackLayout, Input, FlowLayout, Card, Text } from "@salt-ds/core";
import { SearchIcon } from "@salt-ds/icons";
import { useState } from "react";

const ALL_ITEMS = ["Apple", "Banana", "Cherry", "Date", "Elderberry"];

export function FilterableList() {
  const [query, setQuery] = useState("");
  const filtered = ALL_ITEMS.filter((i) => i.toLowerCase().includes(query.toLowerCase()));

  return (
    <StackLayout direction="column" gap={3}>
      <Input
        startAdornment={<SearchIcon />}
        placeholder="Search…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <FlowLayout gap={2}>
        {filtered.map((item) => (
          <Card key={item} style={{ minWidth: 140 }}>
            <Text>{item}</Text>
          </Card>
        ))}
      </FlowLayout>
    </StackLayout>
  );
}
```

---

## 11. Dialog / Confirmation Modal

**Trigger**: modal overlay with title, body content, and action buttons.

```tsx
import { Dialog, DialogHeader, DialogContent, DialogActions, Button } from "@salt-ds/core";
import { useState } from "react";

export function ConfirmDialog() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <Button onClick={() => setOpen(true)}>Delete item</Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogHeader header="Confirm deletion" />
        <DialogContent>
          Are you sure you want to delete this item? This action cannot be undone.
        </DialogContent>
        <DialogActions>
          <Button appearance="bordered" onClick={() => setOpen(false)}>Cancel</Button>
          <Button sentiment="negative" appearance="solid" onClick={() => setOpen(false)}>
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
```

---

## 12. Slide-in Drawer / Side Panel

**Trigger**: panel that slides in from the right (or left) over the page content.

```tsx
// npm install @salt-ds/lab
import { Drawer } from "@salt-ds/lab";
import { StackLayout, Button, H3, Text } from "@salt-ds/core";
import { useState } from "react";

export function SidePanel() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <Button onClick={() => setOpen(true)}>Open panel</Button>
      <Drawer open={open} onOpenChange={setOpen} position="right">
        <StackLayout direction="column" gap={3} style={{ padding: "var(--salt-spacing-500)" }}>
          <H3>Panel Title</H3>
          <Text>Panel content goes here.</Text>
          <Button appearance="bordered" onClick={() => setOpen(false)}>Close</Button>
        </StackLayout>
      </Drawer>
    </>
  );
}
```

---

## 13. Tabs-based Content Panel

**Trigger**: row of tab labels at top, content area changes on tab click.

```tsx
import { Tabs, Tab, TabPanel, StackLayout } from "@salt-ds/core";
import { useState } from "react";

export function TabbedPanel() {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <StackLayout direction="column" gap={0}>
      <Tabs activeTabIndex={activeTab} onActiveChange={setActiveTab}>
        <Tab label="Overview" />
        <Tab label="Activity" />
        <Tab label="Settings" />
      </Tabs>
      <TabPanel>
        {activeTab === 0 && <div>Overview content</div>}
        {activeTab === 1 && <div>Activity content</div>}
        {activeTab === 2 && <div>Settings content</div>}
      </TabPanel>
    </StackLayout>
  );
}
```

---

## 14. Notification / Toast Banner

**Trigger**: dismissable notification bar at top or bottom of screen.

```tsx
import { Banner, BannerContent, BannerActions, Button } from "@salt-ds/core";
import { useState } from "react";

export function ToastBanner() {
  const [visible, setVisible] = useState(true);

  if (!visible) return null;
  return (
    <Banner status="info">
      <BannerContent>
        A new version is available. Refresh to update.
      </BannerContent>
      <BannerActions>
        <Button appearance="transparent" onClick={() => setVisible(false)}>
          Dismiss
        </Button>
      </BannerActions>
    </Banner>
  );
}
```

---

## 15. Date Range Picker Form Field

**Trigger**: date input or calendar picker for selecting a date or range.

```tsx
// npm install @salt-ds/lab
import { DatePicker } from "@salt-ds/lab";
import { FormField, FormFieldLabel } from "@salt-ds/core";

export function DateField() {
  return (
    <FormField>
      <FormFieldLabel>Select date</FormFieldLabel>
      <DatePicker />
    </FormField>
  );
}
```

---

## 16. File Upload Drop Zone

**Trigger**: a dashed-border area for dragging files, or a file browse button.

```tsx
// npm install @salt-ds/lab
import { FileDropZone, FileDropZoneIcon, FileDropZoneTrigger } from "@salt-ds/lab";
import { Text } from "@salt-ds/core";

export function UploadZone() {
  return (
    <FileDropZone onDrop={(files) => console.log(files)}>
      <FileDropZoneIcon />
      <Text>Drag and drop files here</Text>
      <FileDropZoneTrigger accept=".pdf,.docx" />
    </FileDropZone>
  );
}
```

---

## 17. Vertical Navigation Rail

**Trigger**: left sidebar with stacked navigation links, possibly nested/grouped.

```tsx
import { StackLayout, NavigationItem, Divider, Text } from "@salt-ds/core";

export function NavRail() {
  return (
    <StackLayout
      direction="column"
      gap={0}
      style={{
        width: 220,
        minHeight: "100vh",
        borderRight: "var(--salt-size-border) solid var(--salt-separable-primary-borderColor)",
        padding: "var(--salt-spacing-400) 0",
      }}
    >
      <Text styleAs="label" style={{ padding: "var(--salt-spacing-200) var(--salt-spacing-400)" }}>
        MAIN
      </Text>
      <NavigationItem active href="/dashboard">Dashboard</NavigationItem>
      <NavigationItem href="/reports">Reports</NavigationItem>
      <NavigationItem href="/users">Users</NavigationItem>
      <Divider style={{ margin: "var(--salt-spacing-200) 0" }} />
      <Text styleAs="label" style={{ padding: "var(--salt-spacing-200) var(--salt-spacing-400)" }}>
        SETTINGS
      </Text>
      <NavigationItem href="/settings">Preferences</NavigationItem>
      <NavigationItem href="/billing">Billing</NavigationItem>
    </StackLayout>
  );
}
```

---

## 18. Breadcrumb + Page Header

**Trigger**: "Home > Section > Page" trail above a page title.

```tsx
// npm install @salt-ds/lab
import { Breadcrumbs, Breadcrumb } from "@salt-ds/lab";
import { StackLayout, H1, Text } from "@salt-ds/core";

export function PageHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <StackLayout direction="column" gap={1}>
      <Breadcrumbs>
        <Breadcrumb href="/">Home</Breadcrumb>
        <Breadcrumb href="/section">Section</Breadcrumb>
        <Breadcrumb>{title}</Breadcrumb>
      </Breadcrumbs>
      <H1>{title}</H1>
      {subtitle && (
        <Text style={{ color: "var(--salt-content-secondary-foreground)" }}>{subtitle}</Text>
      )}
    </StackLayout>
  );
}
```

---

## 19. Selection Cards / Plan Picker

**Trigger**: 2–4 cards where the user selects one (plan picker, option selector).

```tsx
import { InteractableCard, FlowLayout, StackLayout, H3, Text, Label } from "@salt-ds/core";
import { useState } from "react";

const OPTIONS = [
  { id: "basic", name: "Basic", price: "$0/mo", desc: "For individuals" },
  { id: "pro", name: "Pro", price: "$29/mo", desc: "For teams" },
  { id: "enterprise", name: "Enterprise", price: "Custom", desc: "For large orgs" },
];

export function SelectionCards() {
  const [selected, setSelected] = useState("pro");

  return (
    <FlowLayout gap={3}>
      {OPTIONS.map(({ id, name, price, desc }) => (
        <InteractableCard
          key={id}
          selected={selected === id}
          onClick={() => setSelected(id)}
          style={{ width: 200 }}
        >
          <StackLayout direction="column" gap={1}>
            <Label>{name}</Label>
            <H3>{price}</H3>
            <Text styleAs="notation">{desc}</Text>
          </StackLayout>
        </InteractableCard>
      ))}
    </FlowLayout>
  );
}
```

---

## 20. Overflow / More Menu

**Trigger**: "⋯" button or kebab menu that opens a list of actions.

```tsx
import { Menu, MenuItem, MenuTrigger, Button } from "@salt-ds/core";
import { OverflowMenuIcon } from "@salt-ds/icons";

export function OverflowMenu() {
  return (
    <Menu>
      <MenuTrigger>
        <Button appearance="transparent" aria-label="More actions">
          <OverflowMenuIcon />
        </Button>
      </MenuTrigger>
      <MenuItem onClick={() => console.log("edit")}>Edit</MenuItem>
      <MenuItem onClick={() => console.log("duplicate")}>Duplicate</MenuItem>
      <MenuItem sentiment="negative" onClick={() => console.log("delete")}>Delete</MenuItem>
    </Menu>
  );
}
```
