# Salt DS Token Reference

## Aesthetic Directions

| Direction | `density` | `mode` | Refinement |
|-----------|-----------|--------|------------|
| **Data / Financial** | `high` | `dark` | Near-monochrome, tight gaps, tabular rhythm |
| **Minimal / Refined** | `low` | `light` | Maximum whitespace, single accent, restrained type |
| **Editorial / Magazine** | `low` | `light` | Asymmetric `GridLayout`, oversized Display type |
| **Terminal / Developer** | `high` | `dark` | Monospace accent, raw structural feel |
| **Warm / Approachable** | `low` | `light` | Warm accent override, generous padding |
| **Enterprise / Neutral** | `medium` | `light` | Default Salt — focus on layout and info architecture |
| **Dramatic / High-Contrast** | `medium` | `dark` | Strong accent, bold Display headlines |

---

## Density Guide

| `density` | Best for | Component height | Spacing feel |
|-----------|----------|------------------|--------------|
| `high` | Trading UIs, data dashboards, analytics | Compact | Tight |
| `medium` | Standard business apps (default) | Standard | Balanced |
| `low` | Consumer-facing, reading-heavy, forms | Spacious | Relaxed |
| `touch` | Mobile / kiosk / touchscreen | Large targets | Very generous |

---

## Color Tokens

```css
/* Backgrounds / Surfaces */
var(--salt-container-primary-background)      /* main page / app bg */
var(--salt-container-secondary-background)    /* card, panel, sidebar bg */
var(--salt-container-tertiary-background)     /* nested / inset surfaces */
var(--salt-overlayable-background)            /* dialog / modal overlay bg */

/* Text */
var(--salt-content-primary-foreground)        /* primary body text */
var(--salt-content-secondary-foreground)      /* muted labels, captions */
var(--salt-content-disabled-foreground)       /* disabled text */

/* Actions / Accent */
var(--salt-actionable-cta-background)         /* CTA / primary button bg */
var(--salt-actionable-cta-foreground)         /* CTA / primary button text */
var(--salt-actionable-primary-background)     /* secondary button bg */
var(--salt-actionable-primary-foreground)     /* secondary button text */
var(--salt-actionable-cta-background-hover)   /* hover state */
var(--salt-actionable-cta-background-active)  /* active/pressed state */

/* Borders */
var(--salt-separable-primary-borderColor)     /* standard border */
var(--salt-separable-secondary-borderColor)   /* subtle border */
var(--salt-focused-outlineColor)              /* focus ring — never suppress */

/* Status */
var(--salt-status-error-foreground)
var(--salt-status-error-background)
var(--salt-status-warning-foreground)
var(--salt-status-warning-background)
var(--salt-status-success-foreground)
var(--salt-status-success-background)
var(--salt-status-info-foreground)
var(--salt-status-info-background)
```

---

## Spacing Tokens (density-aware)

```css
var(--salt-spacing-100)   /* ≈4px at medium density */
var(--salt-spacing-200)   /* ≈8px */
var(--salt-spacing-300)   /* ≈12px */
var(--salt-spacing-400)   /* ≈16px */
var(--salt-spacing-500)   /* ≈24px */
var(--salt-spacing-600)   /* ≈32px */
var(--salt-spacing-700)   /* ≈48px */
```

> These respond to the `density` prop automatically. Never use raw `px` for spacing.

---

## Typography Tokens

```css
var(--salt-text-display1-fontSize)   /* hero / landing page display */
var(--salt-text-display2-fontSize)
var(--salt-text-h1-fontSize)
var(--salt-text-h2-fontSize)
var(--salt-text-h3-fontSize)
var(--salt-text-h4-fontSize)
var(--salt-text-body-fontSize)
var(--salt-text-label-fontSize)
var(--salt-text-notation-fontSize)   /* caption, footnote, annotation */
```

**Component shortcuts:**
```tsx
<Display1>, <Display2>          // Hero text
<H1>, <H2>, <H3>, <H4>         // Page / section headings
<Text styleAs="body">           // Body copy
<Text styleAs="label">          // Field labels (outside FormField)
<Text styleAs="notation">       // Captions / footnotes
<Label>                         // Compact inline label
```

---

## Size Tokens

```css
var(--salt-size-border)        /* border-width for custom elements */
var(--salt-size-indicator)     /* status dot diameter */
var(--salt-size-icon)          /* icon rendering size */
var(--salt-size-base)          /* standard component height */
var(--salt-size-selectable)    /* checkbox / radio hit area */
```

---

## Shadow / Elevation Tokens

```css
var(--salt-overlayable-shadow)      /* dialogs, floating panels */
var(--salt-shadow-100)              /* subtle card lift */
var(--salt-shadow-200)              /* raised panel */
var(--salt-shadow-300)              /* high emphasis — tooltip, popover */
```

---

## Custom Token Overrides (project-level)

If the design deviates from default Salt palette, override in a separate CSS file:

```css
/* custom-theme.css — import AFTER @salt-ds/theme/index.css */
:root {
  --salt-actionable-cta-background: #your-brand-color;
  --salt-actionable-cta-foreground: #ffffff;
}
```

Never override inline in component styles.

---

## Required App Setup

```tsx
// src/main.tsx
import { SaltProvider } from "@salt-ds/core";
import "@salt-ds/theme/index.css";
// Optional custom overrides:
import "./custom-theme.css";

root.render(
  <SaltProvider theme="salt" density="medium" mode="light">
    <App />
  </SaltProvider>
);
```

## Required Fonts

```bash
npm install @fontsource/open-sans @fontsource/pt-mono
```

```ts
// src/main.tsx
import "@fontsource/open-sans/300.css";
import "@fontsource/open-sans/400.css";
import "@fontsource/open-sans/600.css";
import "@fontsource/open-sans/700.css";
import "@fontsource/pt-mono";
```
