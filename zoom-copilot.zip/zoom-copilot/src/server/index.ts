import express from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import 'dotenv/config';

import { authRouter } from './routes/auth';
import { copilotRouter } from './routes/copilot';
import { CopilotAgentManager } from './copilotAgentManager';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
const httpServer = createServer(app);
const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

app.use(cors({ origin: '*' }));
app.use(express.json());

// Serve the Zoom App frontend
app.use(express.static(path.join(__dirname, '../../client')));

// API routes
app.use('/auth', authRouter);
app.use('/api/copilot', copilotRouter);

// Health check
app.get('/health', (_req, res) => res.json({ status: 'ok', version: '1.0.0' }));

// ─── WebSocket: real-time Copilot streaming ──────────────────────────────────

const agentManager = new CopilotAgentManager();
const clients = new Map<string, WebSocket>();

wss.on('connection', (ws) => {
  const clientId = crypto.randomUUID();
  clients.set(clientId, ws);

  console.log(`[WS] Client connected: ${clientId}`);

  ws.on('message', async (raw) => {
    try {
      const msg = JSON.parse(raw.toString()) as WsMessage;
      await handleWsMessage(clientId, ws, msg);
    } catch (err) {
      ws.send(JSON.stringify({ type: 'error', message: String(err) }));
    }
  });

  ws.on('close', () => {
    clients.delete(clientId);
    agentManager.endSession(clientId);
    console.log(`[WS] Client disconnected: ${clientId}`);
  });

  // Send welcome
  ws.send(JSON.stringify({
    type: 'connected',
    clientId,
    message: 'Connected to Zoom Copilot server',
  }));
});

type WsMessage =
  | { type: 'init'; agentType: AgentType; meetingContext?: MeetingContext }
  | { type: 'message'; text: string; meetingContext?: MeetingContext }
  | { type: 'reset' }
  | { type: 'ping' };

type AgentType = 'general' | 'code-reviewer' | 'meeting-summarizer' | 'pr-helper' | 'bug-hunter';

export interface MeetingContext {
  meetingId?: string;
  topic?: string;
  participants?: string[];
  transcript?: string;
  sharedCode?: string;
}

async function handleWsMessage(
  clientId: string,
  ws: WebSocket,
  msg: WsMessage
) {
  switch (msg.type) {
    case 'ping':
      ws.send(JSON.stringify({ type: 'pong' }));
      break;

    case 'init': {
      await agentManager.createSession(clientId, msg.agentType, msg.meetingContext);
      ws.send(JSON.stringify({
        type: 'ready',
        agentType: msg.agentType,
        greeting: agentManager.getGreeting(msg.agentType),
      }));
      break;
    }

    case 'message': {
      if (!agentManager.hasSession(clientId)) {
        await agentManager.createSession(clientId, 'general', msg.meetingContext);
      }

      // Stream response tokens back in real time
      ws.send(JSON.stringify({ type: 'stream_start' }));

      await agentManager.sendMessage(clientId, msg.text, msg.meetingContext, (token) => {
        ws.send(JSON.stringify({ type: 'stream_token', token }));
      });

      ws.send(JSON.stringify({ type: 'stream_end' }));
      break;
    }

    case 'reset':
      agentManager.endSession(clientId);
      ws.send(JSON.stringify({ type: 'reset_ok' }));
      break;
  }
}

// ─── Start ───────────────────────────────────────────────────────────────────

const PORT = process.env.PORT ?? 3000;
httpServer.listen(PORT, () => {
  console.log(`\n🚀 Zoom Copilot server running at http://localhost:${PORT}`);
  console.log(`📡 WebSocket endpoint: ws://localhost:${PORT}/ws`);
  console.log(`\nOpen the Zoom App at http://localhost:${PORT}\n`);
});
