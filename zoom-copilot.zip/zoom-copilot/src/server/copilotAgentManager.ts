/**
 * CopilotAgentManager
 * Wraps the GitHub Copilot SDK to manage per-user agent sessions.
 * Falls back to direct Anthropic/OpenAI API calls if the SDK isn't installed.
 */

import type { MeetingContext } from './index';

type AgentType =
  | 'general'
  | 'code-reviewer'
  | 'meeting-summarizer'
  | 'pr-helper'
  | 'bug-hunter';

interface Session {
  agentType: AgentType;
  history: Array<{ role: 'user' | 'assistant'; content: string }>;
  meetingContext?: MeetingContext;
  createdAt: Date;
}

const AGENT_SYSTEM_PROMPTS: Record<AgentType, string> = {
  'general': `You are a GitHub Copilot agent embedded inside a Zoom meeting. 
You help developers with coding questions, architecture decisions, and technical discussions happening in the meeting.
You have access to the meeting transcript and any code shared during the meeting.
Be concise, practical, and code-focused. Format code with markdown.`,

  'code-reviewer': `You are a senior code reviewer embedded in a Zoom meeting.
Your job is to review code shared during the meeting, spot bugs, suggest improvements, 
flag security issues, and explain your reasoning clearly.
Reference specific line numbers when relevant. Be thorough but constructive.`,

  'meeting-summarizer': `You are a technical meeting assistant embedded in a Zoom call.
Summarize discussions, extract action items, capture decisions made, and list open questions.
When asked, generate structured summaries with: Summary, Decisions, Action Items, and Open Questions sections.`,

  'pr-helper': `You are a PR (Pull Request) assistant in a Zoom meeting.
Help draft PR descriptions, write commit messages, suggest test cases for changes discussed,
and identify potential issues before code is merged. Be specific and reference the code context.`,

  'bug-hunter': `You are a debugging specialist in a Zoom meeting.
Analyze error messages, stack traces, and code to identify root causes.
Walk through your reasoning step by step. Suggest fixes and explain why bugs occur.
Ask clarifying questions when you need more context.`,
};

const AGENT_GREETINGS: Record<AgentType, string> = {
  'general': "Hey! I'm your Copilot agent for this meeting. Ask me anything — code questions, architecture decisions, quick lookups. I can see your meeting context too.",
  'code-reviewer': "Code review mode activated. Paste any code and I'll give you a thorough review — bugs, security, style, and improvements.",
  'meeting-summarizer': "Summary mode on. I'm tracking your meeting. Ask me to summarize anytime, or I can extract action items and decisions.",
  'pr-helper': "PR helper ready. Tell me what you're building and I'll help you craft the perfect PR description, commit messages, and test cases.",
  'bug-hunter': "Debugging mode engaged. Share your error, stack trace, or code and let's find the bug together. I'll walk through it step by step.",
};

export class CopilotAgentManager {
  private sessions = new Map<string, Session>();
  private copilotSdkAvailable = false;

  constructor() {
    this._checkSdkAvailability();
  }

  private async _checkSdkAvailability() {
    try {
      // Try to import the Copilot SDK (requires @github/copilot-sdk + Copilot CLI)
      await import('@github/copilot-sdk');
      this.copilotSdkAvailable = true;
      console.log('[CopilotAgentManager] GitHub Copilot SDK available ✓');
    } catch {
      console.log('[CopilotAgentManager] Copilot SDK not available, using fallback API');
    }
  }

  async createSession(
    clientId: string,
    agentType: AgentType,
    meetingContext?: MeetingContext
  ): Promise<void> {
    this.sessions.set(clientId, {
      agentType,
      history: [],
      meetingContext,
      createdAt: new Date(),
    });
  }

  hasSession(clientId: string): boolean {
    return this.sessions.has(clientId);
  }

  getGreeting(agentType: AgentType): string {
    return AGENT_GREETINGS[agentType];
  }

  async sendMessage(
    clientId: string,
    userMessage: string,
    meetingContext: MeetingContext | undefined,
    onToken: (token: string) => void
  ): Promise<string> {
    const session = this.sessions.get(clientId);
    if (!session) {
      throw new Error('No session found. Call createSession first.');
    }

    // Update meeting context if provided
    if (meetingContext) {
      session.meetingContext = { ...session.meetingContext, ...meetingContext };
    }

    // Add user message to history
    session.history.push({ role: 'user', content: userMessage });

    let fullResponse: string;

    if (this.copilotSdkAvailable) {
      fullResponse = await this._sendViaCopilotSdk(session, userMessage, onToken);
    } else {
      fullResponse = await this._sendViaDirectApi(session, userMessage, onToken);
    }

    // Add assistant response to history
    session.history.push({ role: 'assistant', content: fullResponse });

    return fullResponse;
  }

  // ─── GitHub Copilot SDK path ────────────────────────────────────────────────
  private async _sendViaCopilotSdk(
    session: Session,
    userMessage: string,
    onToken: (token: string) => void
  ): Promise<string> {
    // Dynamic import of the Copilot SDK
    const { CopilotClient } = await import('@github/copilot-sdk');

    const client = new CopilotClient();
    await client.start();

    const sdkSession = await client.createSession({
      model: 'claude-sonnet-4-5', // or 'gpt-4o', 'o3', etc.
      streaming: true,
      // Inject system prompt as base prompt
      basePrompt: this._buildSystemPrompt(session),
    });

    let fullText = '';

    await sdkSession.send({
      prompt: userMessage,
      onToken: (token: string) => {
        fullText += token;
        onToken(token);
      },
    });

    await client.stop();
    return fullText;
  }

  // ─── Direct API fallback (Anthropic / OpenAI) ───────────────────────────────
  private async _sendViaDirectApi(
    session: Session,
    userMessage: string,
    onToken: (token: string) => void
  ): Promise<string> {
    const anthropicKey = process.env.ANTHROPIC_API_KEY;
    const openaiKey = process.env.OPENAI_API_KEY;

    if (anthropicKey) {
      return this._sendViaAnthropic(session, onToken, anthropicKey);
    } else if (openaiKey) {
      return this._sendViaOpenAI(session, onToken, openaiKey);
    } else {
      // Demo mode: simulate streaming response
      return this._simulateResponse(session, userMessage, onToken);
    }
  }

  private async _sendViaAnthropic(
    session: Session,
    onToken: (token: string) => void,
    apiKey: string
  ): Promise<string> {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-5',
        max_tokens: 2048,
        stream: true,
        system: this._buildSystemPrompt(session),
        messages: session.history.map((m) => ({ role: m.role, content: m.content })),
      }),
    });

    let fullText = '';
    const reader = response.body!.getReader();
    const decoder = new TextDecoder();

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value);
      const lines = chunk.split('\n').filter((l) => l.startsWith('data: '));

      for (const line of lines) {
        try {
          const data = JSON.parse(line.slice(6));
          if (data.type === 'content_block_delta' && data.delta?.text) {
            fullText += data.delta.text;
            onToken(data.delta.text);
          }
        } catch { /* skip malformed chunks */ }
      }
    }

    return fullText;
  }

  private async _sendViaOpenAI(
    session: Session,
    onToken: (token: string) => void,
    apiKey: string
  ): Promise<string> {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        stream: true,
        messages: [
          { role: 'system', content: this._buildSystemPrompt(session) },
          ...session.history.map((m) => ({ role: m.role, content: m.content })),
        ],
      }),
    });

    let fullText = '';
    const reader = response.body!.getReader();
    const decoder = new TextDecoder();

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value);
      const lines = chunk.split('\n').filter((l) => l.startsWith('data: '));

      for (const line of lines) {
        if (line === 'data: [DONE]') continue;
        try {
          const data = JSON.parse(line.slice(6));
          const token = data.choices?.[0]?.delta?.content;
          if (token) {
            fullText += token;
            onToken(token);
          }
        } catch { /* skip */ }
      }
    }

    return fullText;
  }

  // Demo mode: returns a realistic-looking response without any API key
  private async _simulateResponse(
    session: Session,
    userMessage: string,
    onToken: (token: string) => void
  ): Promise<string> {
    const responses: Record<string, string> = {
      default: `I'm your Copilot agent! To get real responses, add your **GitHub Token** (for the Copilot SDK) or an **Anthropic/OpenAI API key** to your \`.env\` file.\n\nFor now, I'm running in demo mode. Here's what I can help with in this meeting:\n- 🔍 Code review & debugging\n- 📝 PR descriptions\n- 📋 Meeting summaries\n- 🏗️ Architecture questions`,
    };

    const demoText = responses['default'];
    const words = demoText.split(' ');

    for (const word of words) {
      await new Promise((r) => setTimeout(r, 40));
      onToken(word + ' ');
    }

    return demoText;
  }

  // ─── System prompt builder ──────────────────────────────────────────────────
  private _buildSystemPrompt(session: Session): string {
    let prompt = AGENT_SYSTEM_PROMPTS[session.agentType];

    if (session.meetingContext) {
      const ctx = session.meetingContext;
      prompt += '\n\n--- MEETING CONTEXT ---';
      if (ctx.topic)        { prompt += `\nMeeting topic: ${ctx.topic}`; }
      if (ctx.participants) { prompt += `\nParticipants: ${ctx.participants.join(', ')}`; }
      if (ctx.transcript)   { prompt += `\nRecent transcript:\n${ctx.transcript}`; }
      if (ctx.sharedCode)   { prompt += `\nCode shared in meeting:\n\`\`\`\n${ctx.sharedCode}\n\`\`\``; }
    }

    return prompt;
  }

  endSession(clientId: string): void {
    this.sessions.delete(clientId);
  }
}
