import { Router } from 'express';
import type { Request, Response } from 'express';

export const authRouter = Router();

// Step 1: Redirect user to Zoom OAuth
authRouter.get('/zoom', (_req: Request, res: Response) => {
  const clientId = process.env.ZOOM_CLIENT_ID;
  const redirectUri = encodeURIComponent(process.env.ZOOM_REDIRECT_URI ?? '');
  const scope = encodeURIComponent('meeting:read user:read');

  const authUrl =
    `https://zoom.us/oauth/authorize` +
    `?response_type=code` +
    `&client_id=${clientId}` +
    `&redirect_uri=${redirectUri}` +
    `&scope=${scope}`;

  res.redirect(authUrl);
});

// Step 2: Handle Zoom OAuth callback
authRouter.get('/callback', async (req: Request, res: Response) => {
  const { code } = req.query;

  if (!code) {
    res.status(400).json({ error: 'Missing authorization code' });
    return;
  }

  try {
    const tokenRes = await fetch('https://zoom.us/oauth/token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization: `Basic ${Buffer.from(
          `${process.env.ZOOM_CLIENT_ID}:${process.env.ZOOM_CLIENT_SECRET}`
        ).toString('base64')}`,
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code: code as string,
        redirect_uri: process.env.ZOOM_REDIRECT_URI ?? '',
      }),
    });

    const tokens = await tokenRes.json() as {
      access_token: string;
      refresh_token: string;
      expires_in: number;
    };

    // In production: store tokens securely (DB / encrypted session)
    // For demo: redirect to app with token in fragment
    res.redirect(`/?access_token=${tokens.access_token}`);
  } catch (err) {
    res.status(500).json({ error: 'OAuth token exchange failed', detail: String(err) });
  }
});

// GET /auth/status — check if user is authenticated
authRouter.get('/status', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  const hasToken = !!authHeader?.startsWith('Bearer ');
  const hasGithubToken = !!process.env.GITHUB_TOKEN;

  res.json({
    zoomAuth: hasToken,
    copilotReady: hasGithubToken || !!process.env.ANTHROPIC_API_KEY || !!process.env.OPENAI_API_KEY,
    demoMode: !hasGithubToken && !process.env.ANTHROPIC_API_KEY && !process.env.OPENAI_API_KEY,
  });
});
