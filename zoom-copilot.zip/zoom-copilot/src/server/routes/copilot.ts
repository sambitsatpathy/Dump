import { Router } from 'express';
import type { Request, Response } from 'express';

export const copilotRouter = Router();

// GET /api/copilot/agents — list available agents
copilotRouter.get('/agents', (_req: Request, res: Response) => {
  res.json({
    agents: [
      {
        id: 'general',
        name: 'General Copilot',
        icon: '🤖',
        description: 'All-purpose coding assistant. Ask anything.',
        badge: 'Most Popular',
      },
      {
        id: 'code-reviewer',
        name: 'Code Reviewer',
        icon: '🔍',
        description: 'Spot bugs, security issues, and suggest improvements.',
        badge: null,
      },
      {
        id: 'meeting-summarizer',
        name: 'Meeting Summarizer',
        icon: '📋',
        description: 'Extracts decisions, action items, and open questions.',
        badge: 'New',
      },
      {
        id: 'pr-helper',
        name: 'PR Helper',
        icon: '🔀',
        description: 'Draft PR descriptions, commit messages, and test cases.',
        badge: null,
      },
      {
        id: 'bug-hunter',
        name: 'Bug Hunter',
        icon: '🐛',
        description: 'Analyzes errors and stack traces to find root causes.',
        badge: null,
      },
    ],
  });
});

// POST /api/copilot/quick — quick one-shot query (no session / streaming)
copilotRouter.post('/quick', async (req: Request, res: Response) => {
  const { prompt, context } = req.body as { prompt: string; context?: string };

  if (!prompt) {
    res.status(400).json({ error: 'prompt is required' });
    return;
  }

  // This route is just for simple REST calls - WebSocket is preferred for streaming
  res.json({
    message: 'Use the WebSocket connection at /ws for full streaming support.',
    hint: 'Connect via ws://localhost:3000/ws and send { type: "message", text: "..." }',
  });
});
