# Zoom Copilot 🤖⚡

GitHub Copilot agents embedded directly in your Zoom meetings. Ask coding questions, get code reviews, summarize discussions — all without leaving your call.

---

## What it does

A Zoom App side panel that connects to **GitHub Copilot agents** via the new Copilot SDK. Five specialist agents are available:

| Agent | Best for |
|---|---|
| 🤖 General | All-purpose coding Q&A |
| 🔍 Code Reviewer | Bug spotting, security, style feedback |
| 📋 Meeting Summarizer | Action items, decisions, open questions |
| 🔀 PR Helper | PR descriptions, commit messages, test cases |
| 🐛 Bug Hunter | Stack trace analysis, root cause finding |

---

## Architecture

```
Zoom Meeting (client)
    │
    └─ Zoom App Side Panel (HTML/JS)
            │ WebSocket (ws://localhost:3000/ws)
            │
        Express Server (Node.js)
            │
        CopilotAgentManager
            │
            ├─ GitHub Copilot SDK  ← preferred (requires Copilot CLI + subscription)
            ├─ Anthropic API       ← fallback (set ANTHROPIC_API_KEY)
            ├─ OpenAI API          ← fallback (set OPENAI_API_KEY)
            └─ Demo mode           ← no keys needed, simulated responses
```

---

## Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
```

Edit `.env` and set **at least one** of:
- `GITHUB_TOKEN` — GitHub Personal Access Token with Copilot scope (uses Copilot SDK)
- `ANTHROPIC_API_KEY` — Uses Claude directly (no Copilot subscription needed)
- `OPENAI_API_KEY` — Uses GPT-4o directly

Leave all blank to run in **demo mode** (simulated responses).

### 3. Start the server
```bash
npm run dev
```

Server starts at `http://localhost:3000`

---

## Using with Zoom

### Option A: Standalone (browser, no Zoom)
Visit `http://localhost:3000` — works as a standalone chat with all 5 agents.

### Option B: Zoom App (side panel inside meetings)
1. Go to [Zoom App Marketplace](https://marketplace.zoom.us/develop/apps) → Create App → Zoom App
2. Set your app's home URL to `http://localhost:3000` (or your deployed URL)
3. Add OAuth credentials to `.env`
4. Install the app in your Zoom account
5. During any meeting: click **Apps** in the toolbar → open Zoom Copilot

The app automatically pulls in meeting context (topic, participants) via the Zoom Apps JS SDK.

---

## Using the GitHub Copilot SDK

The Copilot SDK (released January 2026) wraps the same engine behind Copilot CLI:

```bash
# Install Copilot CLI first
npm install -g @github/copilot

# Install the SDK
npm install @github/copilot-sdk
```

Then set `GITHUB_TOKEN` in `.env`. The `CopilotAgentManager` will automatically use the SDK and fall back to direct API if unavailable.

---

## Paste Code for Context

Use the `+ code` button in the context bar to paste code into the panel. The active agent will use it as context for all subsequent messages — great for code reviews during a meeting.

---

## Deploying

For production Zoom App deployment:
1. Deploy to any Node.js host (Railway, Render, Fly.io, etc.)
2. Update `ZOOM_REDIRECT_URI` to your production URL
3. Update `zoom-app-manifest.json` with your production URL
4. Submit for Zoom Marketplace review (or keep as an internal app)

---

## License
MIT
